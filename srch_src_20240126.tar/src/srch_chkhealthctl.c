/*===========================================================================================================
 #���α׷��� : ���� �ｺüũ ��Ʈ�ѷ�
=============================================================================================================

-----------------------------------------------------------------------------------------------------------*/
/*  (1) ���� Header Define			                                                           				*/
/*---------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>		/* exit() */
#include <string.h>		/* strcmp() */
#include <unistd.h>		/* sleep() */
#include <signal.h>		/* kill() */

#include "srchsrv.h"
/*---------------------------------------------------------------------------------------------------------*/
/*  (2) ���� �Լ� ProtoType Define	                                                                   */
/*---------------------------------------------------------------------------------------------------------*/
void print_usage(void);
int process_start(char *exe_file);
int process_stop(void);


/*---------------------------------------------------------------------------------------------------------*/
/*  (3) ���� ����� ���� Define		                                                                   */
/*---------------------------------------------------------------------------------------------------------*/
#define f_name "srchchk_health.pid"

/*-----------------------------------------------------------------------------------------------------------
 #�Լ� ��� : main
------------------------------------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	char exe_file[32]="./srchchk_health";
	int _pStat;
	char tempbuf[64]={0};

	if (argc >= 3) strcpy(exe_file, argv[2]);

	if(argc == 1) {
		print_usage();
		exit(0);
	} else if(strcmp(argv[1], "start") == 0 || strcmp(argv[1], "-s") == 0) {
		_pStat = process_start(exe_file);

		if(_pStat == 1) {
			printf("\n\nThe Health Checker has been started successfully.\n");
			exit(0);
		} else if(_pStat == 2) {
			printf("\n\nThe Health Checker is running.\n");
			exit(0);
		} else {
			printf("\n\nFailed to start the Health Checker.\n");
			exit(0);
		}
	} else if(strcmp(argv[1], "stop") == 0 || strcmp(argv[1], "-h") == 0 ) {
		if(process_stop()) {
			printf("The Health Checker has stopped.\n");
			exit(0);
		} else {
			printf("Failed to stop the Health Checker.\n");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "kill") == 0){
		sprintf(tempbuf,"kill -9 `ps -ef | grep '%s' | egrep -v 'grep|vi|tail' | awk '{print $2}'`",exe_file);
		if(system(tempbuf) > 0 )		
			return 0;		
		else		
			return 1;		
	} 
	else { 
		print_usage();
		exit(0);
	}
	
	return 1;
}



/*-----------------------------------------------------------------------------------------------------------
 #�Լ� ��� : ���� ����
 #�߰� ���� : popen �� ����Ͽ� ���μ��� ��Ī���� üũ�ϴ� ��ƾ���� ����
------------------------------------------------------------------------------------------------------------*/
int process_start(char *exe_file)
{
	
	FILE *t_file;
	
	if((t_file = fopen(f_name, "r")) != 0) {
		printf("The Health Checker is running : pid file exists\n");
		return 2;
	}
	else {	
		printf("Please wait for srchchk_healthctl is running the Health Checker...\n");
		if( system(exe_file) > 0 ) return 0;
		else return 1;
	}

	
}

/*-----------------------------------------------------------------------------------------------------------
 #�Լ� ��� : ���� ���� 
 #�߰� ���� : popen �� ����Ͽ� ���μ��� ��Ī���� üũ�ϴ� ��ƾ���� ����
------------------------------------------------------------------------------------------------------------*/
int process_stop(void)
{	
	FILE *t_file;
	char l_buf[BUFSIZ];
	const char *p_fname = f_name;
   
	if((t_file = fopen(f_name, "r")) == NULL) {
		printf("The Health Checker is not running : pid file does not exists\n");
		perror(f_name);
		exit(1);
	}
			
	while(fgets(l_buf, BUFSIZ, t_file) != NULL) {
		printf("Kill the Health Checker\n");
		if(kill(atoi(l_buf), SIGKILL) !=0) {
			printf("pid : %d is not an Health Checker process\n", atoi(l_buf));
		}
	}
	
	if((remove(p_fname)) !=0) {
		printf("srchchk_healthctl does not have permission to remove pid file\n");
	}
	return 1; 
	
}


/*-----------------------------------------------------------------------------------------------------------
 #�Լ� ��� : ����
------------------------------------------------------------------------------------------------------------*/
void print_usage(void)
{
	printf("usage : srchchk_healthctl [start, stop]\n");
}
