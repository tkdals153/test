#include "company.h"

void LOGGER_OUTREC(const char *str, int nBufSize);
void LOGGER_OUTREC_AIA(const char *str, int nBufSize);
void LOGGER_OUTREC_HANA(const char *str, int nBufSize);
void LOGGER_OUTREC_metlife(const char *str, int nBufSize);
void LOGGER_OUTREC_KBCD(const char *str, int nBufSize);
void LOGGER_OUTREC_BUSAN(const char *str, int nBufSize);
void LOGGER_OUTREC_miraelife(const char *str, int nBufSize);
void LOGGER_OUTREC_inglife(const char *str, int nBufSize);
void LOGGER_OUTREC_KBST(const char *str, int nBufSize);
void LOGGER_OUTREC_DGBNK(const char *str, int nBufSize);
void LOGGER_OUTREC_HKLIFE(const char *str, int nBufSize);

void MakeText_ALL_GetHead(void *p, char *pszSrc);
void MakeText_ALL_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_ALL_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_ALL(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_KBST_GetHead(void *p, char *pszSrc);
void MakeText_KBST_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_KBST_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_KBST(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_AIA_GetHead(void *p, char *pszSrc);
void MakeText_AIA_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_AIA_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_AIA(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_hana_bank_GetHead(void *p, char *pszSrc);
void MakeText_hana_bank_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_hana_bank_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_hana_bank(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_busan_bank_GetHead(void *p, char *pszSrc);
void MakeText_busan_bank_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_busan_bank_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_busan_bank(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_metlife_GetHead(void *p, char *pszSrc);
void MakeText_metlife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_metlife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_metlife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_KBCD_GetHead(void *p, char *pszSrc);
void MakeText_KBCD_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_KBCD_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_KBCD(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_miraelife_GetHead(void *p, char *pszSrc);
void MakeText_miraelife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_miraelife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_miraelife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_inglife_GetHead(void *p, char *pszSrc);
void MakeText_inglife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_inglife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_inglife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_DGBNK_GetHead(void *p, char *pszSrc);
void MakeText_DGBNK_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_DGBNK_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_DGBNK(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);

void MakeText_HKLIFE_GetHead(void *p, char *pszSrc);
void MakeText_HKLIFE_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext);
void MakeText_HKLIFE_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt);
void MakeChildTxt_HKLIFE(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut);
/*-----------------------------------------------------------------------------------------------*/
/* ���� ��� */
/*-----------------------------------------------------------------------------------------------*/
void Poi_MakeText_GetHead(void *p, char *pszSrc)
{
	#ifdef _ALL_
	MakeText_ALL_GetHead(p, pszSrc);
	#endif
	
	#ifdef _AIA_
	MakeText_AIA_GetHead(p, pszSrc);
	#endif
	
	#ifdef _hana_bank_
	MakeText_hana_bank_GetHead(p, pszSrc);
	#endif
	
	#ifdef _busan_bank_
	MakeText_busan_bank_GetHead(p, pszSrc);
	#endif
	
	#ifdef _metlife_
	MakeText_metlife_GetHead(p, pszSrc);
	#endif
	
	#ifdef _KBCD_
	MakeText_KBCD_GetHead(p, pszSrc);
	#endif
	
	#ifdef _miraelife_
	MakeText_miraelife_GetHead(p, pszSrc);
	#endif
	
	#ifdef _inglife_
	MakeText_inglife_GetHead(p, pszSrc);
	#endif
	
	#ifdef _KBST_
	MakeText_KBST_GetHead(p, pszSrc);
	#endif
	
	#ifdef _DGBNK_
	MakeText_DGBNK_GetHead(p, pszSrc);
	#endif
	
	#ifdef _HKLIFE_
	MakeText_HKLIFE_GetHead(p, pszSrc);
	#endif
}

/* ��ũ�� ���(��������) */
void Poi_MakeText_SetDataBlock(POI_RESULT *pResult, SRCHDAT_C *pOutPut)
{	
	int i;
	if( pResult == 0 || pOutPut == 0 ) return;		
	/*------------------------------------------------------------------------*/
	for( i=0; i<pResult->nTotCnt && pResult->HIT[i].BBH!=0 ; i++ ) {	
			#ifdef _ALL_
			MakeChildTxt_ALL(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _AIA_
			MakeChildTxt_AIA(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _hana_bank_
			MakeChildTxt_hana_bank(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _busan_bank_
			MakeChildTxt_busan_bank(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _metlife_
			MakeChildTxt_metlife(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _KBCD_
			MakeChildTxt_KBCD(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _miraelife_
			MakeChildTxt_miraelife(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _inglife_
			MakeChildTxt_inglife(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _KBST_
			MakeChildTxt_KBST(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _DGBNK_
			MakeChildTxt_DGBNK(&pResult->HIT[i], &pOutPut[i]);
			#endif
			#ifdef _HKLIFE_
			MakeChildTxt_HKLIFE(&pResult->HIT[i], &pOutPut[i]);
			#endif
		}	
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* ���� ������ ���� */
/* ������ ������ ������ �� ����(�� ���� �ڷ� �Ǽ�) */
/*-----------------------------------------------------------------------------------------------*/
int Poi_MakeText_MakeDataBlock(void *pROUT, void *pSrch_out, char *pszDst)
{	
	POI_RESULT *pResult=(POI_RESULT *)pROUT;
	srch_outRec *srch_out=(srch_outRec*)pSrch_out;
	int i=0;	
	char TmpBuf[6];
	
	if( srch_out == 0 ) return i; memset(srch_out->dat, 0x00, sizeof(srch_out->dat));	
	/*-------------------------------------------------------------------------------------------*/
	/* �ڷ� ��û ��ġ */
	strnzcpy(TmpBuf, srch_out->hdr.DatReqLoc, sizeof(srch_out->hdr.DatReqLoc));   
	/*-------------------------------------------------------------------------------------------*/	
	#ifdef _ALL_
	MakeText_ALL_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_ALL_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _AIA_
	MakeText_AIA_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_AIA_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _hana_bank_
	MakeText_hana_bank_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_hana_bank_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _busan_bank_
	MakeText_busan_bank_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_busan_bank_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _metlife_
	MakeText_metlife_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_metlife_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _KBCD_
	MakeText_KBCD_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_KBCD_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _miraelife_
	MakeText_miraelife_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_miraelife_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _inglife_
	MakeText_inglife_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_inglife_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _KBST_
	MakeText_KBST_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_KBST_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _DGBNK_
	MakeText_DGBNK_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_DGBNK_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	
	#ifdef _HKLIFE_
	MakeText_HKLIFE_SetHeader(srch_out, pResult->nHitCnt, pResult->nTotCnt, atoi(TmpBuf));
	Poi_MakeText_SetDataBlock(pResult, srch_out->dat);
	MakeText_HKLIFE_MakeDataText(srch_out, pszDst, pResult->nTotCnt);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	#endif
	/*-------------------------------------------------------------------------------------------*/
	return pResult->nTotCnt;
}
/*  ALL */
#ifdef _ALL_
void MakeText_ALL_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;
	
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_ALL_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_ALL(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}	
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIDO    )); strncpy(pOutPut->SIDO  , TmpBuf2, sizeof(pOutPut->SIDO ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIGUNGU    )); strncpy(pOutPut->SIGUNGU  , TmpBuf2, sizeof(pOutPut->SIGUNGU ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUNDNG    )); strncpy(pOutPut->UPMYUNDNG  , TmpBuf2, sizeof(pOutPut->UPMYUNDNG ));
			}
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUN    )); strncpy(pOutPut->UPMYUN  , TmpBuf2, sizeof(pOutPut->UPMYUN ));
			}
			else if(i==38){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}		
		}
	}
	/*------------------------------------------------------------------------*/
}
/*-----------------------------------------------------------------------------------------------*/
/* ALL : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_ALL_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].SectCd, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.6s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.18s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",    pDat->ZIPS      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",   pDat->NNMR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",    pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMM       ] [%.25s]",   pDat->NNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",    pDat->ZIPQR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",    pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR      ); LOGGER(TmpBuf, 1);	
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif

}
#endif
/*====================================================================================================================*/
/* _DGBNK_ */
#ifdef _DGBNK_
void MakeText_DGBNK_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr.JunMun, pszSrc, sizeof(srch_out->hdr.JunMun));
	memcpy(&srch_out->hdr.DatSize, pszSrc+sizeof(srch_out->hdr.JunMun)+18, sizeof(srch_out->hdr)-sizeof(srch_out->hdr.JunMun));
}

void MakeText_DGBNK_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_DGBNK(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}	
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->RI    )); strncpy(pOutPut->RI  , TmpBuf2, sizeof(pOutPut->RI ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}			
		}
	}
	/*------------------------------------------------------------------------*/
}
/*-----------------------------------------------------------------------------------------------*/
/* �뱸���� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_DGBNK_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;
        char tmpSize[10]={0};

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
        sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 6+25); /* ����*/ 
        strncpy(srch_out->hdr.JunMun,tmpSize,8);
        
        sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 580+25); /* ����*/
        strncpy(srch_out->hdr.JunMun+572,tmpSize,8);

        strncpy(srch_out->hdr.JunMun+41,"03",2);
        strncpy(srch_out->hdr.JunMun+115,"R",1);
        strncpy(srch_out->hdr.JunMun+192,"0",1);
        strncpy(srch_out->hdr.JunMun+154,srch_out->hdr.JunMun+144,10);
        strncpy(srch_out->hdr.JunMun+570,"OD",2);
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
        memcpy(pszDst, srch_out->hdr.JunMun, sizeof(srch_out->hdr.JunMun) );
        memcpy(pszDst + sizeof(srch_out->hdr.JunMun),"                       00",25);
	memcpy(pszDst+sizeof(srch_out->hdr.JunMun)+25, srch_out->hdr.DatSize, sizeof(srch_out->hdr)-sizeof(srch_out->hdr.JunMun) );	/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr)+25, srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
        strcat(pszDst,"@@");
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_DGBNK(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_DGBNK(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256]={0};
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize+25     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt+25   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc+25   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN+25      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt+25     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode+25       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.100s]",   pHdr->KeyWord+25     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.20s]",   pHdr->filler+25      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt+25, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ZIP5      ] [%.6s]",   pDat->ZIP5+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS      ] [%.3s]",   pDat->ZIPS+25     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[ADDR1     ] [%.140s]",   pDat->ADDR1+25     ); LOGGER(TmpBuf, 1);	
		sprintf(TmpBuf, "[RI        ] [%.30s]",   pDat->RI+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI     ] [%.20s]",   pDat->BUNJI+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR     ] [%.3s]",   pDat->ZIPQR+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1     ] [%.140s]",   pDat->NADR1+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB    ] [%.20s]",   pDat->BLDNMB+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNM     ] [%.40s]",   pDat->BLDNM+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR      ] [%.20s]",   pDat->DNGR+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB      ] [%.25s]",   pDat->NNMB+25     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ      ] [%.25s]",   pDat->NNMZ+25     ); LOGGER(TmpBuf, 1);
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/*  KBST */
#ifdef _KBST_
void MakeText_KBST_GetHead(void *p, char *pszSrc)
{
	char TmpBuf[256]={0};
	
	srch_outRec *srch_out=(srch_outRec*)p;
	memset(&srch_out->hdr_I, 0x20, sizeof(srch_out->hdr_I));
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr_I, pszSrc, sizeof(srch_out->hdr_I));
	memcpy(srch_out->hdr.JunMun,srch_out->hdr_I.JunMun,sizeof(srch_out->hdr_I.JunMun));
	strncpy(srch_out->hdr.DatReqLoc,srch_out->hdr_I.DatReqLoc,sizeof(srch_out->hdr_I.DatReqLoc));
	strncpy(srch_out->hdr.KeyWord,srch_out->hdr_I.KeyWord,sizeof(srch_out->hdr_I.KeyWord));
	
	LOGGER("\n=================[IN HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[IN-DatSize1    ] [%.36s]",   srch_out->hdr_I.JunMun      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[IN-DatSize2    ] [%.100s]",  srch_out->hdr_I.JunMun+36   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[IN_DatReqLoc   ] [%.3s]",    srch_out->hdr_I.DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[IN-KeyWord     ] [%.80s]",   srch_out->hdr_I.KeyWord     ); LOGGER(TmpBuf, 1);	
}

void MakeText_KBST_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));
	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_KBST(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}	
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->RI    )); strncpy(pOutPut->RI  , TmpBuf2, sizeof(pOutPut->RI ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->JIHA    )); strncpy(pOutPut->JIHA  , TmpBuf2, sizeof(pOutPut->JIHA ));
			}
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMMB    )); strncpy(pOutPut->BLDNMMB  , TmpBuf2, sizeof(pOutPut->BLDNMMB ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMSB    )); strncpy(pOutPut->BLDNMSB  , TmpBuf2, sizeof(pOutPut->BLDNMSB ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}	
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}	
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIDO    )); strncpy(pOutPut->SIDO  , TmpBuf2, sizeof(pOutPut->SIDO ));
			}
			else if(i==38){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIGUNGU    )); strncpy(pOutPut->SIGUNGU  , TmpBuf2, sizeof(pOutPut->SIGUNGU ));
			}
			else if(i==40){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUNDNG    )); strncpy(pOutPut->UPMYUNDNG  , TmpBuf2, sizeof(pOutPut->UPMYUNDNG ));
			}
			else if(i==42){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUN    )); strncpy(pOutPut->UPMYUN  , TmpBuf2, sizeof(pOutPut->UPMYUN ));
			}
			else if(i==44){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}		
			else if(i==46){
                CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPSEQ    )); strncpy(pOutPut->ZIPSEQ  , TmpBuf2, sizeof(pOutPut->ZIPSEQ ));
            }
		}
	}
	/*------------------------------------------------------------------------*/
}
/*-----------------------------------------------------------------------------------------------*/
/* ALL : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_KBST_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;
	char tmpSize[10]={0},tmp1[8]={0},tmp2[8]={0},tmp[64]={0};

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* �������� ���� */
	sprintf(tmpSize,"%05d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 5); /* ����Į�� 5���� */
	strncpy(srch_out->hdr.JunMun,tmpSize,5);
	
	strncpy(tmp1,srch_out->hdr.JunMun+6,6);
	strncpy(tmp2,srch_out->hdr.JunMun+12,6);
	
	strncpy(srch_out->hdr.JunMun+6,tmp2,6);
	strncpy(srch_out->hdr.JunMun+12,tmp1,6);
	
	#ifndef WIN32
	sprintf(tmp, "%s", GET_TIME(6));
	strncpy(srch_out->hdr.JunMun+52,tmp,6);
	#endif
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr)-136, fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_KBST(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_KBST(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.18s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",    pDat->ZIPS      ); LOGGER(TmpBuf, 1);	
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[RI         ] [%.20s]",   pDat->RI        ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[JIHA       ] [%.4s]",    pDat->JIHA      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMMB    ] [%.10s]",   pDat->BLDNMMB   ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMSB    ] [%.10s]",   pDat->BLDNMSB   ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",   pDat->NNMR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",    pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB       ] [%.25s]",   pDat->NNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",    pDat->ZIPQR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",    pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIDO       ] [%.20s]",   pDat->SIDO      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIGUNGU    ] [%.20s]",   pDat->SIGUNGU   ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[UPMYUNDNG  ] [%.20s]",   pDat->UPMYUNDNG ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[UPMYUN     ] [%.20s]",   pDat->UPMYUN    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMRN      ] [%.30s]",   pDat->NNMRN     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPSEQ     ] [%.10s]",   pDat->ZIPSEQ    ); LOGGER(TmpBuf, 1);
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif

}
#endif
/*====================================================================================================================*/
/*  AIA */
#ifdef _AIA_
void MakeText_AIA_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;
	
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_AIA_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_AIA(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}			
		}
	}
	/*------------------------------------------------------------------------*/
}
/*-----------------------------------------------------------------------------------------------*/
/* AIA���� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_AIA_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_AIA(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_AIA(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.6s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.18s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);

		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB    ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* HANA_BANK */
#ifdef _hana_bank_
void MakeText_hana_bank_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr.JunMun, pszSrc, sizeof(srch_out->hdr.JunMun));
	memcpy(&srch_out->hdr.DatSize, pszSrc+sizeof(srch_out->hdr.JunMun)+18, sizeof(srch_out->hdr)-sizeof(srch_out->hdr.JunMun));
}

void MakeText_hana_bank_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_hana_bank(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJN    )); strncpy(pOutPut->BJN  , TmpBuf2, sizeof(pOutPut->BJN ));
			}
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* �ϳ����� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_hana_bank_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;
	char tmpSize[10]={0},tmp[64]={0};

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* �������� ���� */
	sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 6); /* ���� 8���� @@���� 2 ���ؼ� 6������ */
	strncpy(srch_out->hdr.JunMun,tmpSize,8);
		
	strnzcpy(tmp,srch_out->hdr.JunMun+39,2);
	sprintf(tmpSize,"%02d",atoi(tmp)+1);
	strncpy(srch_out->hdr.JunMun+39,tmpSize,2);
	
	strncpy(srch_out->hdr.JunMun+96,"NAT",3);
	
	strncpy(srch_out->hdr.JunMun+104,"S",1);
	
	#ifndef WIN32
	sprintf(tmp, "%s", GET_TIME(4));
	strncpy(srch_out->hdr.JunMun+172,tmp,16);
	#endif
	
	strncpy(srch_out->hdr.JunMun+188,"0",1);
		
	sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt)-sizeof(srch_out->hdr.JunMun));
	strncpy(srch_out->hdr.JunMun+514,tmpSize,8);	
	
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(&srch_out->dat[i], 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	strcat(pszDst,"@@");
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_HANA(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_HANA(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.17s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",    pDat->ZIPS      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",   pDat->NNMR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",    pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMM       ] [%.25s]",   pDat->NNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",    pDat->ZIPQR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",    pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMRN      ] [%.30s]",   pDat->NNMRN     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJN        ] [%.20s]",   pDat->BJN       ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* BUSAN_BANK */
#ifdef _busan_bank_
void MakeText_busan_bank_GetHead(void *p, char *pszSrc)
{
	char *sdname[]={"�λ�","����","��õ","�뱸","����","����","���","���","����","���","�泲","����","����","���","�泲","����","����","" };
	char *sdcode[]={"26","11","28","27","29","30","31","41","42","43","44","45","46","47","48","50","36",""};
	int i;
	POISRV_ENV *pEnv=0;
	srch_outRec *srch_out;

	pEnv=POI_GetEnvNodeSet();
	
	srch_out = (srch_outRec *) p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr.JunMun, pszSrc, sizeof(srch_out->hdr.JunMun));
	memcpy(&srch_out->hdr.DatSize, pszSrc+sizeof(srch_out->hdr.JunMun)+18, sizeof(srch_out->hdr)-sizeof(srch_out->hdr.JunMun));
	/* ���Ŀ켱�õ��� ����*/
	pEnv->SIDOSORT_F[0]=0;	
	strnzcpy(pEnv->SIDOSORT_F,srch_out->hdr.SIGUNGU,5);
	/*for(i=0;sdcode[i]!=0 && i<17;i++){
		if(strncmp(srch_out->hdr.SIGUNGU,sdcode[i],2)==0){
			strcpy(pEnv->SIDOSORT_F,sdname[i]);
			break;
		}
	}*/
}

void MakeText_busan_bank_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
/*      printf("nTotCnt=%d,nNext=%d,PGNCNT=%d,nBlkCnt=%d\n",nTotCnt,nNext,pEnv->PGNCNT,nBlkCnt);*/ 
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_busan_bank(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR2    )); strncpy(pOutPut->NADR2  , TmpBuf2, sizeof(pOutPut->NADR2 ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->FULL    )); strncpy(pOutPut->FULL  , TmpBuf2, sizeof(pOutPut->FULL ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMMB    )); strncpy(pOutPut->BLDNMMB  , TmpBuf2, sizeof(pOutPut->BLDNMMB ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMSB    )); strncpy(pOutPut->BLDNMSB  , TmpBuf2, sizeof(pOutPut->BLDNMSB ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
				CheckAndCopyFixedLenFLD_WN(" ",  TmpBuf2,  sizeof(pOutPut->ETC1    )); strncpy(pOutPut->ETC1  , TmpBuf2, sizeof(pOutPut->ETC1 ));
				CheckAndCopyFixedLenFLD_WN(" ",  TmpBuf2,  sizeof(pOutPut->ETC2    )); strncpy(pOutPut->ETC2  , TmpBuf2, sizeof(pOutPut->ETC2 ));
				CheckAndCopyFixedLenFLD_WN(" ",  TmpBuf2,  sizeof(pOutPut->ETC3    )); strncpy(pOutPut->ETC3  , TmpBuf2, sizeof(pOutPut->ETC3 ));
			}			
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* �ϳ����� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_busan_bank_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;
	char tmpSize[10]={0},tmp[64]={0};

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* �������� ���� */
	sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 6); /* ���� 8���� @@���� 2 ���ؼ� 6������ */
	strncpy(srch_out->hdr.JunMun,tmpSize,8);
				
	sprintf(tmpSize,"%08d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt)-sizeof(srch_out->hdr.JunMun));
	strncpy(srch_out->hdr.JunMun+514,tmpSize,8);	
	strncpy(srch_out->hdr.JunMun+159,"R",1);
	
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(&srch_out->dat[i], 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	strcat(pszDst,"@@");
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_BUSAN(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_BUSAN(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[1024]={0};
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.100s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[SIGUNGU     ] [%.5s]",    pHdr->SIGUNGU      ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.18s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ZIP5       ] [%.6s]",   pDat->ZIP5     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",   pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.200s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR2      ] [%.200s]",   pDat->NADR2    ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[FULL       ] [%.400s]",    pDat->FULL      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNMMB    ] [%.5s]",   pDat->BLDNMMB     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMSB    ] [%.5s]",   pDat->BLDNMSB       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNM      ] [%.100s]",   pDat->BLDNM      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",    pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ETC1       ] [%.7s]",   pDat->ETC1      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ETC2       ] [%.20s]",   pDat->ETC2      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ETC3       ] [%.20s]",   pDat->ETC3      ); LOGGER(TmpBuf, 1);
				
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* metlife */
#ifdef _metlife_
void MakeText_metlife_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));	
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_metlife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_metlife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIDO    )); strncpy(pOutPut->SIDO  , TmpBuf2, sizeof(pOutPut->SIDO ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIGUNGU    )); strncpy(pOutPut->SIGUNGU  , TmpBuf2, sizeof(pOutPut->SIGUNGU ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->RI    )); strncpy(pOutPut->RI  , TmpBuf2, sizeof(pOutPut->RI ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUN    )); strncpy(pOutPut->UPMYUN  , TmpBuf2, sizeof(pOutPut->UPMYUN ));
			}
			else if(i==38){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* metlife : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_metlife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_metlife(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}
void LOGGER_OUTREC_metlife(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.17s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",   pDat->ZIP5     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIDO       ] [%.20s]",   pDat->SIDO     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[SIGUNGU    ] [%.20s]",   pDat->SIGUNGU     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[RI         ] [%.20s]",    pDat->RI      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",    pDat->BUNJI      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",   pDat->ZIPS     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",   pDat->ZIPQJ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",    pDat->NADR1      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNM      ] [%.20s]",    pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",    pDat->NNMR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",   pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB       ] [%.25s]",   pDat->NNMB     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",   pDat->ZIPQR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[UPMYUN     ] [%.20s]",   pDat->UPMYUN       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMRN      ] [%.40s]",   pDat->NNMRN       ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* KBCARD */
#ifdef _KBCD_
void MakeText_KBCD_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));
	memcpy(&srch_out->hdr.JunMun, pszSrc, sizeof(srch_out->hdr.JunMun));
	memcpy(&srch_out->hdr.DatSize, pszSrc+sizeof(srch_out->hdr.JunMun)+18, sizeof(srch_out->hdr)-sizeof(srch_out->hdr.JunMun));
}

void MakeText_KBCD_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_KBCD(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIDO    )); strncpy(pOutPut->SIDO  , TmpBuf2, sizeof(pOutPut->SIDO ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIGUNGU    )); strncpy(pOutPut->SIGUNGU  , TmpBuf2, sizeof(pOutPut->SIGUNGU ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUN    )); strncpy(pOutPut->UPMYUN  , TmpBuf2, sizeof(pOutPut->UPMYUN ));
			}
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}			
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* ����ī�� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_KBCD_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;
	char tmpSize[10]={0},tmp[64]={0};

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* �������� ���� */
	/*sprintf(tmpSize,"%09d",sizeof(srch_out->hdr)+(sizeof(srch_out->dat[0]) * nBlkCnt) - 9); 
	strncpy(srch_out->hdr.JunMun,tmpSize,9);*/
	sprintf(tmpSize,"%09d",250);
	strncpy(srch_out->hdr.JunMun+15,tmpSize,9);
	
	strncpy(srch_out->hdr.JunMun+61,"R",1);
	strncpy(srch_out->hdr.JunMun+118,"0",1);
	strncpy(srch_out->hdr.JunMun+145,"N0000000",8);		
	
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(&srch_out->dat[i], 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_KBCD(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC_KBCD(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",    pHdr->Rcode       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",   pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.17s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[RI         ] [%.20s]",   pDat->RI        ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",    pDat->ZIPS      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",   pDat->NNMR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",    pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB       ] [%.25s]",   pDat->NNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",    pDat->ZIPQR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",    pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIDO       ] [%.20s]",   pDat->SIDO      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIGUNGU    ] [%.40s]",   pDat->SIGUNGU   ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[UPMYUN     ] [%.40s]",   pDat->UPMYUN    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMRN      ] [%.50s]",   pDat->NNMRN     ); LOGGER(TmpBuf, 1);	
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* _miraelife_ */
#ifdef _miraelife_
void MakeText_miraelife_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));	
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_miraelife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_miraelife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIDO    )); strncpy(pOutPut->SIDO  , TmpBuf2, sizeof(pOutPut->SIDO ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->SIGUNGU    )); strncpy(pOutPut->SIGUNGU  , TmpBuf2, sizeof(pOutPut->SIGUNGU ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->RI    )); strncpy(pOutPut->RI  , TmpBuf2, sizeof(pOutPut->RI ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->UPMYUN    )); strncpy(pOutPut->UPMYUN  , TmpBuf2, sizeof(pOutPut->UPMYUN ));
			}
			else if(i==38){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMRN    )); strncpy(pOutPut->NNMRN  , TmpBuf2, sizeof(pOutPut->NNMRN ));
			}
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* metlife : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_miraelife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_miraelife(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}
void LOGGER_OUTREC_miraelife(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);	
	sprintf(TmpBuf, "[SvrNm       ] [%.12s]",      pHdr->SvrNm       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[UserID      ] [%.6s]",       pHdr->UserID      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DeptCd      ] [%.6s]",       pHdr->DeptCd      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[SvcId       ] [%.10s]",      pHdr->SvcId       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TrdTm       ] [%.6s]",       pHdr->TrdTm       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",       pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",       pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",       pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",       pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",       pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",       pHdr->Rcode       ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[IPAddr      ] [%.20s]",      pHdr->IPAddr      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[ChlCd       ] [%.2s]",       pHdr->ChlCd       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",      pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.17s]",      pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",   pDat->ZIP5     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[SIDO       ] [%.20s]",   pDat->SIDO     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[SIGUNGU    ] [%.20s]",   pDat->SIGUNGU     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[RI         ] [%.20s]",    pDat->RI      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",    pDat->BUNJI      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[ZIPS       ] [%.3s]",   pDat->ZIPS     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",   pDat->ZIPQJ      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",    pDat->NADR1      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB     ] [%.20s]",   pDat->BLDNMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",    pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",    pDat->NNMR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",   pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB       ] [%.25s]",   pDat->NNMB     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",   pDat->ZIPQR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[UPMYUN     ] [%.20s]",   pDat->UPMYUN       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMRN      ] [%.40s]",   pDat->NNMRN       ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* _inglife_ */
#ifdef _inglife_
void MakeText_inglife_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));	
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_inglife_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%04d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 1000)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_inglife(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->RI    )); strncpy(pOutPut->RI  , TmpBuf2, sizeof(pOutPut->RI ));
			}		
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}	
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->JIHA    )); strncpy(pOutPut->JIHA  , TmpBuf2, sizeof(pOutPut->JIHA ));
			}			
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMMB    )); strncpy(pOutPut->BLDNMMB  , TmpBuf2, sizeof(pOutPut->BLDNMMB ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMSB    )); strncpy(pOutPut->BLDNMSB  , TmpBuf2, sizeof(pOutPut->BLDNMSB ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}			
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* metlife : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_inglife_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ZIP5, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_inglife(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}
void LOGGER_OUTREC_inglife(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);	
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",       pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.4s]",       pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",       pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",       pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",       pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",       pHdr->Rcode       ); LOGGER(TmpBuf, 1);		
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",      pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.17s]",      pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ZIP5       ] [%.5s]",   pDat->ZIP5     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",   pDat->ZIPQJ     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[ADDR1      ] [%.80s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[RI         ] [%.20s]",    pDat->RI      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI      ] [%.12s]",    pDat->BUNJI      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[JIHA       ] [%.4s]",   pDat->JIHA       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMMB    ] [%.10s]",   pDat->BLDNMMB      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMSB    ] [%.10s]",    pDat->BLDNMSB      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM      ] [%.40s]",    pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",    pDat->ZIPQR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR       ); LOGGER(TmpBuf, 1);			
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* _hklife_ */
#ifdef _HKLIFE_
void MakeText_HKLIFE_GetHead(void *p, char *pszSrc)
{
	srch_outRec *srch_out=(srch_outRec*)p;	
		
	memset(&srch_out->hdr, 0x20, sizeof(srch_out->hdr));	
	memcpy(&srch_out->hdr, pszSrc, sizeof(srch_out->hdr));
}

void MakeText_HKLIFE_SetHeader(srch_outRec *srch_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char TmpBuf[128];	
	POISRV_ENV *pEnv=0;
	pEnv=POI_GetEnvNodeSet();
	if(  srch_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(srch_out->dat[0])); strncpy(srch_out->hdr.DatSize, TmpBuf, sizeof(srch_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%03d", nTotCnt); strncpy(srch_out->hdr.TotDatCnt, TmpBuf, sizeof(srch_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)*(pEnv->PGNCNT)+nBlkCnt) ) *srch_out->hdr.NextYN='Y';
	else *srch_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%04d", nBlkCnt); strncpy(srch_out->hdr.BlckCnt, TmpBuf, sizeof(srch_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	if(nTotCnt==0)
		CheckAndCopyFixedLenFLD_WN("0", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else if(nTotCnt < 999)
		CheckAndCopyFixedLenFLD_WN("1", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
	else
		CheckAndCopyFixedLenFLD_WN("2", srch_out->hdr.Rcode, sizeof(srch_out->hdr.Rcode));
}

/* �������� ��� */
void MakeChildTxt_HKLIFE(SRCH_HIT_NODE *pInfo, SRCHDAT_C *pOutPut)
{
	POISRV_ENV *pEnv=0;
	MAC_OUT *pMacNode=0;
	MACOBJ *pMacFn;
	int i;
	char TmpBuf[2048],TmpBuf2[2048];

	if( pInfo == 0 ) return;
	pEnv=POI_GetEnvNodeSet(); if( pEnv == 0 ) return; pMacNode=pEnv->MACOUT;
	/*------------------------------------------------------------------------*/
	for( i=0; i<pMacNode->nMac; i++ ) {
		pMacFn=pMacNode->fnMAC[i];
		if(pMacFn->fn!=0){
			pMacFn->fn(pInfo, pMacFn->fnOpt, TmpBuf);	
			if(i==0){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ADDR1    )); strncpy(pOutPut->ADDR1  , TmpBuf2, sizeof(pOutPut->ADDR1 ));
			}
			else if(i==2){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BUNJI    )); strncpy(pOutPut->BUNJI  , TmpBuf2, sizeof(pOutPut->BUNJI ));
			}
			else if(i==4){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1    )); strncpy(pOutPut->NADR1  , TmpBuf2, sizeof(pOutPut->NADR1 ));
			}
			else if(i==6){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNMB    )); strncpy(pOutPut->BLDNMB  , TmpBuf2, sizeof(pOutPut->BLDNMB ));
			}
			else if(i==8){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIP5    )); strncpy(pOutPut->ZIP5  , TmpBuf2, sizeof(pOutPut->ZIP5 ));
			}
			else if(i==10){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPS    )); strncpy(pOutPut->ZIPS  , TmpBuf2, sizeof(pOutPut->ZIPS ));
			}
			else if(i==12){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BLDNM    )); strncpy(pOutPut->BLDNM  , TmpBuf2, sizeof(pOutPut->BLDNM ));
			}	
			else if(i==14){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJC    )); strncpy(pOutPut->BJC  , TmpBuf2, sizeof(pOutPut->BJC ));
			}
			else if(i==16){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMR    )); strncpy(pOutPut->NNMR  , TmpBuf2, sizeof(pOutPut->NNMR ));
			}
			else if(i==18){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMS    )); strncpy(pOutPut->NNMS  , TmpBuf2, sizeof(pOutPut->NNMS ));
			}
			else if(i==20){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMB    )); strncpy(pOutPut->NNMB  , TmpBuf2, sizeof(pOutPut->NNMB ));
			}
			else if(i==22){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQR    )); strncpy(pOutPut->ZIPQR  , TmpBuf2, sizeof(pOutPut->ZIPQR ));
			}
			else if(i==24){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->ZIPQJ    )); strncpy(pOutPut->ZIPQJ  , TmpBuf2, sizeof(pOutPut->ZIPQJ ));
			}
			else if(i==26){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NNMZ    )); strncpy(pOutPut->NNMZ  , TmpBuf2, sizeof(pOutPut->NNMZ ));
			}
			else if(i==28){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->DNGR    )); strncpy(pOutPut->DNGR  , TmpBuf2, sizeof(pOutPut->DNGR ));
			}
			else if(i==30){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->BJN    )); strncpy(pOutPut->BJN  , TmpBuf2, sizeof(pOutPut->BJN ));
			}
			else if(i==32){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->GDJ    )); strncpy(pOutPut->GDJ  , TmpBuf2, sizeof(pOutPut->GDJ ));
			}
			else if(i==34){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1E    )); strncpy(pOutPut->NADR1E  , TmpBuf2, sizeof(pOutPut->NADR1E ));
			}
			else if(i==36){
				CheckAndCopyFixedLenFLD_WN(TmpBuf,  TmpBuf2,  sizeof(pOutPut->NADR1ER    )); strncpy(pOutPut->NADR1ER  , TmpBuf2, sizeof(pOutPut->NADR1ER ));
			}				
		}
	}
	/*------------------------------------------------------------------------*/
}

/*-----------------------------------------------------------------------------------------------*/
/* metlife : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_HKLIFE_MakeDataText(srch_outRec *srch_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( srch_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(srch_out->hdr.DatSize, 1, sizeof(srch_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(srch_out->dat[i].ADDR1, 1, sizeof(srch_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &srch_out->hdr, sizeof(srch_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(srch_out->hdr), srch_out->dat, sizeof(SRCHDAT_C) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC_HKLIFE(pszDst, sizeof(srch_out->hdr) + (sizeof(SRCHDAT_C) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}
void LOGGER_OUTREC_HKLIFE(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	SRCHHDR *pHdr;
    SRCHDAT_C *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; 
	pHdr=(SRCHHDR *)str; pDat=(SRCHDAT_C *)(str + sizeof(SRCHHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);	
	sprintf(TmpBuf, "[SvrNm       ] [%.12s]",      pHdr->SvrNm       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[UserID      ] [%.16s]",       pHdr->UserID      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[ORG_NO      ] [%.5s]",       pHdr->ORG_NO      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[PGM_ID       ] [%.30s]",      pHdr->PGM_ID       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DEAL_TM       ] [%.6s]",       pHdr->DEAL_TM       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",       pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.3s]",       pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",       pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",       pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.4s]",       pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[RCode       ] [%.3s]",       pHdr->Rcode       ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[IPAddr      ] [%.20s]",      pHdr->IPAddr      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TRT_CHNL_GB ] [%.3s]",       pHdr->TRT_CHNL_GB       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[KeyWord     ] [%.80s]",      pHdr->KeyWord     ); LOGGER(TmpBuf, 1);	
	sprintf(TmpBuf, "[filler      ] [%.10s]",      pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[ADDR1       ] [%.50s]",   pDat->ADDR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BUNJI       ] [%.20s]",   pDat->BUNJI     ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[NADR1    ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BLDNMB      ] [%.20s]",   pDat->BLDNMB    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP5         ] [%.5s]",    pDat->ZIP5      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPS      ] [%.3s]",    pDat->ZIPS      ); LOGGER(TmpBuf, 1);		
		sprintf(TmpBuf, "[BLDNM       ] [%.80s]",   pDat->BLDNM     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJC        ] [%.10s]",   pDat->BJC       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMR       ] [%.12s]",    pDat->NNMR     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMS       ] [%.2s]",   pDat->NNMS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMB       ] [%.25s]",   pDat->NNMB     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQR      ] [%.3s]",   pDat->ZIPQR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPQJ      ] [%.3s]",   pDat->ZIPQJ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DNGR       ] [%.20s]",   pDat->DNGR       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[BJN     ] [%.20s]",   pDat->BJN       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[GDJ      ] [%.1s]",   pDat->GDJ       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1E      ] [%.100s]",   pDat->NADR1E       ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1ER      ] [%.100s]",   pDat->NADR1ER       ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}
#endif
/*====================================================================================================================*/
/* _HKTCPTL (�ѱ�����ĳ��Ż: JSON, UTF-8) */
#ifdef _HKTCPTL
/* JSON �Էµ�����(CP949 ��ȯ��)�� Object�� ����� ����, ��� ���ۿ��� �˻�Ű���� ���� */
cJSON* JSON2Keyword_HKTCPTL(char *strJson, char *pDest)
{
    cJSON *json, *teleMsg, *header, *body, *INADM, *PGNM, *trttRsltDvcd; 
    cJSON *cinAdm, *pgnm;

    if ( strJson == 0 || *strJson == 0 )
        return 0;

    /* JSON �Ľ� */
    json = cJSON_Parse(strJson);
    if ( json == 0 ) return 0;

    /*printf("[PARSING JSON]\n%s\n", cJSON_Print(json));*/

    /* �˻������� ���� */
    teleMsg = cJSON_GetObjectItem(json, "teleMsg");
    body = cJSON_GetObjectItem(teleMsg, "body");
    INADM = cJSON_GetObjectItem(body, "INADM");

	/* 2022.11.11 �ѱ�����ĳ��Ż �߰� ��û: ��ȿŰ => trttRsltDvcd = 1 */
	header = cJSON_GetObjectItemCaseSensitive(teleMsg, "header");
	trttRsltDvcd = cJSON_GetObjectItemCaseSensitive(header, "trttRsltDvcd");
	if ( cJSON_IsString(trttRsltDvcd) && (trttRsltDvcd->valuestring != NULL) ) {
		strcpy(trttRsltDvcd->valuestring, "0");
	} else { /* 2022.11.15 null�� ������ ���ܰ� �־� �Ʒ� �ڵ� �߰� */
		cJSON_DeleteItemFromObject(header, "trttRsltDvcd");
		cJSON_AddStringToObject(header, "trttRsltDvcd", "0");
	}
	

	if (cJSON_IsString(INADM) && (INADM->valuestring != NULL)) {
        strcpy(pDest, INADM->valuestring);
	    PGNM = cJSON_GetObjectItem(body, "PGNM");
		if ( cJSON_IsString(PGNM) && (INADM->valuestring != NULL) && atoi(PGNM->valuestring) > 0 ) {
			strcat(pDest, "|");
			strcat(pDest, PGNM->valuestring);
		} else {
			strcpy(trttRsltDvcd->valuestring, "1"); /* Ű ��ȿ �� "1" ����*/
		}
    } else {
        strcpy(trttRsltDvcd->valuestring, "1"); /* Ű ��ȿ �� "1" ����*/
    }

    /* ���� �Ľ� JSON�� ��� JSON ���� �� ���߿� ������ ���� �ܺο��� �������ִ´�.*/
    return json;
}

/* �ѱ�����ĳ��Ż �Էµ����Ϳ��� JSON ���θ� Ȯ���� �� ��� ���ܵ� ������ ���� */
char* HKTCPTL_DetectJSON(char *s)
{
    if ( s == 0 || *s == 0 ) 
        return 0;
    return strstr(s, "{");
}
#endif
