/* Circular Work Queue (2022.07.11 by kyh)
    
    - reference sites:
    https://www.programiz.com/dsa/circular-queue
    https://github.com/petercrona/StsQueue
*/
#include "work_queue.h"

#define WORK_QUEUE_DEFAULT_SIZE (1024)

struct WorkQueue* WQ_Create(int maxsize)
{
    struct WorkQueue *handle = (struct WorkQueue *)calloc(1, sizeof(struct WorkQueue));
    if ( maxsize <= 0 ) {
        handle->items = (int*)calloc(WORK_QUEUE_DEFAULT_SIZE, sizeof(int));
        handle->maxsize = WORK_QUEUE_DEFAULT_SIZE;
    } else {
        handle->items = (int*)calloc(maxsize, sizeof(int));
        handle->maxsize = maxsize;
    }
    
    handle->front = -1;
    handle->rear = -1;

    /*pthread_mutex_init(&handle->mutex, NULL);*/

    return handle;
}

/* Check if the queue is full */
int WQ_IsFull(struct WorkQueue* handle) 
{
    if ((handle->front == handle->rear + 1) || 
        (handle->front == 0 && handle->rear == handle->maxsize - 1)) 
        return 1;
    return 0;
}

/* Check if the queue is empty */
int WQ_IsEmpty(struct WorkQueue* handle) 
{
    if ( handle->front == -1 ) return 1;
    return 0;
}

/* Adding an element */
void WQ_EnQueue(struct WorkQueue* handle, int element) 
{
    /*pthread_mutex_lock(&handle->mutex);*/
    if (WQ_IsFull(handle)) {
        /*printf("\n Queue is full!! \n");*/
    } else {
        if (handle->front == -1) handle->front = 0;
        handle->rear = (handle->rear + 1) % handle->maxsize;
        handle->items[handle->rear] = element;
        handle->size++;
        /*printf("\n Inserted -> %d", element);*/
    }
    /*pthread_mutex_unlock(&handle->mutex);*/
}

/* Removing an element */
int WQ_DeQueue(struct WorkQueue* handle) 
{
    /*pthread_mutex_lock(&handle->mutex);*/
    if (WQ_IsEmpty(handle)) {
        /*printf("\n Queue is empty !! \n");*/
        /*pthread_mutex_unlock(&handle->mutex);*/
        return (-1);
    } else {
        int element = handle->items[handle->front];
        if (handle->front == handle->rear) {
            handle->front = -1;
            handle->rear = -1;
        } 
        /* Q has only one element, so we reset the 
          queue after dequeing it. */
        else {
            handle->front = (handle->front + 1) % handle->maxsize;
        }
        handle->size--;
        /*printf("\n Deleted element -> %d \n", element);*/
        /*pthread_mutex_unlock(&handle->mutex);*/
        return (element);
    }
}

int WQ_GetCount(struct WorkQueue* handle)
{
    return handle->size;
}

int WQ_GetSize(struct WorkQueue* handle)
{
    return handle->maxsize;
}

