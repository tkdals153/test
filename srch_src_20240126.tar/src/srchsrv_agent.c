#include "srchsrv.h"
#include <sys/wait.h>
#include <pthread.h>

static struct linger linger;											/* linger option */	
static int agent_stop(void);											/* ������Ʈ ���� */
static void agent_usage(void);											/* ������Ʈ ���� */
static int ENGINE_PASS_THRU(int *engine_sock, int write_len, char *lpSrc, char *lpDst);/* ���� ������ ���� */
static int ENGINE_SOCK_SETTING(int *engine_sock, char *client_ip, unsigned short nServerPort);	/* �������� ���� ȯ�漳�� */
static void AGENT_SETT(void);											/* ������Ʈ ȯ�漳��      */
static void AGENT_STRT_SERVER(int bFork);								/* �������� ������Ʈ ���� */

void  AGENT_CONN_SERVER(void *c);										/* ������������ ��� ��� */
static void AGENT_SOCK_SETTING(unsigned short *nServerPort);			/* ������Ʈ ���� ���ϼ��� */


static unsigned short nPort,nPort2;										/* ���� ���� ��Ʈ */
char ipAddr2[32]={0};

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : main()
---------------------------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	if( argc > 1 && strcmp(argv[1], "-s") == 0 ) {
		STD_PRNT("Starting Online Socket Agent Server(Standalone Mode)");
		agent_stop();
		LOAD_CONFIG(argv[0], "srchsrv.conf"); AGENT_SETT();		
		AGENT_STRT_SERVER(0);
	} else if( argc > 1 && strcmp(argv[1], "stop") == 0 ) {
		agent_stop();
		exit(1);
	} else if( argc > 1 && strcmp(argv[1], "help") == 0 ) {
		agent_usage();
		exit(1);
	} else {
		agent_stop();
		STD_PRNT("Starting Online Socket Agent Server(Daemon Mode)");
		LOAD_CONFIG(argv[0], "srchsrv.conf"); AGENT_SETT();
		AGENT_STRT_SERVER(1);
	}
	
	ReleaseAllEnvironmentValue(pConfig);
	
	return 0;
}

static void agent_usage(void)
{
	printf("usage : srchsrv_agent [-s, stop, help]\n");
	
	printf("    default, start with daemon mode \n");
	printf("    -s, start with standalone mode\n");
	printf("    stop, halt the agent(kill process)\n");
	printf("    help, srchsrv_agent usage\n");
	
}

static int agent_stop(void)
{	
	FILE *t_file;
	char l_buf[BUFSIZ];
	const char *p_fname = "srchsrv_agent.pid";

	if((t_file = fopen(p_fname, "r")) == NULL) {
		printf("The agent is not running : pid file does not exists\n");
		perror(p_fname);
		return 0;
	}
			
	while(fgets(l_buf, BUFSIZ, t_file) != NULL) {
		printf("Kill the agent (%d)\n", atoi(l_buf));
		if(kill(atoi(l_buf), SIGKILL) !=0) {
			printf("pid : %d is not an agent process\n", atoi(l_buf));
			return 0;
		}
	}
	
	if((remove(p_fname)) !=0) {
		printf("srchsrv_agent does not have permission to remove pid file\n");
	}
	return 1;
	
	
}


/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �������� ������Ʈ ����
---------------------------------------------------------------------------------------------------*/
#if 1
static void AGENT_STRT_SERVER(int bFork)
{
	int client_sock;
	int retval,nTimeOut=3,len=0;
	int thr_id, i=0, status;
	pthread_t pid;
	fd_set read_fds;
	struct sockaddr_in client_addr;	/* �����ּ� ����ü */ 
	char clint_Ip[32];
	
	
	AGENT_SOCK_SETTING(&nPort); FD_ZERO(&read_fds);
	if( bFork ) { f_daemon(); write_pid("srchsrv_agent.pid"); }
	/*---------------------------------------------------------------------------------------------*/
	while(1) {		
		if( (client_sock = accept(server, (struct sockaddr *) &client_addr, &len)) == -1 ) 
			continue;	
		printf("AGENT SERVER ACCEPT\n");	
		sprintf(clint_Ip,"%s",inet_ntoa(client_addr.sin_addr));	
		if(strcmp(L4_IP,clint_Ip)!=0) {				
			FD_SET(client_sock, &read_fds);
			if(nTimeOut>=30){
				tv.tv_sec = nTimeOut / 1000;
	    		tv.tv_usec = (nTimeOut % 1000) * 1000;		
    		}
    		else{
    			tv.tv_sec = nTimeOut; tv.tv_usec = 0;
    		}			

			retval=select(client_sock+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
			if( retval == -1 ) {
				STD_PRNT("SERVER(retval == -1) : Socket Select Failed");
				shutdown(client_sock, SHUT_RD); shutdown(client_sock,SHUT_WR);	
				close(client_sock);
			}
			else if ( retval ) {
				/*AGENT_CONN_SERVER((void *)&client_sock);*/
				if(FD_ISSET(client_sock, &read_fds)) {		
					AGENT_CONN_SERVER((void *)&client_sock);					
				}
				else{
					STD_PRNT("FDSET ERROR\n");
					shutdown(client_sock, SHUT_RD); shutdown(client_sock,SHUT_WR);	
					close(client_sock);							     				
				}
			}
			else {
				STD_PRNT("AGENT SERVER(timeout) : No data within n seconds.");
				shutdown(client_sock, SHUT_RD); shutdown(client_sock,SHUT_WR);	
				close(client_sock);
			}
		}
		FD_CLR(client_sock,&read_fds);	
		FD_ZERO(&read_fds);	
	}
	/*---------------------------------------------------------------------------------------------*/
}
#else
static void AGENT_STRT_SERVER(int bFork)
{
	int client_sock;
	int retval;
	int thr_id, i=0, status;
	pthread_t pid;
	
	
	AGENT_SOCK_SETTING(&nPort);
	if( bFork ) { f_daemon(); write_pid("srchsrv_agent.pid"); }
	/*---------------------------------------------------------------------------------------------*/
	while(1) {
		if( (client_sock = accept(server, 0, 0)) > 0 ) {
			printf("Accepting new request\n");
#ifdef _N_THREAD			
			AGENT_CONN_SERVER((void *)&client_sock);
#else
			thr_id=pthread_create(&pid, 0, AGENT_CONN_SERVER, (void *)&client_sock);
			printf("Creating thread : %d\n", pid);
#endif
						
		} else if( retval == -1 ) {
			STD_PRNT("Socket Accept Failed");
		} else {
			/* STD_PRNT("SERVER(timeout) : No data within n seconds."); */
		}
	}
	/*---------------------------------------------------------------------------------------------*/
}
#endif
/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : ������������ ��� ���
---------------------------------------------------------------------------------------------------*/
void AGENT_CONN_SERVER(void *c)
{
	int client_sock;
	int engine_sock=0;
	int len=0, write_len=0;
	int write_clen=0;
	char *lpREAD, *lpWRITE, TmpBuf[512],TmpLog[READ_SIZ+12];

#ifndef _N_THREAD
	pthread_detach(pthread_self());
#endif
	lpREAD=(char*)calloc(sizeof(char), READ_SIZ);
	lpWRITE=(char*)calloc(sizeof(char), WRITE_SIZ);
	
	/*---------------------------------------------------------------------------------------------*/
	client_sock=*((int*)c);											/* client socket number */
	printf("AGENT SERVER : SOCK(%d):Connected\n", client_sock);
	len=read(client_sock, lpREAD, READ_SIZ); 	
	printf("[TIME:%s] AGENT SERVER : RECV(%d)\n", GET_TIME(0), len);
	
	sprintf(TmpLog,"[AGENT_LOG_IN]%s",lpREAD);
	LOGGER(TmpLog, 0);
	/*---------------------------------------------------------------------------------------------*/
	/* data recv */
	if( len > 0 ) {
		printf("[%s]", lpREAD); lpREAD[len]='\0';
		/* �������� ������ ���� */
		if( ENGINE_SOCK_SETTING(&engine_sock, "127.0.0.1", nPort) != 0 ) {
			/* ù��° ���� ������ ������ �ȵɶ� ����ȭ ������ ���������� ���� */
			sprintf(TmpBuf, "AGENT SERVER(ENGINE) : FAILOVER(%s:%d)", ipAddr2, nPort2); STD_PRNT(TmpBuf);
			
			if( ENGINE_SOCK_SETTING(&engine_sock, ipAddr2,nPort2 ) != 0 ) {
				
				shutdown(client_sock, SHUT_RDWR); close(client_sock);
				free(lpREAD); free(lpWRITE);
			#ifndef _N_THREAD			
				pthread_exit(0);
			#else
				return;
			#endif
			}			
		}
		/* printf("\nAGENT SERVER : Connected Engine"); */
		
	}
	/*---------------------------------------------------------------------------------------------*/
	/* no data */
	else if ( len == 0 ) {
		shutdown(client_sock, SHUT_RDWR); close(client_sock);
		free(lpREAD); free(lpWRITE);
		#ifndef _N_THREAD			
			pthread_exit(0);
		#else
			return;
		#endif
	}
	/*---------------------------------------------------------------------------------------------*/
	/* read error */
	else {
		shutdown(client_sock, SHUT_RDWR); close(client_sock);
		free(lpREAD); free(lpWRITE);
		#ifndef _N_THREAD			
			pthread_exit(0);
		#else
			return;
		#endif
	}	
	/*---------------------------------------------------------------------------------------------*/
	if( len > 0 ) {
		write_len=ENGINE_PASS_THRU(&engine_sock, len, lpREAD, lpWRITE);
		if( write_len > 0 ) {
			/* printf("\nAGENT SERVER(WRITE TO ENGINE) : READ(%d):[%s]", write_len, lpWRITE); */
			/* printf("\nAGENT SERVER(WRITE TO ENGINE) : CLIENT(%d)", client_sock); */
			write_clen=write(client_sock, lpWRITE, write_len);
			/* printf("\nAGENT SERVER(WRITE TO ENGINE) : WROTE(%d)\n", write_clen); */
		} else {
			printf("\nAGENT SERVER : Nothing to Send(%d)\n", write_len);
		}
		
	}
	/*---------------------------------------------------------------------------------------------*/
	shutdown(engine_sock, SHUT_RDWR); close(engine_sock);
	shutdown(client_sock, SHUT_RDWR); close(client_sock);
	printf("\n [TIME:%s] AGENT SERVER : SEND\n", GET_TIME(0));
	sprintf(TmpLog,"[AGENT_LOG_OUT]%s",lpWRITE);
	LOGGER(TmpLog, 0);
	
	free(lpREAD); free(lpWRITE);
	fflush(stdout);
	/*---------------------------------------------------------------------------------------------*/	
	#ifndef _N_THREAD			
		pthread_exit(0);
	#else
		return;
	#endif
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : ������ ���� ����
---------------------------------------------------------------------------------------------------*/
static int ENGINE_PASS_THRU(int *engine_sock, int write_len, char *lpSrc, char *lpDst)
{
	int len=0;
	
	/*---------------------------------------------------------------------------------------------*/
	/* Pass Thru to Engine */
	write(*engine_sock, lpSrc, write_len);		
	/* printf("\nAGENT SERVER(SEND TO ENGINE) : WRITE(%d):[%s]", write_len, lpSrc); */
	/*---------------------------------------------------------------------------------------------*/
	/* Read From Engine */
	len=socket_recv_all(*engine_sock, lpDst, READ_SIZ); 
	/* printf("\nAGENT SERVER(RECV FROM ENGINE) : READ(%d):[%s]\n", len, lpDst); */
	/*---------------------------------------------------------------------------------------------*/
	fflush(stdout);
	return len;
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �������� ���� ȯ�漳��
---------------------------------------------------------------------------------------------------*/	
static int ENGINE_SOCK_SETTING(int *engine_sock, char *client_ip, unsigned short nServerPort)
{
	char TmpBuf[128];
	struct sockaddr_in engine_svr;
	socklen_t engine_len;
	
	/*---------------------------------------------------------------------------------------------*/
	/* �������� ���� ���� */
	if( (*engine_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1 ) {
		STD_PRNT("AGENT SERVER(ENGINE) : Can't Create Server Socket"); return 1;
	} 
	/* printf("\nAGENT SERVER(%d) : %s %d", *engine_sock, client_ip, nServerPort); */
	
	engine_svr.sin_family = AF_INET;
	engine_svr.sin_addr.s_addr = inet_addr(client_ip);
	engine_svr.sin_port = htons(nServerPort);
	engine_len=sizeof(engine_svr);
	
	if(setsockopt(*engine_sock, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger)) < 0) {
		
	}	
	if(setsockopt(*engine_sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
		
	}
	if(setsockopt(*engine_sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
		
	}
	/* �������� ������ ���� */
	if (connect(*engine_sock, (struct sockaddr *)&engine_svr, engine_len) == -1 ) {
		sprintf(TmpBuf, "AGENT SERVER(ENGINE) : %s\n", strerror(errno)); STD_PRNT(TmpBuf);
		return 1;
	}
	return 0;
}


/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �������� ������Ʈ ȯ�漳��
---------------------------------------------------------------------------------------------------*/	
static void AGENT_SETT(void)
{
	char TmpBuf[128];
	
	/*--------------------------------------------------------------------------------------------*/
	/* �޸� �Ҵ� */
	STD_PRNT("Allocating Memory");
	GetEnvIniString( pConfig, "MEMORY", "socket_read", TmpBuf, sizeof(TmpBuf) ); READ_SIZ=atoi(TmpBuf);	
	GetEnvIniString( pConfig, "MEMORY", "socket_write", TmpBuf, sizeof(TmpBuf) ); WRITE_SIZ=atoi(TmpBuf);
	/* ���� �α� ���� */
	GetEnvIniString( pConfig, "LOGGING", "srchsrv_agent_log", TmpBuf, sizeof(TmpBuf) );
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.bNraLog=1;
		STD_PRNT("Agent Logging Enabled");	
	} else {
		slog.bNraLog=0;	
		STD_PRNT("Agent Logging Disabled");
	}
	
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �������� ������Ʈ ���� ����
---------------------------------------------------------------------------------------------------*/
static void AGENT_SOCK_SETTING(unsigned short *nServerPort)
{
	struct  sockaddr_in server_addr;	/* ���� ���� ���� */	
	unsigned short agPort=0;
	char TmpBuf[512];
	int  on=1;
	/*---------------------------------------------------------------------------------------------*/
	/* �������� ��Ʈ */
	GetEnvIniString(pConfig, "NETWORK", "port", TmpBuf, sizeof(TmpBuf) ); *nServerPort=(unsigned short)atoi(TmpBuf);
	if( *nServerPort == 0 ) {
		STD_PRNT("Please check the configure file (port)\n");
		ERR_EXIT("Socket Port is not set");
	}
	/*---------------------------------------------------------------------------------------------*/
	/* ��������2 ��Ʈ */
	GetEnvIniString(pConfig, "NETWORK", "port2", TmpBuf, sizeof(TmpBuf) ); nPort2=(unsigned short)atoi(TmpBuf);
	/*---------------------------------------------------------------------------------------------*/
	/* ������Ʈ ��Ʈ */
	GetEnvIniString(pConfig, "NETWORK", "agent_port", TmpBuf, sizeof(TmpBuf) ); agPort=(unsigned short)atoi(TmpBuf);
	if( agPort == 0 ) {
		STD_PRNT("Please check the configure file (agent_port)\n");
		ERR_EXIT("Agent Socket Port is not set");
	}
	/* �ι�° �������� ������ */
	GetEnvIniString(pConfig, "NETWORK", "ipaddr2", ipAddr2, sizeof(ipAddr2) ); 
	if( *ipAddr2 == 0 ) strcpy(ipAddr2, "127.0.0.1");
	/*---------------------------------------------------------------------------------------------*/
	/* ���� ���� */
	if( (server = socket(AF_INET, SOCK_STREAM, 0)) == 0 ) {
		STD_PRNT("Can't Create Server Socket\n");
		ERR_EXIT("Server Socket is 0");
	} 
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
    server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(agPort); 
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ���� */
	GetEnvIniString(pConfig, "NETWORK", "l_onoff", TmpBuf, sizeof(TmpBuf)); linger.l_onoff = atoi(TmpBuf);
	GetEnvIniString(pConfig, "NETWORK", "l_linger", TmpBuf, sizeof(TmpBuf)); linger.l_linger = atoi(TmpBuf);	
	
	if(setsockopt(server, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger)) < 0) {
		STD_PRNT("Socket configuration(SO_LINGER) not applied\n");
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� Ÿ�Ӿƿ� ���� */
	GetEnvIniString(pConfig, "NETWORK", "timeout", TmpBuf, sizeof(TmpBuf)); 

	if(atoi(TmpBuf)>=30){
		tv.tv_sec = atoi(TmpBuf) / 1000;
   		tv.tv_usec = (atoi(TmpBuf) % 1000) * 1000;		
	}
	else{
		tv.tv_sec = atoi(TmpBuf); tv.tv_usec = 0;	
	}

	if(setsockopt(server, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
		STD_PRNT("Socket configuration(SO_RCVTIMEO) not applied\n");
	}
	if(setsockopt(server, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
		STD_PRNT("Socket configuration(SO_SNDTIMEO) not applied\n");
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ���� ���� */
	GetEnvIniString(pConfig, "NETWORK", "socket_reuse", TmpBuf, sizeof(TmpBuf)); 
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		if(setsockopt(server, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0) {
			STD_PRNT("Socket Configuration Failed");
			close(server);
			ERR_EXIT("setsockopt(SO_REUSEADDR)");
		}
	}
	GetEnvIniString(pConfig, "NETWORK", "socket_reuse_port", TmpBuf, sizeof(TmpBuf)); 
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		if(setsockopt(server, SOL_SOCKET, SO_REUSEPORT, (char *)&on, sizeof(on)) < 0) {
			STD_PRNT("Socket Configuration Failed");
			close(server);
			ERR_EXIT("setsockopt(SO_REUSEPORT)");
		}
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ����ŷ ��� ���� */
	/* setNonBlockSock(server); */
	
	/*--------------------------------------------------------------------------------------------*/	
	/* ���� ���ε� */
	if( bind(server, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1 ) {
		STD_PRNT("Socket Binding Failed\n");
		sprintf(TmpBuf, "bind: %s", strerror(errno)); 
		ERR_EXIT(TmpBuf);
	}
	/*--------------------------------------------------------------------------------------------*/	
	/* ���� ������ */
	if( listen(server, SOMAXCONN) == -1 ) { 
		STD_PRNT("Socket Listening Failed\n");
		sprintf(TmpBuf, "listen: %s", strerror(errno)); 
		ERR_EXIT(TmpBuf);
	} else {
		STD_PRNT("==============================================");
		STD_PRNT(" Server Info ");
		STD_PRNT("----------------------------------------------");
		sprintf(TmpBuf, " ## AGENT  : 127.0.0.1:%d", agPort); STD_PRNT(TmpBuf);
		sprintf(TmpBuf, " #1 NRASRV Active Server : 127.0.0.1:%d", nPort); STD_PRNT(TmpBuf);
		if( nPort2 > 0 ) {
			sprintf(TmpBuf, " #2 NRASRV Standby Server : %s:%d\n", ipAddr2, nPort2); STD_PRNT(TmpBuf);
		} else STD_PRNT("  NRASRV Standby Server is NOT Available\n");
	}
	/*--------------------------------------------------------------------------------------------*/			
	client = server + 1; 
	GetEnvIniString(pConfig, "NETWORK", "L4_IP", L4_IP, sizeof(L4_IP) );

}
