/**
 * 2022.07.11 �˻����� ��Ƽ������ �ű� ���� ���
 * ���� ��Ƽ���μ��� ��忡�� ��� ��ְ� �߻��ϴ� ���� �־ ���� ������.
 * 
 * ���� ����
 * 1. ó�� �� ��⸦ ���� �۾�ť ����
 * 2. ��û ���� �� �۾������忡�� ó���� �� �ֵ��� ������Ǯ ����
 * 
 * ���ǻ���
 * POI_SPEED_UP2 TRUE Ȱ��ȭ�ؼ� ������ ���߾� ��Ƽ�����尡 ���װ� ������.
 * 
*/
#include "srchsrv.h"
#include "work_queue.h"
#include <pthread.h>
#include <signal.h>
#include <errno.h>
#ifdef _MT2_USE_EPOLL
#include <sys/epoll.h>
#endif

#define MT2_DEFAULT_THREAD_NUM  (4)
#define MT2_QUEUE_SIZE          (128)
#define MT2_MAX_THREAD_NUM      (100)
#define MT2_READ_BUF_BYTE       (1024)
#define MT2_WRITE_BUF_BYTE      (102400)
#define MT2_INTERVAL_NS_TO_US   (1000L)     /* 1us = 1000 Nanoseconds */
#define MT2_INTERVAL_NS_TO_MS   (10000000L) /* 10ms = 1,000,000 Nanoseconds */

/* ������ ���� ����ü ���� */
struct _WorkThreadParm {
    int nThreadID;
    char *pReadBuf;
    char *pWriteBuf;
    POI_INPUT *pInput;
    POI_RESULT *pResult;
};

/* �ʱ�ȭ */
static void MT2_Init(char *pnThread);
static void MT2_SOCK_SETTING();

/* �۾� ������ */
static void* Work_Thread(void *arg);
static void error_handling(char *buf);

/* ���� ó�� �Լ� */
static int RECV_CTL_MT2(int c, char *pRead, POI_INPUT *pInput, POI_RESULT *pResult, char *pWrite);
static int setnonblocking(int sockfd);

/* write ������ ����ȭ�� ���� �������� ���� */
static struct WorkQueue *g_WQ;
static fd_set g_reads;
static pthread_mutex_t g_mutex;
static int g_epoll_fd;
static int g_bDailyProcess = FALSE;

static enum eSrchRequestType {
    eCTL_SRCH_NORM = 0,
    eCTL_SRCH_WEB,
    eCTL_SRCH_TXT
};

#ifndef _MT2_USE_EPOLL /* select mode */
void Multi_Thread2(char *pnThread)
{
    /* �۾� ť ���� */
    int clnt_sock;
    struct sockaddr_in clnt_adr;
    socklen_t adr_sz;
    fd_set cpy_reads;
    int fd_max;
    struct timespec delta = {0, MT2_INTERVAL_NS_TO_MS};
    int i, bWQFull;
#ifdef MT2_DEBUG_PRINT            
    char szLogDbg[512] = {0,};
#endif

    /* ���� ���� => LISTEN */
    SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&g_reads);

    /* ���� ���� */
    f_daemon(); write_pid("srchsrv.pid");

    /* �����ͷε� / �۾������� ���� �� �ʱ�ȭ */
    g_WQ = WQ_Create(MT2_QUEUE_SIZE);
    MT2_Init(pnThread);

    /* change to non-blocking mode */
    setnonblocking(server);

    STD_PRNT("Multi_Thread2 mode start...");

    /* select loop ���� �۾�ť�� �о���̸� �� �����忡�� polling �Ͽ� �۾��� ��������. */
    while(1) {
        FD_ZERO(&g_reads);
        FD_SET(server, &g_reads);
        fd_max = server;
        cpy_reads = g_reads;

        if ( select(fd_max+1, &cpy_reads, NULL, NULL, NULL) == -1 ) {
            char szLog[128];
            sprintf(szLog,"Multi_Thread2: select() Error (errno: %d,%s)", errno, strerror(errno));
            STD_PRNT(szLog);
            nanosleep(&delta, 0);
            continue;
        }

        for ( i = 0; i < fd_max + 1; i++ ) {
            if ( FD_ISSET(i, &cpy_reads) ) {
                if ( i == server ) { /* connection request */
                    /*  �۾�ť�� �� á���� ���� �ź�. �۾��� �� ���ִٸ�
                        ���ʿ� accept�� ���� �ʰ� connect timeout�� �߰� ����� ���� ȿ�����ϰ��̰�,
                        accept�ϰ� write timeout�� ������ ����� ����ŷ�Ǿ� �ð��� ������ ������ ������. */
                    pthread_mutex_lock(&g_mutex);
                    bWQFull = WQ_IsFull(g_WQ);
                    pthread_mutex_unlock(&g_mutex);
                    if ( bWQFull == 1 ) {
                        STD_PRNT("Multi_Thread2: Request Blocked. (WorkQueue is full)");
                        nanosleep(&delta, 0);
                        continue;
                    }

                    pthread_mutex_lock(&g_mutex);
                    if ( g_bDailyProcess == TRUE ) {
                        pthread_mutex_unlock(&g_mutex);
                        STD_PRNT("Multi_Thread2: Request Blocked. (Daily Process is running...)");
                        nanosleep(&delta, 0);
                        continue;
                    } else {
                        pthread_mutex_unlock(&g_mutex);
                    }

                    adr_sz = sizeof(clnt_adr);
                    #ifdef _SCKOPT
                    if ( (clnt_sock = accept(server, 0, 0)) == -1 )
                    #else
                    if ( (clnt_sock = accept(server, (struct sockaddr*)&clnt_adr, &adr_sz)) == -1 )
                    #endif
                        break;

                    setnonblocking(client);

                    FD_SET(clnt_sock, &g_reads);
                    if ( fd_max < clnt_sock )
                        fd_max = clnt_sock;
                    
                    /* Ŭ���̾�Ʈ ������ �۾�ť�� �ֱ� */
                    pthread_mutex_lock(&g_mutex);
                    WQ_EnQueue(g_WQ, clnt_sock);
                    pthread_mutex_unlock(&g_mutex);

#ifdef MT2_DEBUG_PRINT
                    pthread_mutex_lock(&g_mutex);
                    sprintf(szLogDbg, "[DEBUG] work queue inserted (Queue Size: %d/%d)", WQ_GetCount(g_WQ), WQ_GetSize(g_WQ));
                    pthread_mutex_unlock(&g_mutex);
                    printf("%s\n", szLogDbg);
                    LOGGER(szLogDbg, 0);
#endif                    
                }
            }
        }
        nanosleep(&delta, 0);
    }
}
#else
void Multi_Thread2(char *pnThread)
{
    /* �۾� ť ���� */
    int client;
    struct sockaddr_in clnt_adr;
    socklen_t adr_sz;
    struct timespec delta = {0, MT2_INTERVAL_NS_TO_MS};
	
	struct epoll_event epEvt, *clntEvts;
	const int maxEvtCnt = 1024;
	int evtCnt=0, retval, i, bWQFull;
#ifdef MT2_DEBUG_PRINT
    char szLogDbg[512] = {0,};
#endif

    /* ���� ���� => LISTEN */
    SETT_ENGINE(1, 1); SOCK_SETTING();

    /* ���� ���� */
    f_daemon(); write_pid("srchsrv.pid");

    /* �����ͷε� / �۾������� ���� �� �ʱ�ȭ */
    g_WQ = WQ_Create(MT2_QUEUE_SIZE);
    MT2_Init(pnThread);

    /* change to non-blocking mode */
    setnonblocking(server);

    STD_PRNT("Multi_Thread2 epoll mode start...");

    clntEvts = (struct epoll_event*)calloc(maxEvtCnt,sizeof (struct epoll_event));

    g_epoll_fd = epoll_create(maxEvtCnt);
	if( g_epoll_fd < 0 )
        ERR_EXIT("epoll_create Error.");

    /*add server fd to epoll*/
	epEvt.events = EPOLLIN;
	epEvt.data.fd = server;
	retval = epoll_ctl(g_epoll_fd, EPOLL_CTL_ADD, server, &epEvt);
	if( retval < 0 ) {
        close(server);
        close(g_epoll_fd);
        ERR_EXIT("epoll_ctl init ADD error.");
        return;

    }

    /* select loop ���� �۾�ť�� �о���̸� �� �����忡�� polling �Ͽ� �۾��� ��������. */
    while(1) {
        evtCnt = epoll_wait(g_epoll_fd, clntEvts, maxEvtCnt, -1);
        if( evtCnt <= 0 ) continue;

#ifdef MT2_DEBUG_PRINT        
        printf("epoll evt raise!! -  evt cnt = [%d]\n", evtCnt);
#endif

        for( i = 0; i < evtCnt; ++i ) {
            if ( clntEvts[i].data.fd == server ) { /* connection request */
                struct epoll_event evt;

                /*  �۾�ť�� �� á���� ���� �ź�. �۾��� �� ���ִٸ�
                    ���ʿ� accept�� ���� �ʰ� connect timeout�� �߰� ����� ���� ȿ�����ϰ��̰�,
                    accept�ϰ� write timeout�� ������ ����� ����ŷ�Ǿ� �ð��� ������ ������ ������. */
                pthread_mutex_lock(&g_mutex);
                bWQFull = WQ_IsFull(g_WQ);
                pthread_mutex_unlock(&g_mutex);

                if ( bWQFull == 1 ) {
                    STD_PRNT("Multi_Thread2: Request Blocked. (WorkQueue is full)");
                    nanosleep(&delta, 0);
                    break;
                }
                
                pthread_mutex_lock(&g_mutex);
                if ( g_bDailyProcess == TRUE ) {
                    pthread_mutex_unlock(&g_mutex);
                    STD_PRNT("Multi_Thread2: Request Blocked. (Daily Process is running...)");
                    nanosleep(&delta, 0);
                    break;
                } else {
                    pthread_mutex_unlock(&g_mutex);
                }
                
                adr_sz = sizeof(clnt_adr);
                #ifdef _SCKOPT
                if ( (client = accept(server, 0, 0)) == -1 )
                #else
                if ( (client = accept(server, (struct sockaddr*)&clnt_adr, &adr_sz)) == -1 )
                #endif
                    break;

                setnonblocking(client);

                evt.events = EPOLLIN;
				evt.data.fd = client;
				retval = epoll_ctl(g_epoll_fd, EPOLL_CTL_ADD, client, &evt);
                if( retval < 0 ) {
					printf("epoll ctl error..\n");
					close(client);
				}

#ifdef MT2_DEBUG_PRINT
                printf("connected  client = [%d]\n", client);
#endif
            } else {
                int curClntSock = clntEvts[i].data.fd;
                if( curClntSock < 0 ) continue;	
                /* Ŭ���̾�Ʈ ������ �۾�ť�� �ֱ� */
                pthread_mutex_lock(&g_mutex);
                WQ_EnQueue(g_WQ, client);
                pthread_mutex_unlock(&g_mutex);
#ifdef MT2_DEBUG_PRINT
                pthread_mutex_lock(&g_mutex);
                sprintf(szLogDbg, "[DEBUG] work queue inserted (Queue Size: %d/%d)", WQ_GetCount(g_WQ), WQ_GetSize(g_WQ));
                pthread_mutex_unlock(&g_mutex);
                printf("%s\n", szLogDbg);
                LOGGER(szLogDbg, 0);
#endif   
            }
        }
        /*nanosleep(&delta, 0);*/
    }
}
#endif /* MT2_USE_EPOLL */

static void MT2_Init(char *pnThread)
{
    int nThread = 0;
    pthread_t *pArrThID[MT2_MAX_THREAD_NUM];
    struct _WorkThreadParm *pArrThParm;
    int i;

    pthread_mutex_init(&g_mutex, NULL);
    
    /* ������ �ʱ�ȭ */
    if ( pnThread != 0 && *pnThread != 0 )
        nThread = atoi(pnThread);

    if ( nThread <= 0 )
        nThread = MT2_DEFAULT_THREAD_NUM;
    if ( nThread > MT2_MAX_THREAD_NUM )
        nThread = MT2_MAX_THREAD_NUM;

    /* �Է� ���� ������ŭ �۾� ������ ���� */
    pArrThParm = (struct _WorkThreadParm*)calloc(nThread, sizeof(struct _WorkThreadParm));
    for ( i = 0; i < nThread; i++ ) {
        pArrThParm[i].nThreadID = i;
        pArrThParm[i].pReadBuf  = (char*)calloc(MT2_READ_BUF_BYTE, sizeof(char));
        pArrThParm[i].pWriteBuf = (char*)calloc(MT2_WRITE_BUF_BYTE, sizeof(char));
        pArrThParm[i].pInput   = (POI_INPUT*)calloc(1, sizeof(POI_INPUT));
        pArrThParm[i].pResult   = (POI_RESULT*)calloc(1, sizeof(POI_RESULT));
        
        if ( pthread_create(&pArrThParm[i].nThreadID, NULL, Work_Thread, (void *)&pArrThParm[i]) < 0 ) {
            ERR_EXIT("Work Thread Create Error");
        }
    }
    
    FD_ZERO(&g_reads);
}

/* ��Ƽ������ ���� ������ �Լ� */
static void* Work_Thread(void *arg)
{
    struct _WorkThreadParm *pTh = (struct _WorkThreadParm *)arg;
    static struct timespec delta = {0, MT2_INTERVAL_NS_TO_MS};
    static struct timespec delta_1us = {0, MT2_INTERVAL_NS_TO_US};
    int c, bWQEmpty;

    while(1) {
        /* �۾� ť ��� */
        pthread_mutex_lock(&g_mutex);
        bWQEmpty = WQ_IsEmpty(g_WQ);
        pthread_mutex_unlock(&g_mutex);
        if ( bWQEmpty ) {
            nanosleep(&delta, 0);
            continue;
        }

        /* �۾��� ������ ť���� ������ read & write �۾� */
        while ( 1 ) {
            pthread_mutex_lock(&g_mutex);
            c = WQ_DeQueue(g_WQ);
            pthread_mutex_unlock(&g_mutex);
            if ( c <= 0 ) break;
#ifdef MT2_DEBUG_PRINT
            char szLogDbg[1024];
            sprintf(szLogDbg, "[DEBUG] Thread #%d processing...(Queue Size: %d/%d)", pTh->nThreadID, WQ_GetCount(g_WQ), WQ_GetSize(g_WQ));
            printf("%s\n", szLogDbg);
            LOGGER(szLogDbg, 0);
#endif
		sigignore(SIGPIPE);
            RECV_CTL_MT2(c, pTh->pReadBuf, pTh->pInput, pTh->pResult, pTh->pWriteBuf);
            nanosleep(&delta_1us, 0);
        }


        nanosleep(&delta, 0);
    }
    return 0;
}

static void srch_sep_start_cnt(char *pRead, int *pnStart, int *pnCnt)
{
    char *s; int i, ret = 0;

    *pnStart = 0; *pnCnt = 0;
    s = strstr(pRead, "|");
    if ( !s ) return;
    *s = '\0';
    if ( *(s+1) != '\0' )
        *pnStart = atoi(s+1);
    s = strstr(s+1, "|");
    if ( !s ) return;
    if ( *(s+1) != '\0' )
        *pnCnt = atoi(s+1);
}

/* RECV_CTL ��Ƽ������ ���� (����� �������� �� Ư���� ������ó���� ���� ����.) */
static int RECV_CTL_MT2(int c, char *pRead, POI_INPUT *pInput, POI_RESULT *pResult, char *pWrite)
{
    int nLen, start, cnt, nCnt;
    enum eSrchRequestType eReqType = eCTL_SRCH_NORM;
    POISRV_ENV *ENV = POI_GetEnvNodeSet();
    static char *pOutRecData = NULL;
    bHealth=FALSE;

    if( pOutRecData == NULL ) pOutRecData = (char *)malloc(sizeof(char)*102400);	
    pOutRecData[0] = '\0';
    
    pRead[0] = '\0';
    nLen = read(c, pRead, MT2_READ_BUF_BYTE - 1);
    if ( nLen == 0 ) { /* close request */
#ifndef _MT2_USE_EPOLL
        FD_CLR(c, &g_reads);
#endif
        close(c);
        return 0;
    }
    else if ( nLen < 0 ) {
        char szLog[512];
        sprintf(szLog, "read() failed (errno: %d, %s)", errno, strerror(errno));
        STD_PRNT(szLog);
        close(c);
        return -1;
    }
    shutdown(c, SHUT_RD);

    if(slog.ndisplayLog!=1) {
	    printf("RECV(%d):\n", nLen);
	}

    pRead[nLen] = '\0';
    pWrite[0] = '\0';

    if(slog.ndisplayLog!=1){
		printf("=================== RECV DATA ====================\n");
		printf("SOCK(%d):Connected\n", c);
        printf("RECV(%d):\n", nLen);
        printf("[%s]\n", pRead);
	}

    memset(pInput, 0, sizeof(POI_INPUT));
    #if 1
    if ( strncmp(pRead, "#CTL:SRCH:TXT=", 14) == 0) {
        	eReqType = eCTL_SRCH_TXT;
		strcpy(pInput->szKeyWord, pRead + 14);
	} else
    #endif
	if ( strncmp(pRead, "#CTL:SRCH:WEB=", 14) == 0 ) {
        	eReqType = eCTL_SRCH_WEB;
		strcpy(pInput->szKeyWord, pRead + 14);
	}	
	else if( strncmp(pRead, "#CTL:SRCH:HTH=", 14) == 0 ) {
        /* ���ϸ� ���̱� ���� �ٷ� Ư�� ���ڿ� write */
#if 1   /* �ｺüũ Input/output error�� ���� ���� ��� ���� */
	  bHealth=TRUE;
        strcpy(pInput->szKeyWord, pRead + 14);
#else        
        strcpy(pWrite, "HTHOK");
        if ( write(c, pWrite, 5) == -1 ) {
            char szLog[512];
            sprintf(szLog, "[HEALTH_CHECK] write() failed (errno: %d, %s)", errno, strerror(errno));
            STD_PRNT(szLog);
            shutdown(c, SHUT_WR);
            close(c);
            return 1;
        }
        shutdown(c, SHUT_WR);
        close(c);
        return 1;
#endif
    }
    else if( (strncmp(pRead, "#CTL:DLY:ADD:", 13) == 0) 
          || (strncmp(pRead, "#CTL:DLY:MADD:", 14) == 0) ) {
        static struct timespec delta = {0, MT2_INTERVAL_NS_TO_MS};
        char TmpBuf[1024]={0,}, envpath[256]={0,};
        
        pthread_mutex_lock(&g_mutex);
        g_bDailyProcess = TRUE;
        pthread_mutex_unlock(&g_mutex);

        /* �ٸ� �۾� ���� ������ ��� */
        while ( !WQ_IsEmpty(g_WQ) )
            nanosleep(&delta, 0);

        /*sleep(3);*/
        strcpy(TmpBuf, g_szAbsPath);
		GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
		GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));
		if( *TmpBuf != 0 && *envpath != 0 ) {
			if( POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) == -1 ) {
				DAILY_LOGGER("[DAILY] Failed to Loading Daily Reference Data!\n\n"); 
			}
			else{
				sprintf(TmpBuf,"[DAILY] Loaded Daily Reference Data\n");
				DAILY_LOGGER(TmpBuf);
			}
		}
		else {
			DAILY_LOGGER("[DAILY] Please check the configure file");
			/*ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;*/
		}

        pthread_mutex_lock(&g_mutex);
        g_bDailyProcess = FALSE;
        pthread_mutex_unlock(&g_mutex);

        strcpy(pWrite, "SUCCESS");
        write(c, pWrite, 7);
        shutdown(c, SHUT_WR);
        close(c);
        return 1;
    } 
    else {
        strcpy(pInput->szKeyWord, pRead);
    }

    /* �˻� ������ �и� �� ó�� */
    srch_sep_start_cnt(pInput->szKeyWord, &start, &cnt);
    memset(pResult, 0, sizeof(POI_RESULT));
    /*printf("keyword=%s\n",pInput->szKeyWord);*/
    nCnt = SRCH_POI(pInput, pResult, start, cnt);
    nLen = 0;
    switch ( eReqType ) {
        #if 1
        case eCTL_SRCH_TXT:
			POI_MakeTxt(pResult, pOutRecData);
			#ifdef _HANA_SKCARD_
			sprintf(pWrite, "%06d%04d%s", strlen(pOutRecData)+4, nCnt, pOutRecData);
			#else
			sprintf(pWrite, "%06d%04d%04d%s", strlen(pOutRecData)+8, pResult->nHitCnt, nCnt, pOutRecData);
			#endif
			nLen = strlen(pWrite);
            break;
        #endif
        case eCTL_SRCH_WEB:
            nLen = POI_MakeXML_Len(pResult, &pWrite, ENV->ENC,"N","");
            break;
        case eCTL_SRCH_NORM:
        default: /* ��� ���� �˻� Ű���� ������ */
            nLen = POI_MakeXML(pResult, &pWrite, ENV->ENC);
            break;
    }
    
    if ( write(c, pWrite, nLen) == -1 ) {
        char szLog[512];
        sprintf(szLog, "Socket Write Error (errno: %d, %s)", errno, strerror(errno));
        STD_PRNT(szLog);
        return -1;
    }

    shutdown(c, SHUT_WR);
    close(c);

    if(slog.ndisplayLog!=1){
        printf("\nWRITE(%d):[%s]\n", nLen, pWrite);
        printf("\n============= End of OUTPUT ADR INFO =============\n\n");	
	}

    fflush(stdout);
    return 1;
}

static int setnonblocking(int sockfd)
{
	if (fcntl(sockfd, F_SETFD, fcntl(sockfd, F_GETFD, 0) | O_NONBLOCK) == -1) {
		return -1;
	}
	return 0;
}
