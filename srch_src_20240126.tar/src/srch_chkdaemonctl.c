#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#define f_name "srchchk.pid"
#define exe_file "./srchchk"

void print_useage(void);
int restart_zipit();
int process_start(void);
int process_stop(void);



int main(int argc, char *argv[])
{
	int _pStat;
	char tempbuf[64]={0};

	if(argc == 3)
	{
		if(strcmp(argv[2], "-l") == 0){
			strcat(exe_file, " -l");
		}
	}
	else if(argc == 5)	/* owner +  ���������̸� �����Է� */
	{
		if(strcmp(argv[2], "-n") == 0)	/* -n => process name expected */
		{	/* ��뿹�� : ./srchchkctl start -n owner nra_exename */
			sprintf(exe_file + strlen(exe_file), " -n %s %s", argv[3], argv[4]); /* �����̸� + ���������̸� */
		}
	}
		
	if(argc == 1)
	{
		print_useage();
		exit(0);
	}
	else if(strcmp(argv[1], "start") == 0)
	{
		_pStat = process_start();

		if(_pStat == 1)
		{
			printf("%s\n", "Now srchchk Process Start!!!");
			exit(0);
		}
		else if(_pStat == 2)
		{
			printf("%s\n", "srchchk process is Running or Previous srchchk process was Stopped Abnormally");
			exit(0);
		}
		else
		{
			printf("%s\n", "Failed To Start srchchk Process");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "stop") == 0)
	{
		if(process_stop())
		{
			printf("%s\n", "Now srchchk Process Stop!!");
			exit(0);
		}
		else
		{
			printf("%s\n", "Failed to stop srchchk Process!!");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "restart") == 0)
	{
		if(restart_zipit())
		{
			printf("%s\n", "Now srchchk Process restart!!");
			exit(0);	
		}	
		else
		{
			printf("%s\n", "Failed to restart srchchk process!!");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "kill") == 0){
		sprintf(tempbuf,"kill -9 `ps -ef | grep '%s' | egrep -v 'grep|vi|tail' | awk '{print $2}'`",exe_file);
		if(system(tempbuf) > 0 )		
			return 0;		
		else		
			return 1;		
	} 
	else
	{
		print_useage();
		exit(0);
	}
}
int restart_zipit()
{
	FILE *t_file; 

	if ((t_file = fopen(f_name, "r")) != NULL)
	{
		printf("%s\n", "Now srchchk Process is killed!!!");
		if ((process_stop()) == 0)
		{
			printf("%s\n", "Please First! Remove srchchkPid File");
			return -1;
		}
		printf("%s\n", "--------------------------------");
		printf("%s\n", "Now srchchk Process is Starting!!!");
		printf("%s\n", "--------------------------------");
		if ((process_start()) != 1)
		{
			return -1;
		}
		return 1;
	} else
	{
		printf("%s\n", "--------------------------------");
		printf("%s\n", "Now srchchk Process is Starting!!!");
		printf("%s\n", "--------------------------------");
		if (process_start() != 1)
		{
			return -1;
		}
		return 1;
	}
}

int process_start(void)
{
	FILE *t_file;
	
	printf("Wait for 5 seconds...\n");
	sleep(5);
	
	if((t_file = fopen(f_name, "r")) != NULL)
	{
		perror("Start Error!!");
		return 2;
	}
	else
	{
		printf("Starting process(%s)\n", exe_file);
		if(system(exe_file) > 0 )
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
}

int process_stop(void)
{
	FILE *t_file,*t_file2;
	char l_buf[BUFSIZ];
	const char *p_fname = f_name;
	
	if((t_file = fopen(f_name, "r")) == NULL)
	{
	
		exit(1);
	}
				
	while(fgets(l_buf, BUFSIZ, t_file) != NULL)
	{
		if(kill(atoi(l_buf),SIGKILL) !=0)
		{
			printf("%s %d %s\n", "PID : ", atoi(l_buf),"is not srchchk process");
		}
	}
		
	if((remove(p_fname)) !=0)
	{
		printf("%s\n", "You Have No Right to Remove srchchkPid");
	}
	
	return 1;
}

void print_useage(void)
{
	printf("Useage   : [command] [option]\n");
	printf("[OPTION] : \"start\", \"stop\", \"restart\"\n");
	printf("Example \n");
	printf("	srchchkctl start	   : srchchk process start!\n");
}	
