#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#define f_name "sDailyClient.pid"
char exe_file[64]={"./sDailyClint"};

void print_useage(void);
int process_start(void);
int process_stop(void);



int main(int argc, char *argv[])
{
	int _pStat;
	char tempbuf[64]={0};

	if(argc == 3)
	{
		if(strcmp(argv[2], "-l") == 0){
			strcat(exe_file, " -l");
		}
	}
	else if(argc == 5)	/* owner +  ���������̸� �����Է� */
	{
		if(strcmp(argv[2], "-n") == 0)	/* -n => process name expected */
		{	/* ��뿹�� : ./nraserverChecker start -n owner nra_exename */
			sprintf(exe_file + strlen(exe_file), " -n %s %s", argv[3], argv[4]); /* �����̸� + ���������̸� */
		}
	}
		
	if(argc == 1)
	{
		print_useage();
		exit(0);
	}
	else if(strcmp(argv[1], "start") == 0)
	{
		_pStat = process_start();

		if(_pStat == 1)
		{
			printf("%s\n", "Now sDailyClint Process Start!!!");
			exit(0);
		}
		else if(_pStat == 2)
		{
			printf("%s\n", "sDailyClint process is Running or Previous sDailyClint process was Stopped Abnormally");
			exit(0);
		}
		else
		{
			printf("%s\n", "Failed To Start sDailyClint Process");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "stop") == 0)
	{
		if(process_stop())
		{
			printf("%s\n", "Now sDailyClint Process Stop!!");
			exit(0);
		}
		else
		{
			printf("%s\n", "Failed to stop sDailyClint Process!!");
			exit(0);
		}
	}
	else if(strcmp(argv[1], "kill") == 0){
		sprintf(tempbuf,"kill -9 `ps -ef | grep '%s' | egrep -v 'grep|vi|tail' | awk '{print $2}'`",exe_file);
		if(system(tempbuf) > 0 )		
			return 0;		
		else		
			return 1;		
	}
	else
	{
		print_useage();
		exit(0);
	}
}


int process_start(void)
{
	FILE *t_file;
	
	printf("Wait for 5 seconds...\n");
	sleep(5);
	
	if((t_file = fopen(f_name, "r")) != NULL)
	{
		perror("Start Error!!");
		return 2;
	}
	else
	{
		printf("Starting process(%s)\n", exe_file);
		if(system(exe_file) > 0 )
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
}

int process_stop(void)
{
	FILE *t_file,*t_file2;
	char l_buf[BUFSIZ];
	const char *p_fname = f_name;
	
	if((t_file = fopen(f_name, "r")) == NULL)
	{
	
		exit(1);
	}
				
	while(fgets(l_buf, BUFSIZ, t_file) != NULL)
	{
		if(kill(atoi(l_buf),SIGKILL) !=0)
		{
			printf("%s %d %s\n", "PID : ", atoi(l_buf),"is not nrachk process");
		}
	}
		
	if((remove(p_fname)) !=0)
	{
		printf("%s\n", "You Have No Right to Remove sDailyClintPid");
	}
	
	return 1;
}

void print_useage(void)
{
	printf("Useage   : [command] [option]\n");
	printf("[OPTION] : \"start\", \"stop\" \n");
	printf("Example \n");
	printf("	sDailyClint start	   : sDailyClint process start!\n");
}	
