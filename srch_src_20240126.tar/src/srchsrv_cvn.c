/*==================================================================================================
 #���α׷��� : UNIX/LINUX ���� ���
 #���������� : �¶��� �ּ� ���� ���
==================================================================================================*/
#include "srchsrv.h"
#include "version.h"
#include <signal.h>

#include <pthread.h>
/*#include <setjmp.h>*/
#include <errno.h>

static POI_RESULT g_Result;

static void print_usage(void);			/* ���� ��� */
static void print_version(void);		/* �������� ��� */
char *pXML=0;							/* XML��� ���� */
int checkD[10];
char *OutRecData, *TmpLogBuf;
int socket_recv(int socket, char* buffer, int size,int SizeOfLen);

struct _ThreadSocketInfo *SocketArray;
void * Thread_server(struct _ThreadSocketInfo * threadInfo);
void Multi_Thread(char *mnum);
/*
void    sig_err2(int sig);
jmp_buf env;
void sig_err2(int sig)
{
	longjmp(env, 1);
}
*/
void handler(int sig);
void handler(int sig){
	printf("���޵� �ñ׳��� %d\n",sig);
}
/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : main()
---------------------------------------------------------------------------------------------------*/
#ifndef _LIB
int main(int argc, char *argv[])
{
	char TmpBuf[64];
	int bfork=1,state;
	struct 	sigaction sa;
	
	/*--------------------------------------------------------------------------------------------*/
	if( argc == 2 && ( strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "--version") == 0 ) ) {
		print_version();
		return 0;
	}
	
	CHK_PROCESS("srchsrv.pid");
	
	printf("\n---------------------------------------------------");
	printf("\nargc = %d\n", argc);
	printf("argv[0] = %s\n", argv[0]);
	printf("---------------------------------------------------\n");
	
	sa.sa_handler = handler;
  	sa.sa_flags = SA_NODEFER;
  	sigemptyset(&sa.sa_mask);
  	sigaddset(&sa.sa_mask,SIGPIPE);
  	/*sa.sa_restorer = NULL;*/
  	state=sigaction(SIGPIPE, &sa, NULL);
  	if(state != 0)  perror("sigaction Error\n");
	
	/*sa.sa_handler = sig_err2;
 	sa.sa_flags = SA_NODEFER | SA_NOCLDWAIT;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL);
  
	signal(SIGPIPE, SIG_IGN);*/
	sigignore(SIGPIPE);
	sigset(SIGPIPE,SIG_IGN);
	
	getFullPath(argv[0]);
	POI_GetEnvironment(g_szAbsPath, "srchsrv.conf", 1);
	LOAD_CONFIG(argv[0], "srchsrv.conf");
	/*--------------------------------------------------------------------------------------------*/
	/* Standalone Mode */
	if( argc > 1 && (strcmp(argv[1], "-s")==0 || strcmp(argv[1], "standalone")==0) ) {
		STD_PRNT("Starting Online Socket Server(Standalone Mode)"); bfork=0;
	} 
	/* Multi Process Mode */
	#ifdef _MP
	else if( argc > 1 && (strcmp(argv[1], "-pm")==0 || strcmp(argv[1], "pmulti")==0) ) {
		if(argv[2]==0)
		{
			STD_PRNT("���μ��������� �Է��ϼ���. ��)./nrasrv -pm 10\n");
			return 0;
		}			
		Multi_Main(argv[2],argv[3]);
		return 0;
	}
	/* Multi Process Mode */
	else if( argc > 1 && (strcmp(argv[1], "-m")==0 || strcmp(argv[1], "multi")==0) ) {
		MULTI_SERVER( bfork);
		return 0;
	}
	#endif
	else if( argc > 1 && strcmp(argv[1], "-mt")==0 ) {
		if(argv[2]==0)
		{
			STD_PRNT("������ ������ �Է��ϼ���. ��)./nrasrv -mt 10\n");
			return 0;
		}
		Multi_Thread(argv[2]);
		return 0;
	}
	/* Deamon Mode */
	else {
		STD_PRNT("Starting Online Socket Server(Daemon Mode)"); bfork=1;
	}
	
	STRT_SERVER(bfork);
	
	/*--------------------------------------------------------------------------------------------*/
	return 0;
}
#endif

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �˻����� ����
---------------------------------------------------------------------------------------------------*/
void STRT_SERVER(int bfork)
{
	int	retval, nTimeOut=3,len;
	fd_set read_fds;
	struct sockaddr_in client_addr;	/* �����ּ� ����ü */ 
	char clint_Ip[32];
	
	SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&read_fds); 
	nTimeOut=tv.tv_sec;

	if( bfork == 1 ) { f_daemon(); write_pid("srchsrv.pid"); }
	
	OutRecData = (char *)calloc(10240000, sizeof(char));	
	TmpLogBuf = (char *)calloc(10240000, sizeof(char));
	while(1) {		
		#ifdef _SCKOPT
		if( (client = accept(server, 0, 0)) == -1 ) 
		#else
		if( (client = accept(server, (struct sockaddr *) &client_addr, &len)) == -1 ) 
		#endif
			continue;				
		sprintf(clint_Ip,"%s",inet_ntoa(client_addr.sin_addr));			
		if(strcmp(L4_IP,clint_Ip)!=0) {				
			FD_SET(client, &read_fds);
			tv.tv_sec = nTimeOut; tv.tv_usec = 0;
			retval=select(client+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
			
			if( retval == -1 ) STD_PRNT("SERVER(retval == -1) : Socket Select Failed");
			else if ( retval ) {
				if(FD_ISSET(client, &read_fds)) {
					sigignore(SIGPIPE);
					RECV_CTL(client);
					/*
					if(!setjmp(env)){
						RECV_CTL(client);
					}
					else{				  
					  printf("Search Process Error!!\n");
					  STD_PRNT("Search Process Error!!");
					}
					*/
				}
			}
			else STD_PRNT("SERVER(timeout) : No data within n seconds.");
		}
		if( !saa.bAsync ) {
			shutdown(client, SHUT_RD); 
			shutdown(client,SHUT_WR);	/* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
			close(client);											/* Ŭ���̾�Ʈ ���� ���� */		
			FD_CLR(client,&read_fds);
		}
	}	
}


void Multi_Thread(char *mnum)
{
	int	retval, len,preThreadNum,i;
	fd_set read_fds;
	struct sockaddr_in client_addr;	/* �����ּ� ����ü */ 
	char clint_Ip[32];
	 
	
	SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&read_fds); 

	f_daemon(); write_pid("nrasrv.pid");
		
	preThreadNum = atoi(mnum);
	if(preThreadNum > 30) 
    { 
		fprintf(stderr,"Max preThreadNum is 30\n"); 
		exit(0); 
    }
    
    /* Socket Infomation Array */
    SocketArray = (void *)malloc(sizeof(struct _ThreadSocketInfo) * preThreadNum); 
    memset((void *)SocketArray, 0x00, sizeof(struct _ThreadSocketInfo) * preThreadNum); 
    
    /*--------------------------------------------------------------------------------------------*/
	for (i = 0; i < preThreadNum; i++) {
		pthread_create(&SocketArray[i].pid, 0, Thread_server, (struct _ThreadSocketInfo *)&SocketArray[i]);
		printf("Creating thread : %d\n", SocketArray[i].pid);
	}
	
	while(1) {
		#ifdef _SCKOPT
		if( (client = accept(server, 0, 0)) == -1 ) 
		#else
		if( (client = accept(server, (struct sockaddr *) &client_addr, &len)) == -1 ) 
		#endif
			continue;	
		for (i = 0; i < preThreadNum ; i++) {
			if(SocketArray[i].active==0){
				SocketArray[i].active=1;
				SocketArray[i].socknum=client;
				break;
			}
			if(i+1==preThreadNum){
				usleep(100);
				i=0;
			}
		}	
	
	}	
}

void * Thread_server(struct _ThreadSocketInfo * threadInfo)
{
	int	retval, nTimeOut=1;
	fd_set read_fds;
	
	nTimeOut=tv.tv_sec;
	pthread_detach(pthread_self());
	
	while(1){
		if(threadInfo->active==1){
			FD_SET(threadInfo->socknum, &read_fds);
			tv.tv_sec = nTimeOut; tv.tv_usec = 0;

			retval=select(threadInfo->socknum+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
					
			if( retval == -1 ) STD_PRNT("SERVER(retval == -1) : Socket Select Failed");
			else if ( retval ) {
				if(FD_ISSET(threadInfo->socknum, &read_fds)) 				
					RECV_CTL(threadInfo->socknum);
			}
			else STD_PRNT("SERVER(timeout) : No data within n seconds.");		
			
			shutdown(threadInfo->socknum, SHUT_RD); shutdown(threadInfo->socknum,SHUT_WR);	/* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
			close(threadInfo->socknum);											/* Ŭ���̾�Ʈ ���� ���� */
			FD_CLR(threadInfo->socknum,&read_fds);
			threadInfo->active=0;		
		}		
		usleep(10);
	}
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 :  ��� ����
 #��������		 :  0000000005NODAT			: �Է� ������ ����(L4 ����ġ heartbeat check)
 					0000000005ERROR			: ����READ ����
---------------------------------------------------------------------------------------------------*/
int RECV_CTL(int c)
{
	char *p=0, TmpBuf2[1024]={0}, TmpBuf[1024]={0}, envpath[256]={0},*checktime;
	int len=0, dstlen=0,chkeai=0,nReadB;
	char szBuf[16]={0},l_buf[1024]={0};
	int nTotByte, recv=0,rByte,i,j,k,nCnt;
	char READ[MAX_SOCK_LEN]={0}, WRITE[MAX_SOCK_LEN]={0};				/* ���� read����, write���� */
	char AckBuf[1024]={0},stime[10]={0},sjob[1024]={0},*pXml=0;
	FILE *file_sch,*file_in;
	POI_INPUT Input;
	POISRV_ENV	*ENV = POI_GetEnvNodeSet();
	/*--------------------------------------------------------------------------------------------*/
	
	if(slog.ndisplayLog!=1){
		printf("\n=================== RECV DATA ====================");
		printf("\nSOCK(%d):Connected", c); fflush(stdout);
	}	
	/*--------------------------------------------------------------------------------------------*/	
	len=read(c, READ, MAX_SOCK_LEN);  	
  if(len<0) printf("==read error\n");
	if( saa.bAsync ) close(c);
	if(slog.ndisplayLog!=1){
		printf("\nRECV(%d):", len);	
	}	
	/*--------------------------------------------------------------------------------------------*/
	/* �ϰ��� üũ ���� */
	if( IFSE("#CTL:DLY:ADD:", READ) != 0 ) {
		strcpy(TmpBuf, g_szAbsPath);
		GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
		GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));
		if( *TmpBuf != 0 && *envpath != 0 ) {
			/*sprintf(TmpBuf2, "RefData : %s", TmpBuf); STD_PRNT(TmpBuf2);
			sprintf(TmpBuf2, "EnvPath : %s\n", envpath); STD_PRNT(TmpBuf2);	*/	
			if( POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) == -1 ) {
				DAILY_LOGGER("[DAILY] Failed to Loading Daily Reference Data!\n\n"); 
			}
			else{
				sprintf(TmpLogBuf,"[DAILY] Loaded Daily Reference Data\n");
				DAILY_LOGGER(TmpLogBuf);
			}
		}
		else {
			DAILY_LOGGER("[DAILY] Please check the configure file");
			ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;
		}
		strcpy(WRITE, "SUCCESS"); p=WRITE;
		dstlen=strlen(WRITE);
		if(write(c, p, dstlen)<=0){			
			DAILY_LOGGER("[DAILY] Socket Write Error");
		}
		
		return 1;
	}
	/*--------------------------------------------------------------------------------------------*/
	/* data recv */
	if( len > 0 ) {
		if(slog.ndisplayLog!=1){
			printf("[%s]\n", READ); 
		}
		READ[len]='\0'; 	
		LOGGER(READ, 1);
		
		if (IFSE("#CTL:SRCH:TXT=", READ) != 0) {
			strcpy(szBuf, "#CTL:SRCH:TXT=");
			strcpy_u(READ, READ + 14);
		}	
		else if (IFSE("#CTL:SRCH:WEB=", READ) != 0) {
			strcpy(szBuf, "#CTL:SRCH:WEB=");
			strcpy_u(READ, READ + 14);
		}
		
		memset(&Input, 0, sizeof(Input)); strcpy(Input.szKeyWord, READ);
		nCnt=SRCH_POI(&Input, &g_Result);
		
		if (szBuf[0] != 0 && IFSE("#CTL:SRCH:TXT=", szBuf) != 0) {
			OutRecData[0] = 0; 
			pXml = (char *)calloc(10240000, sizeof(char));			
			POI_MakeTxt(&g_Result, OutRecData);
			sprintf(pXml, "%06d%04d%s", strlen(OutRecData), nCnt, OutRecData);
			if (pXml != 0)	dstlen = strlen(pXml);				
		}
		else if (szBuf[0] != 0 && IFSE("#CTL:SRCH:WEB=", szBuf) != 0) {
			POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC);
			if (pXml != 0)	dstlen = strlen(pXml);			
		}
		else{
		  POI_MakeXML(&g_Result, &pXml, ENV->ENC);	
		  /*POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC);*/			
		  if(pXml!=0)	dstlen=strlen(pXml);		  
		}
	} 
	/* no data */
	else if ( len == 0 ) {
		strcpy(WRITE, "0000000005NODAT"); p=WRITE;
		dstlen=-1;
	} 
	/* read error */
	else if( len < 0 ) {
		strcpy(WRITE, "0000000005ERROR"); p=WRITE;
		STD_PRNT(WRITE);
	}
	/*--------------------------------------------------------------------------------------------*/
	if( len > 0 ) {
		if( !saa.bAsync ) {	
			if(write(c, pXml, dstlen)<=0){
				sprintf(TmpLogBuf,"Socket Write Error:%s",pXml);
				STD_PRNT(TmpLogBuf);
				sprintf(TmpLogBuf,"errno=%s\n",strerror(errno));
		  		STD_PRNT(TmpLogBuf);
				LOGGER("Socket Write Error", 0);
			}
			else	LOGGER("Socket Write OK", 0);
		}
		else RECV_ASYNC_CTL(pXml, dstlen);
		
		LOGGER(pXml, 0);
		if(slog.ndisplayLog!=1){
			printf("\nWRITE(%d):[%s]\n", dstlen, pXml);
		}
	}	
	if( pXml != 0 ) { free(pXml); pXml=0; }
	/*--------------------------------------------------------------------------------------------*/	
	if(slog.ndisplayLog!=1){
		printf("\n============= End of OUTPUT ADR INFO =============\n\n");	
	}
	fflush(stdout);
	return dstlen;
}

int RECV_ASYNC_CTL(char *writebuf, int dstlen)
{
	int sock=0, len;
	
	if( writebuf == 0 || dstlen == 0 ) return 0;
	/*--------------------------------------------------------------------------------------------*/
	printf("Connecting %s:%d\n", saa.szDstIP, saa.nPort);
	
	if( (sock=connect_svr(saa.szDstIP, saa.nPort)) > 0 ) {
		len=write(sock, writebuf, dstlen);
		if( len < 0 ) len=write(sock, writebuf, dstlen);
		
	} else {
		printf("Connection Failed\n");
	}
	/*--------------------------------------------------------------------------------------------*/
	disconnect_svr(sock);
}


/*------------------------------------------------------------------------------------------------*/
/* ���� �������� ���                                                                             */
/*------------------------------------------------------------------------------------------------*/
static void print_version(void)
{	
	printf("%s %s\n", PROGRAM_NAME, VERSION_INFO);
	printf("Revision : %s\n\n", REVISION_INFO);
	printf("Copyright (c) SujiewonNetSoft. All rights reserved.\n");
}

int socket_recv(int socket, char* buffer, int size,int SizeOfLen)
{
	int total_received;
	int received,rtotcnt;
	char tmpSize[11];
	memset(tmpSize,0,11);
	assert(buffer);
	assert(size > 0);
	total_received = 0;
	while(size){
		received = read(socket, buffer, size);
		printf("[%s]\n\n", buffer);		
		if(tmpSize[0]==0){
			strnzcpy(tmpSize,buffer,SizeOfLen);
			rtotcnt=atoi(tmpSize);
		} 	
		/* ���ϰ��� = 0 �̸� close�Ǿ����� �ǹ�
		   ���ϰ��� < 0 �̸� ���� �߻��� �ǹ�
		*/
		if(received <= 0) break;
		total_received += received;
		size -= received;
		buffer += received;
		if(rtotcnt <= total_received)
		 break;
		printf("rtotcnt[%d]total_received[%d]\n\n", rtotcnt,total_received);
	}
	return received > 0 ? total_received : received;
}
