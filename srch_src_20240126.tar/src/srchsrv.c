/*==================================================================================================
 #���α׷��� : UNIX/LINUX ���� ���
 #���������� : �¶��� �ּ� ���� ���
==================================================================================================*/
#include "srchsrv.h"
#include "version.h"
#include "company.h"
#include <signal.h>

#include <pthread.h>
#include <setjmp.h>
#include <errno.h>
#include <fcntl.h>

static void print_usage(void);			/* ���� ��� */
static void print_version(void);		/* �������� ��� */
int checkD[10];
int socket_recv(int socket, char* buffer, int size,int SizeOfLen);

struct _ThreadSocketInfo *SocketArray;
void * Thread_server(struct _ThreadSocketInfo * threadInfo);
void Multi_Thread(char *mnum);

void    sig_err2(int sig);
jmp_buf env;
void sig_err2(int sig)
{
	longjmp(env, 1);
}
void handler(int sig);
void handler(int sig){
	printf("���޵� �ñ׳��� %d\n",sig);
}
static int check_if_process_exist(char *pszName);
/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : main()
---------------------------------------------------------------------------------------------------*/
#ifndef _LIB
int main(int argc, char *argv[])
{
	char TmpBuf[64];
	int bfork=1,state;
	struct 	sigaction sa;
	const char *pszPgmName = "srchsrv";
	
	/*--------------------------------------------------------------------------------------------*/
	if( argc == 2 && ( strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "--version") == 0 ) ) {
		print_version();
		return 0;
	}
	/*if ( check_if_process_exist(pszPgmName) == 1 ) {
		printf("%s already running... exit process.\n", pszPgmName);
		exit(-1);
	}*/
	
	CHK_PROCESS("srchsrv.pid");
	
	printf("\n---------------------------------------------------");
	printf("\nargc = %d\n", argc);
	printf("argv[0] = %s\n", argv[0]);
	printf("---------------------------------------------------\n");
	
	/*sa.sa_handler = handler;
  	sa.sa_flags = 0;
  	sigemptyset(&sa.sa_mask);*/
  	/*sa.sa_restorer = NULL;*/
  	/*state=sigaction(SIGPIPE, &sa, NULL);
  	if(state != 0)  perror("sigaction Error\n");*/
	
	sa.sa_handler = sig_err2;
 	sa.sa_flags = SA_NODEFER ;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL);
  
	/*signal(SIGPIPE, SIG_IGN);
	sigignore(SIGPIPE);
	sigset(SIGPIPE,SIG_IGN);
	*/	
	getFullPath(argv[0]);
	POI_GetEnvironment(g_szAbsPath, "srchsrv.conf", 1);
	LOAD_CONFIG(argv[0], "srchsrv.conf");
	/*--------------------------------------------------------------------------------------------*/
	/* Standalone Mode */
	if( argc > 1 && (strcmp(argv[1], "-s")==0 || strcmp(argv[1], "standalone")==0) ) {
		STD_PRNT("Starting Online Socket Server(Standalone Mode)"); bfork=0;
	} 
	/* Multi Process Mode */
	#ifdef _MP
	else if( argc > 1 && (strcmp(argv[1], "-pm")==0 || strcmp(argv[1], "pmulti")==0) ) {
		if(argv[2]==0)
		{
			STD_PRNT("���μ��������� �Է��ϼ���. ��)./nrasrv -pm 10\n");
			return 0;
		}			
		Multi_Main(argv[2],argv[3]);
		return 0;
	}
	/* Multi Process Mode */
	else if( argc > 1 && (strcmp(argv[1], "-m")==0 || strcmp(argv[1], "multi")==0) ) {
		MULTI_SERVER( bfork);
		return 0;
	}
	#endif
	else if( argc > 1 && strcmp(argv[1], "-mt")==0 ) {
		if(argv[2]==0)
		{
			STD_PRNT("������ ������ �Է��ϼ���. ��)./nrasrv -mt 10\n");
			return 0;
		}
		Multi_Thread(argv[2]);
		return 0;
	}
	else if( argc > 1 && strcmp(argv[1], "-mt2")==0 ) {
		if(argv[2]==0)
		{
			STD_PRNT("������ ������ �Է��ϼ���. ��)./nrasrv -mt2 4\n");
			return 0;
		}
		Multi_Thread2(argv[2]);
		return 0;
	}
	/* Deamon Mode */
	else {
		STD_PRNT("Starting Online Socket Server(Daemon Mode)"); bfork=1;
	}
	
	STRT_SERVER(bfork);
	
	/*--------------------------------------------------------------------------------------------*/
	return 0;
}
#endif

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 : �˻����� ����
---------------------------------------------------------------------------------------------------*/
void STRT_SERVER(int bfork)
{
	int	retval, nTimeOutS=3,nTimeOutU=0,len,tcnt=0;
	fd_set read_fds;
	struct sockaddr_in client_addr;	/* �����ּ� ����ü */ 
	char clint_Ip[32];
	
	SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&read_fds); 
	nTimeOutS=tv.tv_sec;
	nTimeOutU=tv.tv_usec;

	if( bfork == 1 ) { f_daemon(); write_pid("srchsrv.pid"); }
	
	while(1) {		
	  len=sizeof(client_addr);
		#ifdef _SCKOPT
		if( (client = accept(server, 0, 0)) == -1 ) 
		#else
		if( (client = accept(server, (struct sockaddr *) &client_addr, &len)) == -1 ) 
		#endif
			continue;				
		sprintf(clint_Ip,"%s",inet_ntoa(client_addr.sin_addr));			
		if(strcmp(L4_IP,clint_Ip)!=0) {				
			FD_SET(client, &read_fds);
			tv.tv_sec = nTimeOutS; tv.tv_usec = nTimeOutU;    			
			
			retval=select(client+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
			
			if( retval == -1 ) STD_PRNT("SERVER(retval == -1) : Socket Select Failed");
			else if ( retval ) {
				if(FD_ISSET(client, &read_fds)) {
					/*RECV_CTL(client);*/
					
					if(!setjmp(env)){
						sigignore(SIGPIPE);
						RECV_CTL(client);
					}
					else{				  
					  printf("Search Process Error!!\n");
					  STD_PRNT("Search Process Error!!");
					}					
				}
				else{
					printf("Read signal Error!!\n");
				    STD_PRNT("Read signal Error!!");
				}
			}
			else STD_PRNT("SERVER(timeout) : No data within n seconds.");
		}
		/*if( !saa.bAsync ) {*/
			shutdown(client, SHUT_RD); 
			shutdown(client,SHUT_WR);	/* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
			close(client);											/* Ŭ���̾�Ʈ ���� ���� */		
			FD_CLR(client,&read_fds);			
		/*}*/
	}	
}


void Multi_Thread(char *mnum)
{
	int	retval, len,preThreadNum,i;
	fd_set read_fds;
	struct sockaddr_in client_addr;	/* �����ּ� ����ü */ 
	char clint_Ip[32];
	
	SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&read_fds); 

	f_daemon(); write_pid("srchsrv.pid");
	preThreadNum = atoi(mnum);
	if(preThreadNum > 600) 
    { 
		fprintf(stderr,"Max preThreadNum is 600\n"); 
		exit(0); 
    }
    
    /* Socket Infomation Array */
    SocketArray = (void *)malloc(sizeof(struct _ThreadSocketInfo) * preThreadNum); 
    memset((void *)SocketArray, 0x00, sizeof(struct _ThreadSocketInfo) * preThreadNum); 
    
    /*--------------------------------------------------------------------------------------------*/
	for (i = 0; i < preThreadNum; i++) {
		pthread_create(&SocketArray[i].pid, 0, Thread_server, (struct _ThreadSocketInfo *)&SocketArray[i]);
		printf("Creating thread : %d\n", SocketArray[i].pid);
	}
	
	while(1) {
		#ifdef _SCKOPT
		if( (client = accept(server, 0, 0)) == -1 ) 
		#else
		if( (client = accept(server, (struct sockaddr *) &client_addr, &len)) == -1 ) 
		#endif
			continue;	
		for (i = 0; i < preThreadNum ; i++) {
			if(SocketArray[i].active==0){
				SocketArray[i].active=1;
				SocketArray[i].socknum=client;
				break;
			}
			if(i+1==preThreadNum){
				usleep(100);
				i=0;
			}
		}	
	
	}	
}

void * Thread_server(struct _ThreadSocketInfo * threadInfo)
{
	int	retval, nTimeOut=1,chk=0;
	fd_set read_fds;
	
	nTimeOut=tv.tv_sec;
	pthread_detach(pthread_self());
	
	while(1){
		if(threadInfo->active==1){
			FD_SET(threadInfo->socknum, &read_fds);
			tv.tv_sec = nTimeOut; tv.tv_usec = 0;

			#ifdef _KBST_
			retval=select(threadInfo->socknum+1, &read_fds, (fd_set *)0, (fd_set *)0, NULL);
			#else
			retval=select(threadInfo->socknum+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
			#endif
					
			if( retval == -1 ) STD_PRNT("SERVER(retval == -1) : Socket Select Failed");
			else if ( retval ) {
				if(FD_ISSET(threadInfo->socknum, &read_fds)) 				
					chk=RECV_CTL(threadInfo->socknum);
			}
			else STD_PRNT("SERVER(timeout) : No data within n seconds.");		
			
			#ifdef _KBST_
			if(chk==-1){
				shutdown(threadInfo->socknum, SHUT_RD); shutdown(threadInfo->socknum,SHUT_WR);	/* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
				close(threadInfo->socknum);											/* Ŭ���̾�Ʈ ���� ���� */			
				threadInfo->active=0;	
			}
			#else	
				shutdown(threadInfo->socknum, SHUT_RD); shutdown(threadInfo->socknum,SHUT_WR);	/* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
				close(threadInfo->socknum);											/* Ŭ���̾�Ʈ ���� ���� */			
				threadInfo->active=0;
			#endif			
			FD_CLR(threadInfo->socknum,&read_fds);
		}		
		usleep(10000);
	}
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���		 :  ��� ����
 #��������		 :  0000000005NODAT			: �Է� ������ ����(L4 ����ġ heartbeat check)
 					0000000005ERROR			: ����READ ����
---------------------------------------------------------------------------------------------------*/
int RECV_CTL(int c)
{
	char *p=0, TmpBuf2[1024]={0,}, TmpBuf[1024]={0,}, envpath[256]={0,},*checktime;
	int len=0, dstlen=0,chkeai=0,nReadB=0,TmpLen=0,wlen=0;
	char szBuf[32]={0,},l_buf[1024]={0,},tmp1[8]={0,},tmp2[8]={0,},TmpReqTime[32]={0};
	int nTotByte=0, recv=0,rByte=0,i,j,k,nCnt=0;
	char READ[MAX_SOCK_LEN]={0,}, WRITE[MAX_SOCK_LEN]={0,},TmpRead[128]={0,};	/* ���� read����, write���� */
	char AckBuf[1024]={0,},stime[10]={0,},sjob[1024]={0,},TmpLenth[8]={0,};
	FILE *file_sch, *file_in;
	POI_INPUT Input = {0,};
	/*struct flock filestate;*/
	/*int stat_flags,*/
	int start=1,cnt=0;
    /*int access_flags;*/
    SEPFLD ss = {0,};
    /*SRCHDAT srchdata[1000] = {0,};*/
	srch_outRec srchOut = {0,};
	pthread_t pid = 0;
	/* 2020.12.07: �Ź� RECV�� ������ �޸� Alloc���� �ʵ��� ��. (�ӵ� ������ ����.) */
	static char *OutRecData = NULL, *TmpLogBuf = NULL, *pXml = NULL;
	POI_RESULT g_Result = {0,};
	#ifdef _HKTCPTL
	cJSON *pJSON = 0; char *pJSONRequest = 0;
	#endif
    
	POISRV_ENV	*ENV = POI_GetEnvNodeSet();
	bHealth=FALSE;
	
	if( OutRecData == NULL ) OutRecData = (char *)malloc(sizeof(char)*1024000);	
	OutRecData[0] = '\0';
	if( TmpLogBuf == NULL ) TmpLogBuf = (char *)malloc(sizeof(char)*1024000);
	TmpLogBuf[0] = '\0';
	if ( pXml == NULL ) pXml = (char *)malloc(sizeof(char)*1024000);
	pXml[0] = '\0';
	/*--------------------------------------------------------------------------------------------*/
	if(slog.ndisplayLog!=1){
		printf("=================== RECV DATA ====================\n");
		printf("SOCK(%d):Connected\n", c); fflush(stdout);
	}	
	/*--------------------------------------------------------------------------------------------*/	
	#ifdef _KBST_
	len=read(c, READ, 219);  
	#else
	len=read(c, READ, MAX_SOCK_LEN);  
	#endif
	/* 2020.12.10: CLOSE_WAIT ������� �ʴ� �������� ���� half close �ϵ��� ��.
	(�̸� read stream�� �ݾƼ� �˻� �� sendó�� �� close ���� ������ �߻��ص� 
	CLOSE_WAIT ������� �ʴ� ������ �߻����� �ʵ��� �����ϴ� �ڵ�) */
	#ifndef _KBST_
	shutdown(c, SHUT_RD);
	#endif

	/*if(len<0) printf("==read error\n");*/
	if( saa.bAsync ) close(c);
	if(slog.ndisplayLog!=1){
		printf("RECV(%d):\n", len);
	}
	if(strncmp(	"-KILL",READ,5)==0) {
		printf("KILLED\n");
		exit(1);
	}
	/*--------------------------------------------------------------------------------------------*/
	if( strstr(READ,"JUSO01") != 0 && len==30 ) {
		strncpy(tmp1,READ+6,6);
		strncpy(tmp2,READ+12,6);
	
		strncpy(READ+6,tmp2,6);
		strncpy(READ+12,tmp1,6);
        strncpy(READ+5,"S",1);	    
		sprintf(WRITE,"00031%sSK    ",READ+5);	
		p=WRITE;
		dstlen=strlen(WRITE);
		
		LOGGER("[1]Init-Socket Write=", 0);
		LOGGER(WRITE, 0);
		
		if((wlen=write(c, p, dstlen))<=0){			
			LOGGER("Init-Socket Write Error", 0);
		}
		/*test*/
        sprintf(WRITE,"00031%sSC    ",READ+5);
        /*real*/
		/*sprintf(WRITE,"00031%sSA    ",READ+5);*/
        p=WRITE;
        dstlen=strlen(WRITE);
        
        LOGGER("[2]Init-Socket Write=", 0);
		LOGGER(WRITE, 0);
		
        if((wlen=write(c, p, dstlen))<=0){
           LOGGER("Init-Socket Write Error", 0);
        }
		return dstlen;
	}	
	/*--------------------------------------------------------------------------------------------*/
	/* �ϰ��� üũ ���� - �̱����μ����� */
	if( IFSE("#CTL:DLY:ADD:", READ) != 0 ) {		
		/*pthread_create(&pid, 0, RECV_CTL_DAILY, (void *)0);*/	
		
		strcpy(TmpBuf, g_szAbsPath);
		GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
		GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));
		if( *TmpBuf != 0 && *envpath != 0 ) {
			if( POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) == -1 ) {
				DAILY_LOGGER("[DAILY] Failed to Loading Daily Reference Data!\n\n"); 
			}
			else{
				sprintf(TmpLogBuf,"[DAILY] Loaded Daily Reference Data\n");
				DAILY_LOGGER(TmpLogBuf);
			}
		}
		else {
			DAILY_LOGGER("[DAILY] Please check the configure file");
			ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;
		}
		strcpy(WRITE, "SUCCESS"); p=WRITE;
		dstlen=strlen(WRITE);
		if(write(c, p, dstlen)<=0){			
			DAILY_LOGGER("[DAILY] Socket Write Error");
		}
		return 1;
	}	
	/*--------------------------------------------------------------------------------------------*/
	/* �ϰ��� üũ ���� - ��Ƽ���μ����� */
	if( IFSE("#CTL:DLY:MADD:", READ) != 0 ) {

		/* ��Ƽ �ϰ�� �ϰ��� �ݿ� */
		strcpy(WRITE, "SUCCESS"); p=WRITE;
		dstlen=strlen(WRITE);
		if(write(c, p, dstlen)<=0){			
			DAILY_LOGGER("[DAILY] Socket Write Error");
		}
		return 4321;
		/*
		strcpy(TmpBuf, g_szAbsPath);
		GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
		GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));
		if( *TmpBuf != 0 && *envpath != 0 ) {			
			POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) ;
		}
		else {			
			ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;
		}
		strcpy(WRITE, "SUCCESS"); p=WRITE;
		dstlen=strlen(WRITE);
		if(write(c, p, dstlen)<=0){			
			DAILY_LOGGER("[DAILY] Socket Write Error");
		}
		
		return 1;
		*/
	}
	/*--------------------------------------------------------------------------------------------*/
	/* �ϰ��� üũ ���� - �̱����μ����� (������Ʈ �ڵ�ȭ �ַ�ǿ�) */
	if( IFSE("#CTL:ILGOSI=", READ) != 0 ) {		
		/*�ϰ��� �ݿ� ���� ó��*/
		const char * pREQ = "OK:";
		strcpy(TmpBuf, g_szAbsPath);
		GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
		GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));		
		if( *TmpBuf != 0 && *envpath != 0 ) {
			if( POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) == -1 ) {
				pREQ = "FAIL:";
				DAILY_LOGGER("[DAILY] Failed to Loading Daily Reference Data!\n\n");
			}
			else{
				sprintf(TmpLogBuf,"[DAILY] Loaded Daily Reference Data\n");
				DAILY_LOGGER(TmpLogBuf);
			}
		}
		write(c, pREQ, strlen(pREQ));
		return 1;
	}
	/*--------------------------------------------------------------------------------------------*/
	/* data recv */
	if( len > 0 ) {
		if(slog.ndisplayLog!=1){
			printf("[%s]\n", READ);
			#ifdef _KBST_
            printf("[%s]\n", READ+40); 
            #endif
		}
		READ[len]='\0';
		if( IFSE("#CTL:SRCH:HTH=", READ) == 0 )
			LOGGER(READ, 1);
		
		if (IFSE("#CTL:SRCH:TXT=", READ) != 0) {
			strcpy(szBuf, "#CTL:SRCH:TXT=");
			strcpy_u(READ, READ + 14);
		}	
		else if (IFSE("#CTL:SRCH:WEB=", READ) != 0) {
			strcpy(szBuf, "#CTL:SRCH:WEB=");
			#ifdef _KBBANK_FN
			strncpy(TmpReqTime,READ + 14,14);
			strcpy_u(READ, READ + 28);
			#else
			strcpy_u(READ, READ + 14);
			#endif
		}	
		else if( IFSE("#CTL:SRCH:HTH=", READ) != 0 ) {
			bHealth=TRUE;
			strcpy(szBuf, "#CTL:SRCH:HTH=");
			strcpy_u(READ, READ + 14);
		}
	
		memset(&Input, 0, sizeof(Input)); 
		
		/* EAI �������̿� */
		if (IFSE("#CTL:SRH:TXT:0000=", READ) != 0) {
			strcpy(szBuf, "#CTL:SRH:TXT:0000=");
			Poi_MakeText_GetHead((void *)&srchOut, READ+18);
			strnzcpy(Input.szKeyWord, srchOut.hdr.KeyWord,sizeof(srchOut.hdr.KeyWord));
		}
		else if (strstr(READ,"#CTL:SRH:TXT:0000=") != 0) {                        
			strcpy(szBuf, "#CTL:SRH:TXT:0000=");
			Poi_MakeText_GetHead((void *)&srchOut, READ);
			strnzcpy(Input.szKeyWord, srchOut.hdr.KeyWord,sizeof(srchOut.hdr.KeyWord));
		}
		else if( IFSE("#CTL:SRCH:HTH=", szBuf) != 0 ) {
			strcpy(Input.szKeyWord, READ);
		}
		else{
			#ifdef _KBST_				
				Poi_MakeText_GetHead((void *)&srchOut, READ);
				strnzcpy(Input.szKeyWord, srchOut.hdr.KeyWord,sizeof(srchOut.hdr.KeyWord));
			#elif _HKTCPTL /* �ѱ�����ĳ��Ż (JSON, UTF-8) */
				/* JSON���� JAR���� �˻�: EAI, JAR ��� ��û�� ��. */
				pJSONRequest = HKTCPTL_DetectJSON(READ);
				if ( pJSONRequest ) {
					TmpLogBuf[0] = '\0'; pJSONRequest = 1;
					/* UTF-8 to CP949 convert (�α� ���۸� �ӽ� ���ڵ� ��ȯ ���۷� �����.)*/
					Utf8ToCP949(TmpLogBuf, READ); 
					/* ó�� 6����Ʈ�� ���۹���Ʈ�̹Ƿ� �ǳʶپ� JSON�� �����Ѵ�. */
					strcpy(READ, TmpLogBuf+6); TmpLogBuf[0] = '\0';
					/* JSON to Object and extract keyword. **/
					pJSON = JSON2Keyword_HKTCPTL(READ, Input.szKeyWord);
				} else { /* JAR���� ���� �������� ��� */
					strcpy(Input.szKeyWord, READ);	
				}
			#else
				strcpy(Input.szKeyWord, READ);
			#endif			
		}				
		SEPCHRB(&ss,Input.szKeyWord,"|",10); SEPARRY(&ss);
		if (IFSE("#CTL:SRH:TXT:0000=", READ) != 0) {
			strnzcpy(TmpBuf, srchOut.hdr.DatReqLoc, sizeof(srchOut.hdr.DatReqLoc));
			start=atoi(TmpBuf);		
		}
		else if (strstr(READ,"#CTL:SRH:TXT:0000=") != 0){
			strnzcpy(TmpBuf, srchOut.hdr.DatReqLoc, sizeof(srchOut.hdr.DatReqLoc));
			start=atoi(TmpBuf);                        
		}
		else if( IFSE("#CTL:SRCH:HTH=", szBuf) != 0 ) {
			if(ss.cnt==2 || ss.cnt==3)
					start=atoi(ss.pt[1]);
			else start=0;
		}
		else{
			#ifdef _KBST_
				strnzcpy(TmpBuf, srchOut.hdr.DatReqLoc, sizeof(srchOut.hdr.DatReqLoc));
				start=atoi(TmpBuf); 
			#else
				if(ss.cnt==2 || ss.cnt==3)
					start=atoi(ss.pt[1]);
				else start=0;
			#endif			
		}					
		cnt=0;
		#ifdef _hana_bank_
		cnt=atoi(srchOut.hdr.DCNT);
		#endif
		
		if(ss.cnt==3){
			cnt=atoi(ss.pt[2]);
		}		
		nCnt=SRCH_POI(&Input, &g_Result,start,cnt);
		strcpy(g_Result.KEYWORD,Input.szKeyWord);
	
		if (szBuf[0] != 0 && IFSE("#CTL:SRCH:TXT=", szBuf) != 0) {
			POI_MakeTxt(&g_Result, OutRecData);
			#ifdef _HANA_SKCARD_
			sprintf(pXml, "%06d%04d%s", strlen(OutRecData)+4, nCnt, OutRecData);
			#else
			sprintf(pXml, "%06d%04d%04d%s", strlen(OutRecData)+8,g_Result.nHitCnt, nCnt, OutRecData);
			#endif
			dstlen = strlen(pXml);				
		}
		else if (szBuf[0] != 0 && IFSE("#CTL:SRCH:WEB=", szBuf) != 0) {
			#ifdef _KBBANK_FN
			POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC,"K",TmpReqTime);
			#else
			POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC,"N","");
			#endif			
			dstlen = strlen(pXml);			
		}
		else if (szBuf[0] != 0 && IFSE("#CTL:SRH:TXT:0000=", szBuf) != 0) {	
			memset(OutRecData,0,1024000);
			Poi_MakeText_MakeDataBlock((void *)&g_Result, (void *)&srchOut, OutRecData);
			strcpy(pXml,OutRecData);
			dstlen = strlen(pXml);
		}
		else if (szBuf[0] != 0 && IFSE("#CTL:SRCH:HTH=", szBuf) != 0) {	
			POI_MakeXML(&g_Result, &pXml, ENV->ENC);	
		  	/*POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC);*/			
		  	if(pXml!=0)	dstlen=strlen(pXml);
		}				
		else{
			#ifdef _KBST_
				memset(OutRecData,0,1024000);
				Poi_MakeText_MakeDataBlock((void *)&g_Result, (void *)&srchOut, OutRecData);
				strnzcpy(TmpBuf,OutRecData,5);
				memcpy(pXml, OutRecData, atoi(TmpBuf)+5 );					
				dstlen = atoi(TmpBuf)+5;
			#elif _HKTCPTL
				if ( pJSONRequest ) {
					memset(OutRecData,0,1024000);
					dstlen = POI_MakeJSON(&g_Result, &pXml, pJSON);
					sprintf(TmpLogBuf, "%06d%s", dstlen, pXml);
					strcpy(pXml, TmpLogBuf); TmpLogBuf[0] = '\0';
					dstlen += 6;
				} else {
					POI_MakeXML(&g_Result, &pXml, ENV->ENC);
					dstlen=strlen(pXml);
				}
			#else
		  		POI_MakeXML(&g_Result, &pXml, ENV->ENC);	
		  		/*POI_MakeXML_Len(&g_Result, &pXml, ENV->ENC);*/			
		  		dstlen=strlen(pXml);
		  	#endif	  
		}
	} 
	/* no data */
	else if ( len == 0 ) {
		strcpy(WRITE, "0000000005NODAT"); p=WRITE;
		dstlen=-1;
	} 
	/* read error */
	else if( len < 0 ) {
		strcpy(WRITE, "0000000005ERROR"); p=WRITE;
		/*STD_PRNT(WRITE);*/
	}
	/*--------------------------------------------------------------------------------------------*/
	if( len > 0 ) {
		if( !saa.bAsync ) {
			#ifdef _KBST_
			if (szBuf[0] != 0 && IFSE("#CTL:SRCH:HTH=", szBuf) != 0) {	
				
			}
			else{
	            memset(TmpBuf,0,sizeof(TmpBuf));memset(TmpBuf2,0,sizeof(TmpBuf2));			    		    
				strnzcpy(TmpBuf,pXml,30);	
				strncpy(TmpBuf+5,"S",1);
				sprintf(TmpBuf2,"00031%sSK    ",TmpBuf+5);
				/* �������� �α� */
				sprintf(TmpLogBuf,"[3]Socket Write:%s",TmpBuf2);
				LOGGER(TmpLogBuf, 0);
				
				if(write(c, TmpBuf2,36)<=0){
					sprintf(TmpLogBuf,"Socket Write Error:%s",TmpBuf2);
	                STD_PRNT(TmpLogBuf);
	                sprintf(TmpLogBuf,"errno=%s\n",strerror(errno));
	                STD_PRNT(TmpLogBuf);
	                LOGGER("Socket Write Error", 0);
				}
			}
			#endif

			if(write(c, pXml, dstlen)<=0){	
			/*if(send(c, pXml, dstlen,MSG_NOSIGNAL)<=0){	*/				 		
				sprintf(TmpLogBuf,"Socket Write Error:%s",pXml);					
				STD_PRNT(TmpLogBuf);				
				sprintf(TmpLogBuf,"errno=%s\n",strerror(errno));				
		  		STD_PRNT(TmpLogBuf);
				LOGGER("Socket Write Error", 0);
			}
			else	LOGGER("Socket Write OK", 0);			
		}
		else RECV_ASYNC_CTL(pXml, dstlen);
		if( IFSE("#CTL:SRCH:HTH=", szBuf) == 0 )
			LOGGER_R(pXml, 0);
		if(slog.ndisplayLog!=1){
			printf("\nWRITE(%d):[%s]\n", dstlen, pXml);
		}
	}
	/*--------------------------------------------------------------------------------------------*/	
	if(slog.ndisplayLog!=1){
		printf("\n============= End of OUTPUT ADR INFO =============\n\n");	
	}
	fflush(stdout);
	return dstlen;
}


void * RECV_CTL_DAILY( void * p)
{
	char TmpBuf[1024]={0}, envpath[256]={0},TmpBuf2[1024]={0};
    struct _SocketInfo *SocketArray;
    int i;   
  
    SocketArray=p;
	bHealth=FALSE;
	/*--------------------------------------------------------------------------------------------*/
	/* �ϰ��� üũ ���� */
	strcpy(TmpBuf, g_szAbsPath);
	GetEnvIniString(pConfig, "GENERAL", "refdata_daily", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
	GetEnvIniString(pConfig, "GENERAL", "envfile", envpath, sizeof(envpath));
	if( *TmpBuf != 0 && *envpath != 0 ) {
		if( POI_LoadCodeData_DAILY(TmpBuf, envpath, 1, 1) == -1 ) {
			DAILY_LOGGER("[DAILY] Failed to Loading Daily Reference Data!\n\n");
		}
		else{
			sprintf(TmpBuf2,"[DAILY] Loaded Daily Reference Data\n");
			DAILY_LOGGER(TmpBuf2);
		}
	}
	else {
		DAILY_LOGGER("[DAILY] Please check the configure file");
		ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;
	}
	if(SocketArray!=0){
		for (i = 0; i < SocketArray[0].cnt; i++) {
		    /*close(SocketArray[i].fd);*/
			kill(SocketArray[i].pid, SIGKILL);
			sleep(1);
		}
	}
	/*pthread_exit(0);*/
	return 1;
}

int RECV_ASYNC_CTL(char *writebuf, int dstlen)
{
	int sock=0, len;
	
	if( writebuf == 0 || dstlen == 0 ) return 0;
	/*--------------------------------------------------------------------------------------------*/
	printf("Connecting %s:%d\n", saa.szDstIP, saa.nPort);
	
	if( (sock=connect_svr(saa.szDstIP, saa.nPort)) > 0 ) {
		len=write(sock, writebuf, dstlen);
		if( len < 0 ) len=write(sock, writebuf, dstlen);
		
	} else {
		printf("Connection Failed\n");
	}
	/*--------------------------------------------------------------------------------------------*/
	disconnect_svr(sock);
}


/*------------------------------------------------------------------------------------------------*/
/* ���� �������� ���                                                                              */
/*------------------------------------------------------------------------------------------------*/
static void print_version(void)
{	
	printf("%s %s\n", PROGRAM_NAME, VERSION_INFO);
	printf("Revision : %s\n\n", REVISION_INFO);
	printf("Copyright (c) SujiewonNetSoft. All rights reserved.\n");
}

int socket_recv(int socket, char* buffer, int size,int SizeOfLen)
{
	int total_received;
	int received,rtotcnt;
	char tmpSize[11];
	memset(tmpSize,0,11);
	assert(buffer);
	assert(size > 0);
	total_received = 0;
	while(size){
		received = read(socket, buffer, size);
		printf("[%s]\n\n", buffer);		
		if(tmpSize[0]==0){
			strnzcpy(tmpSize,buffer,SizeOfLen);
			rtotcnt=atoi(tmpSize);
		} 	
		/* ���ϰ��� = 0 �̸� close�Ǿ����� �ǹ�
		   ���ϰ��� < 0 �̸� ���� �߻��� �ǹ�
		*/
		if(received <= 0) break;
		total_received += received;
		size -= received;
		buffer += received;
		if(rtotcnt <= total_received)
		 break;
		printf("rtotcnt[%d]total_received[%d]\n\n", rtotcnt,total_received);
	}
	return received > 0 ? total_received : received;
}

static int check_if_process_exist(char *pszName)
{
    FILE *fp = 0;
    char szBuf[128] = {0,}, szProcessCnt[16] = {0,};
    int nRead = 0;

    if ( !pszName || !(*pszName) )
        return 0;
    
    sprintf(szBuf, "ps -ef | grep %s | grep -v grep | wc -l", pszName); 
    fp = popen(szBuf, "r");
    if ( fp == 0 ) 
        return 0;
    
    nRead = fread(szProcessCnt, sizeof(char), sizeof(szProcessCnt), fp);
    if ( nRead > 0 && atoi(szProcessCnt) > 1 ) 
        return 1;

    return 0;
}
