/*==================================================================================================
 #���α׷��� : �������� ���� �ｺüũ Ŭ���̾�Ʈ ���
 #��      �� : ȯ�漳���� port�� ������ �ۼ���/������ üũ(timeout) 
==================================================================================================*/
#include "srchsrv.h"

#ifdef _KBST_
extern int gfSmsSendProc( int ErrorLevel, char *ProcessID, char *ProcessName, char *Message);
#endif
/*------------------------------------------------------------------------------------------------*/
static int sethealthchk(char *path);
static void error_report(char *msg);
void * threadFn_check_timeout(void *c);								/* thread function(timeout check) */
char *time_stamp();
static int check_if_process_exist(char *pszName);
/*------------------------------------------------------------------------------------------------*/	
static char health_data[1024]={0};									/* health check data */
char health_return[512]={0};										/* health return data */

int nInterval=5;													/* health chk interval */
static int nport=0;													/* server port number */
int client_socket=-1;												/* client socket number */
int bHealthOK=0;													/* �����忡�� üũ�� �ｺ ���� */

/* 2020.09.16 by kyh: Health error file option: When health check is failed, write error file. */
static char health_errfile_use_YN;									/* health check error file print or not */
static int health_errfile_limit_cnt;								/* health check failure count limit (over the limit, restart server) */
static int health_errfile_current_cnt = 0;
static char heatlh_errfile_path[PATH_MAX]={0};					/* failure info file path (when over the failure count limit) */
static void heatlh_errfile_write(char *pPath, char *pszMsg);

struct sockaddr_in server_addr;
struct linger linger;
struct timeval tv;
char   gTime2[30];
/*------------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : main()
---------------------------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	pthread_t pid;
	int status, nByte,rByte,nReadB;
	int	bUserExeName = 0,i;								/* ����ڰ� ������ �������Ϸ� �����ϱ� */
	char szStartExe[64]={0},exe_file[32]={0},*checktime,stime[10]={0};
	char l_buf[128]={0};
	FILE *file_sch;
		
	if( sethealthchk(argv[0]) == 0 ) exit(-1);
	if( argc == 3) {	
		if(strcmp(argv[1], "-n") == 0){ 				/* -n => process name expected */
			/* 2022.12.21 �ߺ�������� (�Ե��� �׽�Ʈ���� ������ϸ� �� �� ����Ǵ� ���� ó���� ���� �߰�) */
			const char *pszPgmName = "srchchk_health";
			/*printf("Process running check... Wait for 5 seconds...\n");*/
			/*sleep(5);*/		
			
			/*if ( check_if_process_exist(pszPgmName) == 1 ) {
				printf("%s already running... exit process.\n", pszPgmName);
				exit(-1);
			}*/
			bUserExeName = 1;	
			strcpy(exe_file, argv[2]);					/* ����ڰ� ������ ���ο� �������� �̸� */		
			sprintf(szStartExe, "./srvctl start ./%s", exe_file);	/* "./srvctl start ./nra_exename"  */
			printf("%s\n",szStartExe);
		}
	}
	
	f_daemon(); write_pid("srchchk_health.pid");
	/*--------------------------------------------------------------------------------------------*/
	do {
		checktime=time_stamp();
		if((file_sch = fopen("schedule_job.txt", "r")) == NULL)	{					
		}
		else
		{
			rByte=File_LineInput(file_sch,l_buf,&nReadB,128); 
			for(i=0;l_buf[i]!=0 && l_buf[i]!=' ';i++)
				stime[i]=l_buf[i];
			stime[i]=0;
			if(strcmp(stime,checktime)==0)
			{	sleep(300);		}
			fclose(file_sch);
		}
		/* Ÿ�Ӿƿ� �ð� üũ */
		if( pthread_create(&pid, 0, threadFn_check_timeout, (void *)0) != 0 ) {
			perror(strerror(errno));
		}
		/*printf("[%d] activating timer...\n", pid); */
		bHealthOK=1; client_socket=0;
		
		if( (client_socket=connect_svr("127.0.0.1", nport)) > 0 ) {
			bHealthOK=1;
			/*printf("data write\n"); */
			if( (nByte=write(client_socket, health_data, strlen(health_data))) == -1 ) 
			{ error_report("write : no response from the server");  bHealthOK=0; }				
			else
			{	 sleep(1);
				if( (nByte=read( client_socket, health_return, sizeof(health_return)) ) == -1 ) 
				{  sleep(1);
					if( (nByte=read( client_socket, health_return, sizeof(health_return)) ) == -1 ) 
					{ 
						error_report("read : no response from the server");  bHealthOK=4; 
					}
					else{
						#ifdef _KBST_			 
					 	 if(	strstr(health_return,"���� �������� ���η�") == 0 ){
							bHealthOK=5; 
						}
						else
						#endif
					  		bHealthOK=2; /* all transfer ok */
					}
				}			 
				else{	
					#ifdef _KBST_
					if(	strstr(health_return,"���� �������� ���η�") == 0 ){
						bHealthOK=5; 
					}
					else
					#endif
				  		bHealthOK=2; /* all transfer ok */
				  health_errfile_current_cnt = 0; /* reset failure count */
				}			
			}
			/*printf("data ok\n"); */
			disconnect_svr(client_socket);			
		} else { 
			error_report(0); bHealthOK=3;											/* health failed */
		}
		/*client_socket=0;*/
		
		/* ������ ���� ���� Ȯ�� */		
		if( pthread_join(pid, (void**)&status) != 0 ) perror(strerror(errno));				
		if( status == -1 ) {
			error_report("connect : no response from the server");

			/* 2020.09.16 by kyh: Health Check file print option */
			if( health_errfile_use_YN == 'Y' ) { 
				++health_errfile_current_cnt;
				if( health_errfile_current_cnt > health_errfile_limit_cnt ) {
					/* health error file print */
					heatlh_errfile_write(heatlh_errfile_path, "connect : no response from the server");

					/* restart server */
					system("./srvctl stop"); 
					if (bUserExeName==1) 
						system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
					else	
						system("./srvctl start");
				}
				sleep(nInterval);
				continue;
			}

			system("./srvctl stop"); 
			if (bUserExeName==1) 
				system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
			else	
				system("./srvctl start");
		}
		if( status == -2 ) {
			error_report("transfer(write) : no response from the server");

			/* 2020.09.16 by kyh: Health Check file print option */
			if( health_errfile_use_YN == 'Y' ) { 
				++health_errfile_current_cnt;
				if( health_errfile_current_cnt > health_errfile_limit_cnt ) {
					/* health error file print */
					heatlh_errfile_write(heatlh_errfile_path, "transfer(write) : no response from the server");

					/* restart server */
					system("./srvctl stop"); 
					if (bUserExeName==1) 
						system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
					else	
						system("./srvctl start");
				}
				sleep(nInterval);
				continue;
			}

			system("./srvctl stop");
			if (bUserExeName==1) 
				system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
			else	
				system("./srvctl start");
		}
		if( status == -3 ) {
			error_report("delayed : no response from the server");

			/* 2020.09.16 by kyh: Health Check file print option */
			if( health_errfile_use_YN == 'Y' ) {
				++health_errfile_current_cnt;
				if( health_errfile_current_cnt > health_errfile_limit_cnt ) {
					/* health error file print */
					heatlh_errfile_write(heatlh_errfile_path, "delayed : no response from the server");

					/* restart server */
					system("./srvctl stop"); 
					if (bUserExeName==1) 
						system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
					else	
						system("./srvctl start");
				}
				sleep(nInterval);
				continue;
			}

			system("./srvctl stop");
			if (bUserExeName==1) 
				system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
			else	
				system("./srvctl start");
		}
		if( status == -4 ) {
			error_report("transfer(read) : no response from the server");

			/* 2020.09.16 by kyh: Health Check file print option */
			if( health_errfile_use_YN == 'Y' ) {
				++health_errfile_current_cnt;
				if( health_errfile_current_cnt > health_errfile_limit_cnt ) {
					/* health error file print */
					heatlh_errfile_write(heatlh_errfile_path, "transfer(read) : no response from the server");

					/* restart server */
					system("./srvctl stop"); 
					if (bUserExeName==1) 
						system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
					else	
						system("./srvctl start");
				}
				sleep(nInterval);
				continue;
			}

			system("./srvctl stop");
			if (bUserExeName==1) 
				system(szStartExe);					/* ����ڰ� ������ �̸����� �����ϰ� �ϱ� */
			else	
				system("./srvctl start");			
		}
		if( status == -5 ) {
			error_report("transfer(read) : error mapping from the server");
			#ifdef _KBST_
			if(gfSmsSendProc(1, "001", "srchsrv", "Search Address Error Mapping") < 0)
        		return -1;
        	#endif
			sleep(600);
			
			/*system("./srvctl stop");
			if (bUserExeName==1) 
				system(szStartExe);					
			else	
				system("./srvctl start");	
			*/		
		}
				
		sleep(nInterval);
	} while(1);
	/*--------------------------------------------------------------------------------------------*/
		
	return 0;
}

void * threadFn_check_timeout(void *c)
{
	unsigned short nDelay=0;
	const unsigned short nMaxDelay=10;
	
	/*if( client_socket < 0 ) return (void*)-1;	*/				/* ���� ���н� ������ ���� */
		
	while(1) {
		sleep(1);
		if( client_socket < 0 ) return (void*)-1;					/* ���� ���н� ������ ���� */
		if( bHealthOK == 3 ) return (void*)-1;					/* ���� ���н� ������ ���� */
		if( bHealthOK == 0 ) return (void*)-2;					/* write �� ���� */ 
		if( bHealthOK == 4 ) return (void*)-4;					/* read �� ���� */
		if( bHealthOK == 5 ) return (void*)-5;					/* �˻������� ��������*/
		if( bHealthOK == 2 ) return (void*)0;					/* ok */		
		
#if 1	
		nDelay++;
		if( nDelay >= nMaxDelay ) {
			printf("[timer] delaying exceeded... %d/%d\n", nDelay, nMaxDelay); 
			return (void*)-3;				/* ������ �ʰ��� ������ ���� */
		}
#else	/* 2021.02.15 ��Ȱ��ȭ (�Ե�ON ��û: �˻����� ����� �� �� �޽����� ���� �߰� Ȯ�� �۾��� ������ ����.) */
		printf("[timer] delaying... %d/%d\n", nDelay++, nMaxDelay); 
		if( nDelay >= nMaxDelay ) return (void*)-3;				/* ������ �ʰ��� ������ ���� */
#endif	
	}
	return (void*)0;
}


static void error_report(char *msg)
{
	char szTmp[512]={0};
	
	if( msg != 0 && *msg != 0 ) {
		sprintf(szTmp, "[HEALTH_ERROR] %s", msg);
	} else {
		sprintf(szTmp, "[HEALTH_ERROR] %s", strerror(errno));
	}
	printf("%s\n", szTmp);
	slog.bSysLog=1;
	SYS_LOGGER(szTmp);
	
}

/*------------------------------------------------------------------------------------------------*/
/* set health checker */
/*------------------------------------------------------------------------------------------------*/
static int sethealthchk(char *path)
{
	char TmpBuf[128];
	
	LOAD_CONFIG(path, "srchsrv.conf");
	/*--------------------------------------------------------------------------------------------*/
	GetEnvIniString(pConfig, "NETWORK", "port", TmpBuf, sizeof(TmpBuf) ); nport=atoi(TmpBuf);
	if( nport == 0 || nport > 65535 ) {
		STD_PRNT("Please check the configure file (port)");
		ERR_EXIT("Socket Port is not set");
	}	
	/*--------------------------------------------------------------------------------------------*/
	GetEnvIniString(pConfig, "NETWORK", "l_onoff", TmpBuf, sizeof(TmpBuf)); linger.l_onoff = atoi(TmpBuf);
	GetEnvIniString(pConfig, "NETWORK", "l_linger", TmpBuf, sizeof(TmpBuf)); linger.l_linger = atoi(TmpBuf);
	GetEnvIniString(pConfig, "NETWORK", "timeout", TmpBuf, sizeof(TmpBuf)); 
	if(atoi(TmpBuf)>=30){
		tv.tv_sec = atoi(TmpBuf) / 1000;
   		tv.tv_usec = (atoi(TmpBuf) % 1000) * 1000;		
	}
	else{
		tv.tv_sec = atoi(TmpBuf); tv.tv_usec = 0;
	}
	/*--------------------------------------------------------------------------------------------*/
	memset(&server_addr, 0, sizeof( server_addr));
	server_addr.sin_family     = AF_INET;
	server_addr.sin_port       = htons(nport);
	server_addr.sin_addr.s_addr= inet_addr("127.0.0.1");
	/*--------------------------------------------------------------------------------------------*/
	strcpy(health_data, "#CTL:SRCH:HTH=");
	GetEnvIniString(pConfig, "NETWORK", "health_data", health_data+14, sizeof(health_data)-14); 
	
	STD_PRNT("Health Checking Data");
	STD_PRNT(health_data);
	/*--------------------------------------------------------------------------------------------*/
	GetEnvIniString(pConfig, "NETWORK", "health_intv", TmpBuf, sizeof(TmpBuf)); 
	if( (nInterval=atoi(TmpBuf)) == 0 ) nInterval=5;						/* default */
	sprintf(TmpBuf, "Health Checking %d second.", nInterval);
	STD_PRNT(TmpBuf);

	/* 2020.09.16 by kyh: file print option (when health check failed, GSHOME request) */
	if( GetEnvIniString(pConfig, "NETWORK", "health_errfile_use_YN", TmpBuf, sizeof(TmpBuf)) != 0 ) {
		if( TmpBuf[0] == 'Y' || TmpBuf[0] == 'y' )
			health_errfile_use_YN = 'Y';
		else 
			health_errfile_use_YN = 'N';
	}
	if( health_errfile_use_YN == 'Y' ) {
		if( GetEnvIniString(pConfig, "NETWORK", "health_errfile_limit_cnt", TmpBuf, sizeof(TmpBuf)) != 0 ) {
			health_errfile_limit_cnt = atoi(TmpBuf);
			if( health_errfile_limit_cnt <= 0 )
				health_errfile_limit_cnt = 3;
		} else {
			health_errfile_limit_cnt = 3;
		}
		if( GetEnvIniString(pConfig, "NETWORK", "health_errfile_path", TmpBuf, sizeof(TmpBuf)) != 0 ) {
			if( TmpBuf[0] != 0 )
				strcpy(heatlh_errfile_path, TmpBuf);
			else
				strcpy(heatlh_errfile_path, "./health_error.txt");
		} else {
			strcpy(heatlh_errfile_path, "./health_error.txt");
		}

		sprintf(TmpBuf, "Health Checking ErrFile print option: Enable");
		STD_PRNT(TmpBuf);
	} else {
		sprintf(TmpBuf, "Health Checking ErrFile print option: Disable");
		STD_PRNT(TmpBuf);
	}
	
	printf("\n"); fflush(stdout);
	return 1;
}
char *time_stamp()
{               
    struct  tm *nPtime;
    time_t  nTime;
    memset(gTime2,0,30);
    time(&nTime);
    nPtime = localtime(&nTime);
   
    memset(gTime2, '\0', 30);
    sprintf(gTime2, "%02d:%02d",nPtime->tm_hour,nPtime->tm_min);
    return gTime2;
}

/* write health check failue info to file (append mode) */
static void heatlh_errfile_write(char *pPath, char *pszMsg)
{
	FILE *fp_error;
	if( pPath == 0 || *pPath == 0 ) 
		return;

	fp_error = fopen(pPath, "a");
	if ( fp_error == 0 )
		return;

	if( pszMsg == 0 || *pszMsg == 0 )
		fprintf(fp_error, "[%s] %s\n", GET_TIME(0), "Health Check failed.. restart server");
	else
		fprintf(fp_error, "[%s] %s(%s)\n", GET_TIME(0), "Health Check failed.. restart server", pszMsg);

	fclose(fp_error);
}

static int check_if_process_exist(char *pszName)
{
    FILE *fp = 0;
    char szBuf[128] = {0,}, szProcessCnt[16] = {0,};
    int nRead = 0;

    if ( !pszName || !(*pszName) )
        return 0;
    
    sprintf(szBuf, "ps -ef | grep %s | grep -v grep | wc -l", pszName); 
    fp = popen(szBuf, "r");
    if ( fp == 0 ) 
        return 0;
    
    nRead = fread(szProcessCnt, sizeof(char), sizeof(szProcessCnt), fp);
    if ( nRead > 0 && atoi(szProcessCnt) > 1 ) {
        pclose(fp);
        return 1;
    }

    pclose(fp);
    return 0;
}
