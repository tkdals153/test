/*==================================================================================================
 #���α׷��� : UNIX/LINUX ���� ��Ƽ���μ��� ���
 #���������� : �¶��� �ּ� ���� ��Ƽ���μ��� ���
==================================================================================================*/
#include "srchsrv.h"
#define SA struct sockaddr 
#ifdef _MP
#include <pthread.h>
#include <signal.h>
/*------------------------------------------------------------------------------------------------*/
typedef union _cmsg_fd{ 
    struct cmsghdr cm; 
    char control[CMSG_SPACE(sizeof(int))]; 
} cmsg_fd; 
/*------------------------------------------------------------------------------------------------*/
/* �Լ� ������Ÿ��                                                                                */
/*------------------------------------------------------------------------------------------------*/
void z_handler(int sig);
int write_fd(int fd, void *ptr, size_t nbytes, int sendfd); 
int prefork_client(int fd,int mfd); 
int prefork_client_cont(int fd) ;
int read_fd(int fd); 
int main_server(int server_sockfd, struct _SocketInfo *SocketArray, int preforknum, char *sckcnctoption) ;
void *Check_Child(void *c);
static int prsckinfo;
void mtps_time_out(int sig);
/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : ��Ƽ�������� ����
---------------------------------------------------------------------------------------------------*/
void *Check_Child(void *c)
{
    int    status;
    pid_t child_pid;
    pthread_detach(pthread_self());
    
    while(1){
        while( (child_pid= waitpid(-1,&status,WNOHANG) ) >0){
            if(slog.ndisplayLog!=1){
                printf("Child has finished: pid=%d\n",child_pid);
                printf("return : %d \n",WEXITSTATUS(status));
            }
        }
        sleep(1);
    }
}
void MULTI_SERVER(int bfork)
{
    int    retval, status,childpid,ntimeout=3;
    fd_set read_fds;
    pid_t child_pid;
    char TmpBuf[1024];
    pthread_t pid;    

    SETT_ENGINE(1, 1); SOCK_SETTING(); FD_ZERO(&read_fds);ntimeout=tv.tv_sec;

    if( bfork == 1 ) { f_daemon(); write_pid("srchsrv.pid"); }
    
    pthread_create(&pid, 0, Check_Child, (void *)0);
    Signal(); /* �ñ׳μ���*/
    
    while(1) {
        
        if( (client = accept(server, 0, 0)) == -1 ) continue;
        childpid = fork();
        if ( childpid < 0 ){
            if(slog.ndisplayLog!=1)
                printf("SERVER : fork error!\n");            
            sprintf(TmpBuf, "fork error: %s", strerror(errno)); 
            perror(TmpBuf); printf("\n");
        }
        else if ( childpid == 0 ){
            /* Child Process */
            if(slog.ndisplayLog!=1)
                printf("\nSERVER : NEW Child Process PID is %ld", (long)getpid());            
            FD_SET(client, &read_fds);            
            tv.tv_sec = ntimeout;
            tv.tv_usec = 0;
            retval=select(client+1, &read_fds, (fd_set *)0, (fd_set *)0, &tv);
            if( retval == -1 ) {
                if(slog.ndisplayLog!=1)
                    STD_PRNT("SERVER(retval == -1) : Socket Select Failed");                
            }
            else if ( retval ) {
                if(FD_ISSET(client, &read_fds)){     
                    alarm(5); /* �˶����� */                                
                    RECV_CTL(client);    
                    alarm(0); /* �˶����� */
                }
            }
            else {            
                if(slog.ndisplayLog!=1)
                    STD_PRNT("SERVER(timeout) : No data within n seconds.");                
            }
            shutdown(client, SHUT_RD); shutdown(client,SHUT_WR);    /* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
            close(client);                                            /* Ŭ���̾�Ʈ ���� ���� */
            close(server);                                            /* �ڽļ��� ���� ���� */
            FD_CLR(client,&read_fds);
            exit(0);            
        }
        else{    
            if(close(client)!=0){
                if(slog.ndisplayLog!=1)                    
                    printf("Parents Close Error!\n");                
            }            
        }        
    }
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : write_fd
---------------------------------------------------------------------------------------------------*/ 
int write_fd(int fd, void *ptr, size_t nbytes, int sendfd) 
{ 
    struct msghdr    msg; 
    struct iovec    iov[1]; 
    cmsg_fd control_un; 
    struct cmsghdr *cmptr; 

    msg.msg_control = control_un.control; 
    msg.msg_controllen = sizeof(control_un.control); 

    cmptr = CMSG_FIRSTHDR(&msg); 
    cmptr->cmsg_len = CMSG_LEN(sizeof(int)); 
    cmptr->cmsg_level = SOL_SOCKET; 
    cmptr->cmsg_type = SCM_RIGHTS; 
    *((int *) CMSG_DATA(cmptr)) = sendfd; 
    msg.msg_name = NULL; 
    msg.msg_namelen = 0; 

    iov[0].iov_base = ptr; 
    iov[0].iov_len = nbytes; 
    msg.msg_iov = iov; 
    msg.msg_iovlen = 1; 
    return(sendmsg(fd, &msg, 0)); 
} 

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : read_fd
---------------------------------------------------------------------------------------------------*/
int read_fd(int fd) 
{ 
    int n; 
    int recvfd; 
    char ptr; 
    struct iovec iov[1]; 
    struct cmsghdr *cmptr; 
    struct msghdr msg; 
    cmsg_fd control_un; 

    msg.msg_control = control_un.control; 
    msg.msg_controllen = sizeof(control_un.control); 
    msg.msg_name = NULL; 
    msg.msg_namelen = 0; 

    iov[0].iov_base = (void *)&ptr; 
    iov[0].iov_len = 1; 
    msg.msg_iov = iov; 
    msg.msg_iovlen = 1; 
    if ( (n = recvmsg(fd, &msg, 0)) <= 0) { 
        /* perror("recvmsg error"); */
        exit(-1);
    } 
    cmptr = CMSG_FIRSTHDR(&msg);  
    if ((cmptr == NULL))      
        exit(-1);
     
    recvfd = *((int *) CMSG_DATA(cmptr)); 
    return recvfd; 
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : ��Ƽ�������� ����
---------------------------------------------------------------------------------------------------*/
void Multi_Main(char *mnum, char *sckcnctoption)
{
    int state;
    int n,i,pid; 
    int preforknum; 
    int sv[2];     
    struct _SocketInfo *SocketArray; 
    
    int    retval, status,childpid;
    fd_set read_fds;
    pid_t child_pid;
    char TmpBuf[1024];
    
    SETT_ENGINE(1, 1); SOCK_SETTING();

    f_daemon(); write_pid("srchsrv.pid"); 
    preforknum = atoi(mnum);
    if(preforknum > 100) 
    { 
        fprintf(stderr,"Max preforknum is 100\n"); 
        exit(0); 
    } 
    /* Socket Infomation Array */
    SocketArray = (void *)malloc(sizeof(struct _SocketInfo)*preforknum); 
    memset((void *)SocketArray, 0x00, sizeof(struct _SocketInfo)*preforknum); 
    /*--------------------------------------------------------------------------------------------*/
    
    for (i = 0; i < preforknum; i++) {
        memset(&sv, 0, sizeof(sv));
        if( socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == -1 ) {
            perror("socketpair error");
        }
        
        pid = fork(); 
        if (pid < 0) { 
            perror("fork error"); exit(0); 
        } 
        if (pid == 0) {
            /* if( dup2(sv[0], 1500) == -1 ) perror("dup2 error"); */
            
            close(sv[1]);
            /* close(sv[0]); */
            close(server);
            if(sckcnctoption==0 || strcmp(sckcnctoption,"-c")!=0){
                prefork_client(sv[0],sv[1]);            
            }
            else
                prefork_client_cont(sv[0]);
        } 
        else if( pid > 0 ) { 
            close(sv[0]); 
            SocketArray[i].pid    = pid;
            SocketArray[i].fd     = sv[1];
            SocketArray[i].status = 1;   
            SocketArray[i].cnt=preforknum;
        } 
    }
    /*--------------------------------------------------------------------------------------------*/
    close(0);
    main_server(server, SocketArray, preforknum,sckcnctoption); 
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : fd Ŭ���̾�Ʈ
---------------------------------------------------------------------------------------------------*/
int prefork_client(int fd, int mfd) 
{ 
    int n=0;   
    int sockfd; 
    int msg = 0,ck=0; 

    if(slog.ndisplayLog!=1){
        printf("\n[NRASRV] Child Created(%d),fd=%d\n", getpid(),mfd); fflush(stdout);
    }
    signal(SIGALRM,mtps_time_out);
    while(1) {
        sockfd = read_fd(fd);                     /* ���ϳѹ��������� */
        if(slog.ndisplayLog!=1)    
            printf("[NRASRV] Client Socket(%d),%d\n", sockfd,getpid()); 
        sigignore(SIGPIPE);
        /* ���μ����������� �迭�� �޾ƿ� ���ϰ��� �־�д�*/
        prsckinfo=sockfd;
        alarm(30); /* �˶����� */
        ck=RECV_CTL(sockfd); 
        alarm(0); /* �˶����� */
        if(slog.ndisplayLog!=1)
            printf("[NRASRV] Client Socket(%d) close,%d\n", sockfd,getpid()); 
        shutdown(sockfd, SHUT_RD);shutdown(sockfd,SHUT_WR);
        close(sockfd);
        if(ck==4321){
            msg=1234;        
            write(fd, (void *)&msg, sizeof(msg));
        }
        else{
            msg=0;
            write(fd, (void *)&msg, sizeof(msg));     /* �ڽ����μ��� ���� ��ȯ�ϱ� */
        }
    } 
    
    return fd;
} 

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : fd Ŭ���̾�Ʈ(���Ͽ����� �����ʰ� ����Ȼ��¿��� �����)
---------------------------------------------------------------------------------------------------*/
int prefork_client_cont(int fd) 
{ 
    int n;   
    int sockfd; 
    int msg = 0; 

    if(slog.ndisplayLog!=1){
        printf("\n[NRASRV] Child Created(%d)", getpid()); fflush(stdout);
    }
    sockfd = read_fd(fd);                     /* ���ϳѹ��������� */
    while(1) {
        printf("\n[NRASRV] Client Socket(%d)", sockfd);         
        if(RECV_CTL(sockfd)==-1)
        {
            close(sockfd); 
            write(fd, (void *)&msg, sizeof(msg));     /* �ڽ����μ��� ���� ��ȯ�ϱ� */
            sockfd = read_fd(fd);                     /* ���ϳѹ��������� */
        } 
    } 
    
    return fd;
} 

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : ��Ƽ�������� ����
---------------------------------------------------------------------------------------------------*/
int main_server(int server_sockfd, struct _SocketInfo *SocketArray, int preforknum, char *sckcnctoption) 
{ 
    int status,i,k,n,j,m,cc,maxfd,data,cnt=0,cnt2=0; 
    int client_sockfd, sv[2],pid;     
    char ptr,TmpBuf[128]={0};   
    fd_set readfds, allfds,readfds_org;  
    pid_t child_pid;
    pthread_t mpid;
    struct timeval tmv;

    FD_ZERO(&allfds); 
    FD_ZERO(&readfds);
    FD_ZERO(&readfds_org);
    FD_SET(server_sockfd, &allfds); 
    for (i = 0; i < preforknum; i++) 
    { 
        FD_SET(SocketArray[i].fd, &allfds); 
        FD_SET(SocketArray[i].fd, &readfds_org); 
        maxfd = SocketArray[i].fd; 
        if(slog.ndisplayLog!=1){
            printf("\n[NRASRV] Socketpair(%d)", maxfd); fflush(stdout);
        }
    } 
    
    while(1) 
    {     
    /* �������� �缼�� */    
        for(i=0; i < maxfd + 1; ++i) {
            if(FD_ISSET(i, &allfds)) {
                FD_SET(i, &readfds);            
            }
            else 
                FD_CLR(i, &readfds);
        }
        n = select(maxfd + 1, &readfds, (fd_set *)0, (fd_set *)0, NULL); 
        if (n < 0) { 
            perror("select"); 
            continue;
        } 
        if (FD_ISSET(server_sockfd, &readfds)) {
            if ((client_sockfd = accept(server_sockfd, 0, 0) == -1)) { perror("accept error:"); STD_PRNT("accept error:"); close(client_sockfd); }
            else { 
                for (i = 0,k=0; i < preforknum; i++) { 
                    if(SocketArray[i].status) { 
                        if(slog.ndisplayLog!=1){
                            printf("Status OK[%d][%d][%d][%d]\n", i, SocketArray[i].pid, SocketArray[i].fd,++cnt2);
                        }
                        if( write_fd(SocketArray[i].fd, &ptr, 1, client_sockfd) == -1 ) { perror("write_fd"); continue; }
                        SocketArray[i].status = 0; 
                        close(client_sockfd); 
                        break; 
                    }
                    if(i+1 == preforknum && k<5) {
                        i=-1; k++;  
                        for(m=0; m < maxfd + 1; ++m) {
                            if(FD_ISSET(m, &readfds_org)) {
                                FD_SET(m, &readfds);                                
                            }
                            else 
                                FD_CLR(m, &readfds);
                        }
                        tmv.tv_sec = 0; tmv.tv_usec = 100000;
                        n = select(maxfd + 1, &readfds, (fd_set *)0, (fd_set *)0, &tmv); 
                        if (n < 0) continue; 
                        for (j = 0; j < preforknum; j++) { 
                            if(FD_ISSET(SocketArray[j].fd, &readfds)) {
                                read(SocketArray[j].fd, (void *)&data, sizeof(data)); 
                                if(data == 0) SocketArray[j].status = 1; 
                                if(data == 1234){  
                                    SocketArray[j].status = 1; 
                                    RECV_CTL_DAILY(SocketArray);                                
                                }
                                FD_CLR(SocketArray[j].fd, &readfds);                            
                            } 
                        }                    
                    }
                } 
                if ( i == preforknum ) {
                    STD_PRNT("Max Client Limit Reached\n");
                    close(client_sockfd);  
                } 
            }             
        } 
        for (i = 0; i < preforknum; i++) { 
            if(FD_ISSET(SocketArray[i].fd, &readfds)) {
                read(SocketArray[i].fd, (void *)&data, sizeof(data)); 
                if(data == 0) SocketArray[i].status = 1; 
                if(data == 1234){  
                    SocketArray[i].status = 1; 
                /*    pthread_create(&mpid, 0, RECV_CTL_DAILY, (void *)SocketArray);    */
                    RECV_CTL_DAILY(SocketArray);    
                    /*for (cc = 0; cc < preforknum; cc++) { 
                        close(SocketArray[cc].fd);                            
                        kill(SocketArray[cc].pid, SIGKILL);        
                        sleep(1);                
                    }*/
                    break;                                
                }
                FD_CLR(SocketArray[i].fd, &readfds);
            } 
        }
        while( (child_pid= waitpid(-1,&status,WNOHANG) ) >0) {        	
            for (i = 0; i < preforknum; i++) { 
               if(SocketArray[i].pid==child_pid) {
               	 memset(&sv, 0, sizeof(sv));
                    close(SocketArray[i].fd);
                    /* SocketArray[i].status = 0; */
                    FD_CLR(SocketArray[i].fd, &allfds);
                    FD_CLR(SocketArray[i].fd, &readfds_org);
                    /*********************************/                    
                    if( socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == -1 ) {
	                perror("socketpair error"); continue;
	              }		                         
                    pid = fork(); 
                    if (pid < 0) { perror("fork error"); exit(0); } 
                    if (pid == 0) { 
                        /* dup2(sv[0], 0);  */
                        close(sv[1]); 
                        /* close(sv[0]);  */
                        close(server_sockfd); 
                        if(sckcnctoption==0 || strcmp(sckcnctoption,"-c")!=0)
                            prefork_client(sv[0],sv[1]);
                        else
                            prefork_client_cont(sv[0]);                        
                    } else { 
                        close(sv[0]); 
                        SocketArray[i].pid    = pid;  
                        SocketArray[i].fd     = sv[1]; 
                        SocketArray[i].status = 1;   
                        FD_SET(SocketArray[i].fd, &allfds);
                        FD_SET(SocketArray[i].fd, &readfds_org);
                        if(SocketArray[i].fd > maxfd)
                            maxfd=SocketArray[i].fd;
                    } 
                    /*********************************/     
                    if(slog.ndisplayLog!=1){
                        printf("\nChild has finished: pid=%d\n",child_pid);
                        printf("return : %d \n",WEXITSTATUS(status));
                    }                    
                    break;
        	}
           }   
        }
    } 
    
    return server_sockfd;
} 

/*--------------------------------------------------------------------------------------------------
 #�Լ� ���         : �ڵ鷯
---------------------------------------------------------------------------------------------------*/
void z_handler(int sig)
{
    pid_t child_pid;
    int status;
    while( (child_pid= waitpid(-1,&status,WNOHANG) ) >0)
    {
        if(slog.ndisplayLog!=1){
            printf("Child has finished: pid=%d\n",child_pid);
            printf("return : %d \n",WEXITSTATUS(status));
        }
    }
    return ;
}
void Signal(void)
{
    signal(SIGALRM,time_out);
}
void time_out(int sig)
{
    if(slog.ndisplayLog!=1)
        printf("���α׷� Ÿ�Ӿƿ��߻�\n");
    
    STD_PRNT("���α׷� Ÿ�Ӿƿ��߻�\n");
    shutdown(client, SHUT_RD); shutdown(client,SHUT_WR);    /* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
    close(client);                                            /* Ŭ���̾�Ʈ ���� ���� */
    close(server);                                            /* �ڽļ��� ���� ���� */
    exit(0);
}
void mtps_time_out(int sig)
{
    if(slog.ndisplayLog!=1)
        printf("���α׷� Ÿ�Ӿƿ��߻�\n");
    
    STD_PRNT("���α׷� Ÿ�Ӿƿ��߻�\n");
    printf("pid=%d\n",getpid());
    shutdown(prsckinfo, SHUT_RD); shutdown(prsckinfo,SHUT_WR);    /* Ŭ���̾�Ʈ �б�, ���� ��Ʈ�� �ݱ� */
    close(prsckinfo);                                            /* Ŭ���̾�Ʈ ���� ���� */
    exit(0);
}

#endif /* _MP */

