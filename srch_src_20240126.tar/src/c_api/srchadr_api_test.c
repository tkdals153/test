#include "srchadr_api.h"

int main(int argc, char *argv[])
{	
	char ZIP[64]={0}, ADM[512]={0}, ADS[512]={0};	
	int i,k=0,j;	
	char Temp[25][128];
	char szTmp[128], szDst[4096], szRCD[16], szRMG[128], szNext[4],szTime[64];
	int nBlockCnt, nTotalCnt;
	
	memset(Temp,0,sizeof(Temp));
	
	if( argc >= 1 ) {		
		/*================================================================================*/
		/* call rfnadr api */
		srchadr_enablelog(1);								/* set write file log */
		srchadr_setlogpath("./log");							/* set file log path */
	
		/* set engine ip address */
		SetEngineProp("127.0.0.1", 5000);					
		while(1){
			k++;			
			fgets(ADM, sizeof(ADM), stdin);
			/*strcpy(ADM,"�߱� ����17 16���漾Ʈ����ũ");*/
			/*strcpy(ADM,"�߾ӷ�");*/
			get_time("TTMMSSUU", szTime);
			printf("\n[%s] ADDRESS(Input) :%s\n ",szTime,ADM); 
			if( SrchAddr_page(ADM,1,10) ) {	
				
				GetTotalCnt(szTmp); nTotalCnt=atoi(szTmp);
				printf("TotalCnt=%d\n",nTotalCnt);
				
				GetCnt(szTmp);nTotalCnt=atoi(szTmp);
				
				for (i = 0; i < nTotalCnt; i++) {
					for (j = 0; j < 15; j++){
						GetAddrList(i, j, szDst);						
						printf("[%s]\n", szDst);
					}		
				}			  
			}
			get_time("TTMMSSUU", szTime);
			printf("[%s] count=%d\n",szTime,k);
		}	
		/*================================================================================*/		
		
	} else {
		printf("usage : rfn [zip] [adm] [ads] [reqLoc(start with 1)]\n");
		return 0;
	}
	
	return 1;
}
