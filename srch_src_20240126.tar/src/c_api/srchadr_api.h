#ifndef __SRCH_API_H__
#define __SRCH_API_H__
#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
/* TCP/IP headers */
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>

#define PACKET_HDR "#CTL:SRCH:TXT="					/* ��Ŷ��� ���*/
#define PACKET_SIZ 14
/*------------------------------------------------------------------------------------------------------------*/
/* ���й��ڿ��� �������� �ڷḦ �������� �ʵ�� �и��ϱ� ���� �Լ��� ���� ������ ����                         */
#define SEP_FLD_MAX 150		/* 2012. 09. 13 by Polaris : �и� MAX�� ���� */
typedef struct _SEPFLD{
	char *SRC;
	char  GB[4];
	char *pt[SEP_FLD_MAX];
	int   ln[SEP_FLD_MAX];
	int   cnt;
} SEPFLD;
/*-----------------------------------------------------------------------------------------------*/
typedef struct _serverinfo {
	char szIPAddr[64];
	int nPort;
} SVRINFO;
/*-----------------------------------------------------------------------------------------------*/

int SetEngineProp(char *pszIPAddr, int nPort);
int SrchAddr(char *keyword);
int SrchAddr_page(char *keyword,int idx,int pCnt);
/*-----------------------------------------------------------------------------------------------*/
void GetAddrList(int index, int column, char *pszDst);
void GetTotalCnt(char *pszDst);
void GetCnt(char *pszDst);
/*-----------------------------------------------------------------------------------------------*/
int ConnectServer(const char *pszIP, unsigned short nPort);
void DisConnectServer(int *s);
int SearchAddress(char * pIP, int nPort, char *lpSrc, char *lpDst);
int SendRecv(int hSock, char * pszSrc, char * pszDst);
/*-----------------------------------------------------------------------------------------------*/
int logg(char *str);
void get_time(const char *pszFormat, char *pszDst);
void SEPARRY(SEPFLD *ss);
int QuotedStringCHK(char *lpSrc,char *GB);
int SEPCHRS(SEPFLD *ss,char *lpSrc,char *GB,int nMax);
void srchadr_enablelog(int SW);
void srchadr_setlogpath(const char *pszPath);
int IFSE(const char *lpStr1, const char *lpStr2);

#ifdef __cplusplus
}
#endif
#endif /* __SRCH_API_H__ */

