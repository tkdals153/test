#include "srchadr_api.h"

/*--------------------------------------------------------------------------------------*/
/* gloval vars */
static			int   bLOG=0;										/* log switch */
static          char  LOG_PATH[256]="./";                           /* log path */
/*-----------------------------------------------------------------------------------------------*/
static SVRINFO si;
char szTmpBuf[1024], TmpData[40000],OutRecData[1000000];
char OutRec[1000][1024];
/*-----------------------------------------------------------------------------------------------*/
void sep2Token(char *gubun, char *lpSrc, char lpDest[1000][1024]);
/*-----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------------*/
/* call refine search engine 														    */
/*--------------------------------------------------------------------------------------*/
int SrchAddr(char *keyword)
{
	char szTotal[5] = { 0 };
	char szKeyWord[512] = { 0 },TmpBuf[1024];
	
	if (szKeyWord == 0) return 0;
	if (*si.szIPAddr == 0 || si.nPort == 0) return 0; 
	memset(OutRecData, 0, sizeof(OutRecData));
	/*-------------------------------------------------------------------------------------------*/
	/* CALL BY VALUE */
	strcpy(szKeyWord, keyword); 

	/*-------------------------------------------------------------------------------------------*/
	sprintf(szTmpBuf, "=== SearchAddr : [%s]", szKeyWord); logg(szTmpBuf);
	sprintf(TmpBuf, "%s%s", PACKET_HDR, szKeyWord);
	
	if (!SearchAddress(si.szIPAddr, si.nPort, TmpBuf, OutRecData)) {
		strcpy(szTmpBuf, "*** SearchAddress : failure"); logg(szTmpBuf);
		return 0;
	}
	memset(OutRec, 0, sizeof(OutRec));
	strncpy(szTotal, OutRecData+6, 4);
	if (atoi(szTotal) != 0)
		sep2Token("~|", OutRecData + 14, OutRec);	
	/*-------------------------------------------------------------------------------------------*/
	return atoi(szTotal);
}
/*--------------------------------------------------------------------------------------*/
/* call refine search engine 														    */
/*--------------------------------------------------------------------------------------*/
int SrchAddr_page(char *keyword,int idx,int pCnt)
{
	char szTotal[5] = { 0 };
	char szKeyWord[512] = { 0 },TmpBuf[1024];
	
	if (szKeyWord == 0) return 0;
	if (*si.szIPAddr == 0 || si.nPort == 0) return 0; 
	memset(OutRecData, 0, sizeof(OutRecData));
	/*-------------------------------------------------------------------------------------------*/
	/* CALL BY VALUE */
	strcpy(szKeyWord, keyword); 

	/*-------------------------------------------------------------------------------------------*/
	sprintf(szTmpBuf, "=== SearchAddr : [%s]", szKeyWord); logg(szTmpBuf);
	sprintf(TmpBuf, "%s%s|%d|%d", PACKET_HDR, szKeyWord,idx,pCnt);
	
	if (!SearchAddress(si.szIPAddr, si.nPort, TmpBuf, OutRecData)) {
		strcpy(szTmpBuf, "*** SearchAddress : failure"); logg(szTmpBuf);
		return 0;
	}
	memset(OutRec, 0, sizeof(OutRec));
	strncpy(szTotal, OutRecData+10, 4);
	if (atoi(szTotal) != 0)
		sep2Token("~|", OutRecData + 14, OutRec);	
	/*-------------------------------------------------------------------------------------------*/
	return atoi(szTotal);
}
int SearchAddress(char * pIP, int nPort, char *lpSrc, char *lpDst)
{
	int hSock=-1;

	/*-------------------------------------------------------------------------------------------*/
	if ((hSock = ConnectServer(pIP, nPort)) <= 0) return 0;
	if (SendRecv(hSock, lpSrc, lpDst) == 0) {		
		DisConnectServer(&hSock);
		return 0;
	}	
	/*-------------------------------------------------------------------------------------------*/
	DisConnectServer(&hSock);


	return 1;
}
/*--------------------------------------------------------------------------------------*/
/* set search engine        														    */
/*--------------------------------------------------------------------------------------*/
int SetEngineProp(char *pszIPAddr, int nPort)
{
	memset(&si, 0, sizeof(SVRINFO));
	if( pszIPAddr == 0 || nPort <= 0 || nPort >= 65535 ) return 0;	

	strcpy(si.szIPAddr, pszIPAddr); si.nPort=nPort;
	sprintf(szTmpBuf, "=== SetEngineProp : %s:%d", pszIPAddr, nPort); logg(szTmpBuf);
	
	return 1;
}


/*-----------------------------------------------------------------------------------------------*/
/* �ּҸ�� ���� */
/*-----------------------------------------------------------------------------------------------*/
 void GetAddrList(int index, int column, char *pszDst)
{
	char TmpBuf[256], szTotal[5] = { 0 };
	int nBlock=0;
	SEPFLD ss;

	strncpy(szTotal, OutRecData + 6, 4); nBlock = atoi(szTotal);
	memset(&TmpData, 0, sizeof(TmpData));	
	/*-------------------------------------------------------------------------------------------*/
	if( index >= 0 && index < nBlock  ) {				/* index ��û��ġ�� ���� ī��Ʈ���� �۾ƾ��Ѵ�	*/	
		sprintf(TmpBuf, "=== GetAddrList(%d/%d) %d column", index + 1, nBlock, column); logg(TmpBuf);
		strcpy(TmpData, OutRec[index]);
		SEPCHRS(&ss, TmpData, "^|", 100); 
		SEPARRY(&ss);
		strcpy(pszDst, ss.pt[column]); logg(pszDst);
		/*---------------------------------------------------------------------------------------*/
	} else {
		sprintf(TmpBuf, "=== GetAddrList(%d) : Invalid index", index); logg(TmpBuf);
		strcpy(pszDst, "");
		/*---------------------------------------------------------------------------------------*/
	}
}
/*-----------------------------------------------------------------------------------------------*/
/* ������ ����(���ŵ� ������ �Ǽ�) */
/*-----------------------------------------------------------------------------------------------*/
void GetCnt(char *pszDst)
{
	char TmpBuf[6]={0};	
	memcpy(TmpBuf, OutRecData + 10, 4);
	strcpy(pszDst, TmpBuf);
}
/*-----------------------------------------------------------------------------------------------*/
/* ������ ��ü ���� */
/*-----------------------------------------------------------------------------------------------*/
void GetTotalCnt(char *pszDst)
{
	char TmpBuf[6]={0};	
	memcpy(TmpBuf, OutRecData + 6, 4);
	strcpy(pszDst, TmpBuf);
}


/*--------------------------------------------------------------------------------------*/
/* switch file log			 														    */
/*--------------------------------------------------------------------------------------*/
void srchadr_enablelog(int SW)
{
	if( SW == 1 ) bLOG=1;
	else bLOG=0;
}
/*--------------------------------------------------------------------------------------*/
/* set log path(default : current directory)                                            */
/*--------------------------------------------------------------------------------------*/
void srchadr_setlogpath(const char *pszPath)
{
	char TmpBuf[256];
	
	if( pszPath == 0 ) return;
	strcpy(LOG_PATH, pszPath); if( LOG_PATH[strlen(LOG_PATH)] != '/' ) strcat(LOG_PATH, "/");
	sprintf(TmpBuf, "[rfnadr_setlogpath] log path : %s", LOG_PATH); logg(TmpBuf);
}

void sep2Token(char *gubun, char *lpSrc, char lpDest[1000][1024])
{
	int i = 0, j = 0, k = 0;
	while (1)
	{
		if (lpSrc[k] != 0 && (lpSrc[k] != *gubun || lpSrc[k + 1] != *(gubun + 1)))
			lpDest[i][j++] = lpSrc[k++];
		else if (lpSrc[k] == 0)
			break;
		else
		{
			lpDest[i][j] = 0;
			i++, k++; k++;
			j = 0;
		}
	}
}
int SEPCHRS(SEPFLD *ss,char *lpSrc,char *GB,int nMax)
{
	int i,j,nCnt=0;
	size_t n;

	if ( ss!=0 ){ ss->cnt=0; ss->SRC=lpSrc; ss->pt[0]=lpSrc; if ( GB!=0 ) strcpy(ss->GB,GB); }
	if ( lpSrc==0 || ss==0 || GB==0  || *GB==0 ) return 0;n=strlen(GB);
	/*--------------------------------------------------------------------------------------------------------------*/
	while(*lpSrc!=0){
		for( i=0; lpSrc[i]!=0 ; i++ ){
			/*----------------------------------------------------------------------------------------------*/
			if ( IFSE(GB,lpSrc+i)!=0 ) break;
			if ( lpSrc[i]=='&' && lpSrc[i+1]=='#' && (lpSrc[i+2]>='0' && lpSrc[i+2]<='9') ){
				for( j=i+2; lpSrc[j]!=0 && (lpSrc[j]>='0' && lpSrc[j]<='9') ; j++ ); i=j; if ( lpSrc[i]!=';' ) i--;
			}
			else if ( IFSE("&nbsp;",lpSrc+i)!=0 || IFSE("&NBSP;",lpSrc+i)!=0 ) i+=5;
			/*----------------------------------------------------------------------------------------------*/
			/* ������ ����ǥó����ƾ�� �����ϴ�( n==1 �����߰� )! */
			if ( lpSrc[i]=='\"' && i==0 && n==1 ){
				i+=QuotedStringCHK(lpSrc+i,GB); if ( lpSrc[i]==0 ) break; /* ����ǥ ���ڴ� ���� ����ǥ����! */
			}
			/*----------------------------------------------------------------------------------------------*/
		}
		ss->pt[nCnt]=lpSrc; ss->ln[nCnt]=i; nCnt++; lpSrc+=i; if ( *lpSrc==0 ) break; lpSrc+=n;
		if ( *lpSrc==0 ){ss->pt[nCnt]=lpSrc; ss->ln[nCnt]=0; nCnt++; break;}
		if ( nCnt>=nMax ) break;
	}
	/*--------------------------------------------------------------------------------------------------------------*/
	ss->cnt=nCnt; for( i=nCnt,n=0; i<nMax && n<10; ss->pt[i]=0,ss->ln[i]=0, n++,i++ );
	return nCnt;
}

int IFSE(const char *lpStr1, const char *lpStr2)
{
	int i=0;
	if ( lpStr1==0 || lpStr2==0 ) return 0;
	while ( lpStr1[i]==lpStr2[i] ){
		if ( lpStr1[i] == 0 ) return i;	i++;
	}
	if ( lpStr1[i] == 0 ) return i;
	return 0;
}

void SEPARRY(SEPFLD *ss)
{
	int i;
	if ( ss==0 || ss->cnt<=1 ) return;
	for(i=0;i<ss->cnt;ss->pt[i][ss->ln[i]]=0,i++); return;
}
int QuotedStringCHK(char *lpSrc,char *GB)
{
	int i,nCnt;

	for( i=1,nCnt=0; lpSrc[i]!=0 ; i++ ){
		if ( lpSrc[i]==GB[0] && IFSE(GB,lpSrc+i)!=0 ) nCnt++;
		if ( IFSE("&nbsp;",lpSrc+i)!=0 ) i+=6;
		if ( lpSrc[i]=='\"' ){
			if ( lpSrc[i+1]==0 || IFSE(GB,lpSrc+i+1)!=0 ) return i;
			else if ( nCnt!=0 ) return i;
			else continue;
		}
		if ( lpSrc[i]==0 ) break;
	}
	return 0;
}

/*--------------------------------------------------------------------------------------*/
/* write file logs 																	    */
/*--------------------------------------------------------------------------------------*/
int logg(char *pszStr)
{
	FILE *fp=0;
	char szTime[64], szLogPath[256];
	int nByte=0;
	
	if( pszStr == 0 || bLOG == 0 ) return 0;
	/*----------------------------------------------------------------------------------*/
	get_time("YYYYMMDD", szTime); sprintf(szLogPath, "%ssrchadr_%s.log", LOG_PATH, szTime);
	if( (fp=fopen(szLogPath, "ab")) == 0 ) return 0;
	/*----------------------------------------------------------------------------------*/
	get_time(0, szTime); nByte=fprintf(fp, "[%s] %s\n", szTime, pszStr); fflush(fp); fclose(fp);
	/*----------------------------------------------------------------------------------*/
	return nByte;
}

/*--------------------------------------------------------------------------------------*/
/* get current time		 															    */
/*--------------------------------------------------------------------------------------*/
void get_time(const char *pszFormat, char *pszDst)
{
	struct timeval tv;
	struct tm *local;
	
	if( pszDst == 0 ) return; *pszDst=0;
	/*----------------------------------------------------------------------------------*/
	gettimeofday(&tv, 0); local=(struct tm*)localtime((time_t*)&tv.tv_sec);
	
	if( pszFormat != 0 && strcmp(pszFormat, "YYYYMMDD") == 0 ) {
		sprintf(pszDst, "%d%02d%02d", local->tm_year + 1900, local->tm_mon +1, local->tm_mday);
	} 
	else if( pszFormat != 0 && strcmp(pszFormat, "TTMMSSUU") == 0 ) {	
		sprintf(pszDst, "%.2d:%.2d:%.2d:%.4d", local->tm_hour, local->tm_min, local->tm_sec, (int)(tv.tv_usec/100));		
	} 
	else {
		sprintf(pszDst, "%d-%02d-%02d %02d:%02d:%02d", local->tm_year + 1900, local->tm_mon +1, 
					local->tm_mday, local->tm_hour, local->tm_min, local->tm_sec);
	}	
	/*----------------------------------------------------------------------------------*/
}
