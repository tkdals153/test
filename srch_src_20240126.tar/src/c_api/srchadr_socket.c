#include "srchadr_api.h"

int connect_with_timeout(int sockfd, struct sockaddr *saddr, int addrsize, unsigned long timeout_milli) ;
/*------------------------------------------------------------------------------------------------*/
/* connect to server */
/*------------------------------------------------------------------------------------------------*/
int ConnectServer(const char *pszIP, unsigned short nPort)
{
	struct sockaddr_in server_addr;
	struct linger linger;
	struct timeval tv;
	int client_socket=-1;
        char TmpBuf[256]={0};

	if( pszIP == 0 || *pszIP == 0 || nPort <= 0 ) return -1;
	/*--------------------------------------------------------------------------------------------*/
	if( (client_socket  = socket( AF_INET, SOCK_STREAM, 0)) == -1 ) {
		if( (client_socket  = socket( AF_INET, SOCK_STREAM, 0)) == -1 ) {
	return -1;
		}
	} 
	/*--------------------------------------------------------------------------------------------*/
	linger.l_onoff = 1;
	linger.l_linger = 1;
	tv.tv_sec = 3;
	tv.tv_usec = 0;
	/*--------------------------------------------------------------------------------------------*/
	setsockopt(client_socket, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
	setsockopt(client_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	setsockopt(client_socket, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
	/*--------------------------------------------------------------------------------------------*/
	memset(&server_addr, 0, sizeof( server_addr));
	server_addr.sin_family     = AF_INET;
	server_addr.sin_port       = htons(nPort);
	server_addr.sin_addr.s_addr= inet_addr(pszIP);
	/*--------------------------------------------------------------------------------------------*/
	/*if (connect_with_timeout(client_socket, (struct sockaddr*)&server_addr,sizeof(server_addr), 1000) < 0){			
			return -1;	
	}*/
	if( connect( client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr) ) == -1 ) {
		if( connect( client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr) ) == -1 ) {
			return -1;
		}
	}
	/*--------------------------------------------------------------------------------------------*/
	return client_socket;}

/*------------------------------------------------------------------------------------------------*/
/* disconnect server */
/*------------------------------------------------------------------------------------------------*/
void DisConnectServer(int *s)
{
	shutdown(*s, SHUT_RD); shutdown(*s, SHUT_WR);
	close(*s); *s=0;
}

int connect_with_timeout(int sockfd, struct sockaddr *saddr, int addrsize, unsigned long timeout_milli) 
{ 
    int newSockStat; 
    int orgSockStat; 
    int res, n; 
    fd_set  rset, wset; 
    struct timeval timeout;
 
    int error = 0; 
    int esize; 
 
    if ( (newSockStat = fcntl(sockfd, F_GETFL, NULL)) < 0 )  
    { 
        perror("F_GETFL error"); 
        return -1; 
    } 
 
    orgSockStat = newSockStat; 
    newSockStat |= O_NONBLOCK; 
 
    /* Non blocking ���·� �����. */ 
    if(fcntl(sockfd, F_SETFL, newSockStat) < 0) 
    { 
        perror("F_SETLF error"); 
        return -1; 
    } 
 
    /* ������ ��ٸ���. 
     Non blocking �����̹Ƿ� �ٷ� �����Ѵ�. */     
    if((res = connect(sockfd, saddr, addrsize)) < 0) 
    {     	
        if (errno != EINPROGRESS) 
            return -1;         
    }   
    /* ��� ������ �������� ��� ������ ���� ���·� �ǵ����� �����Ѵ�.  */
    if (res == 0) 
    { 
        printf("Connect Success\n"); 
        fcntl(sockfd, F_SETFL, orgSockStat); 
        return 1; 
    } 
 
    FD_ZERO(&rset); 
    FD_SET(sockfd, &rset); 
    wset = rset; 
 
    timeout.tv_sec = timeout_milli / 1000;
    timeout.tv_usec = (timeout_milli % 1000) * 1000;
 
    if ( (n = select(sockfd+1, &rset, &wset, NULL, &timeout)) == 0) 
    { 
        /* timeout */
        errno = ETIMEDOUT;     
        printf("errno=%s\n",strerror(errno));
        return -1; 
    } 
    
    if (FD_ISSET(sockfd, &rset) || FD_ISSET(sockfd, &wset) ) 
    {         
        esize = sizeof(int); 
        if ((n = getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, (socklen_t *)&esize)) < 0) {
        	printf("errno2=%s\n",strerror(errno));
            return -1; 
        }
    } 
    else 
    { 
        perror("Socket Not Set"); 
        return -1; 
    } 
 
 
    fcntl(sockfd, F_SETFL, orgSockStat); 
    if(error) 
    { 
    	close(sockfd);      /* just in case */
        errno = error; 
        perror("Socket"); 
        return -1; 
    } 
 
    return 1; 
} 
int SendRecv(int hSock, char * pszSrc, char * pszDst)
{
	char TmpBuf[51200]={0};
	int nTotByte=0, nRecvDat=0;
	int nRecvB;	
	char DataLen[16]={0},szTime[64];
	int nDataLen = 0;
	int nFail=0,ncnt=0;

	if( hSock <= 0 || pszSrc == 0 || pszDst == 0 ) 
		return 0; 	
	/*-------------------------------------------------------------------------------------------*/	
	if (send(hSock, pszSrc, strlen(pszSrc), 0) <= 0) {	/* ��Ŷ����� ������ �������� �Է� �ּ�*/
		sprintf(TmpBuf, "[ERROR] [SendRecv]   packet send error"); logg(TmpBuf);
		return -1;
	} 
	/*sprintf(TmpBuf, "=== Send : %s", pszSrc); logg(TmpBuf);*/ 
	/*get_time("TTMMSSUU", szTime);
	printf("[%s]%s\n",szTime,TmpBuf);*/
	/*-------------------------------------------------------------------------------------------*/	
	/* HEADER, ��������ŭ �ޱ� */
	/*do {		
	
		nRecvB = recv(hSock, &pszDst[nTotByte], 6, 0);				
		
		if( nRecvB > 0 ) nTotByte += nRecvB;		
		ncnt++;
		if (ncnt > 5){
			sprintf(TmpBuf, "*** recv1 : failure"); logg(TmpBuf);
			return 0;
		}
	} while (nTotByte < 6); 	*/
	/*-------------------------------------------------------------------------------------------*/	
	if( (nRecvB = recv(hSock, &pszDst[nTotByte], 6, 0)) <0){
		sprintf(TmpBuf, "*** recv1 : failure"); logg(TmpBuf);
			return 0;
	}
	printf("header recv[%d][%s]\n", nRecvB, pszDst);
	nTotByte += nRecvB;
/*	get_time("TTMMSSUU", szTime);
	printf("[%s]recv1\n",szTime);*/
	/* DATA */	
	strncpy(DataLen, pszDst, 6); 	nDataLen = atoi(DataLen); /* ������ ���� ���� ���	*/
	/*sprintf(TmpBuf, "=== SendRecv : * dat_size(%d/%d)", nTotByte-6, nDataLen); logg(TmpBuf); */

	do {
		nRecvB = recv(hSock, &pszDst[nTotByte], nDataLen, 0);					/* �����ŭ �ޱ� */
		/*sprintf(TmpBuf, "=== SendRecv :   ����recv (%d)", nRecvB); logg(TmpBuf);*/ 
		if( nFail > 10 ) return 0;
		if( nRecvB > 0 ) { nRecvDat+=nRecvB; nTotByte+=nRecvB; }
		else {
			sprintf(TmpBuf, "=== SendRecv :   ����failed (%d)", nFail++); logg(TmpBuf); 
		}
		/*sprintf(TmpBuf, "=== SendRecv : * dat_size(%d/%d)", nTotByte-6, nDataLen); logg(TmpBuf); */

		if( nRecvDat == nDataLen ) break;
	} while(nRecvDat < nDataLen);
	
	/*-------------------------------------------------------------------------------------------*/	
	if( (6+nDataLen) < nTotByte ) {
		sprintf(TmpBuf, "*** SendRecv : every packet has not arrived(%d/%d) ", nTotByte, (6+nDataLen)); logg(TmpBuf); 
	}

	return nTotByte;
}
