#include "srchsrv.h"

#include <netdb.h>
#include <netinet/in.h>

int GET_PROC(char *PID) ;
	
/*--------------------------------------------------------------------------------------------------
#�Լ� ��� : ���� ������ ���Ͽ��� �б� ���Ⱑ �߻������� ��������
---------------------------------------------------------------------------------------------------*/
void sig_handler(int c)
{
	close(c);
}


/*--------------------------------------------------------------------------------------------------
#�Լ� ��� : PID������ �����Ѵ�.
#�Լ� RETURN : ����(1), ����(0)
---------------------------------------------------------------------------------------------------*/
int write_pid(char *pszPIDNAME)
{
	FILE *stream;
	char z_pid[64];

	if((stream = fopen(pszPIDNAME, "ab")) != 0) {
		sprintf(z_pid, "%d\n", getpid());
		fputs(z_pid, stream);
		fflush(stream); fclose(stream);
		return 1;
	}
	else { perror("Faild to write PID file\n"); return 0; }
}


/*--------------------------------------------------------------------------------------------------
#�Լ� ��� : ���� ����
---------------------------------------------------------------------------------------------------*/
void f_daemon(void)
{
	pid_t   pid;
	if (( pid = fork()) < 0) exit(0);
	else if(pid != 0) exit(0); /* �θ����μ����� �����Ѵ�. */
	
	setsid();
}


/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : �������� ����
---------------------------------------------------------------------------------------------------*/
void SETT_ENGINE(int nDisp, int nProg)
{	
	char TmpBuf2[1024], TmpBuf[1024], envpath[256];
	
	/*--------------------------------------------------------------------------------------------*/
	/* �޸� �Ҵ� */
	STD_PRNT("Allocating Memory");
	GetEnvIniString( pConfig, "MEMORY", "socket_read", TmpBuf, sizeof(TmpBuf) ); READ_SIZ=atoi(TmpBuf);
	GetEnvIniString( pConfig, "MEMORY", "socket_write", TmpBuf, sizeof(TmpBuf) ); WRITE_SIZ=atoi(TmpBuf);

	/*--------------------------------------------------------------------------------------------*/
	/* ���������� �ε� */	
	STD_PRNT("The Engine is Loading Reference Data...");
	strcpy(TmpBuf, g_szAbsPath);
	GetEnvIniString(pConfig, "GENERAL", "refdata", TmpBuf+strlen(TmpBuf), sizeof(TmpBuf));
	if( *TmpBuf != 0 ) {
		sprintf(TmpBuf2, "RefData : %s", TmpBuf); STD_PRNT(TmpBuf2);
		POI_LoadAllPOIData(TmpBuf, 1, 0);
	}
	else {
		STD_PRNT("Please check the configure file");
		ERR_EXIT("Can't locate refdata, envfile"); if( bError ) return;
	}	
		
	STD_PRNT("Reference data has been successfully loaded in memory");

	/*-------------------------------------------------------------------------------------------*/
	/* �Է� ��ũ�� ���� */	
/*	GetEnvIniString( pConfig, "MACROS", "input_zip", MZIP, sizeof(MZIP) );
	GetEnvIniString( pConfig, "MACROS", "input_adm", MADM, sizeof(MADM) );
	GetEnvIniString( pConfig, "MACROS", "input_ads", MADS, sizeof(MADS) );
	GetEnvIniString( pConfig, "MACROS", "encoding", MENC, sizeof(MENC) );
	GetEnvIniString( pConfig, "MACROS", "input_nyn", MNYN, sizeof(MNYN) );

	sprintf(TmpBuf, "INPUT MAC SET : %s %s %s", MZIP, MADM, MADS); STD_PRNT(TmpBuf);
	sprintf(TmpBuf, "Encoding Set : %s", MENC); STD_PRNT(TmpBuf);	
	sprintf(TmpBuf, "Input ADR Type Set : %s", MNYN); STD_PRNT(TmpBuf);	
	*/
	/*-------------------------------------------------------------------------------------------*/
	/* XML ��� ��ũ�� ���� */
	GetEnvIniString( pConfig, "MACROS", "output_mac", OMAC_XML, sizeof(OMAC_XML) );
	if( *OMAC_XML != 0 ) {
		sprintf(TmpBuf, "OUTPUT MAC SET(XML+BATCH) : %s", OMAC_XML); STD_PRNT(TmpBuf);
	} else STD_PRNT("[INFO] The XML+BATCH Output Macro is not set");		

	/*-------------------------------------------------------------------------------------------*/
	strcpy(TmpBuf, g_szAbsPath);  strcat(TmpBuf, "output.conf");
	/*-------------------------------------------------------------------------------------------*/
	/* ����ڵ� ������ ���� */
	GetEnvIniString( pConfig, "GENERAL", "COD_GB", GetCODGB(), sizeof(GetCODGB()) );
	/*-------------------------------------------------------------------------------------------*/
	/* XML ��� �ʱ�ȭ ���� */
	/*strcpy(TmpBuf, g_szAbsPath);  strcat(TmpBuf, "xml.conf");
	if( !MakeXML_Init(TmpBuf) ) {
		STD_PRNT("Please check the XML configure file");
		ERR_EXIT("The XML Config is not set"); if( bError ) return;
	}
	*/
	/*-------------------------------------------------------------------------------------------*/
	/* �Է°˻� �α� ���� */
	GetEnvIniString( pConfig, "LOGGING", "nrasrv_log", TmpBuf, sizeof(TmpBuf) );
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.bNraLog=1;
		STD_PRNT("Input Search Logging Enabled");	
	} else {
		slog.bNraLog=0;	
		STD_PRNT("Input Search Logging Disabled");
	}
	/* �˻���� �α� ���� */
	GetEnvIniString( pConfig, "LOGGING", "nrasrvR_log", TmpBuf, sizeof(TmpBuf) );
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.bNraLogR=1;
		STD_PRNT("Output Search Logging Enabled");	
	} else {
		slog.bNraLogR=0;	
		STD_PRNT("Output Search Logging Disabled");
	}
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : ���ϼ��� ����
---------------------------------------------------------------------------------------------------*/
void SOCK_SETTING()
{
    struct hostent     *he;
    char szHostName[128];

	struct  sockaddr_in server_addr;	/* ���� ���� ���� */
	struct linger linger;				/* linger option */
	int nPort=0, on=1;					/* Port Number */
	char TmpBuf[512];
	BOOL optval = TRUE;	
	/*--------------------------------------------------------------------------------------------*/
	GetEnvIniString(pConfig, "NETWORK", "port", TmpBuf, sizeof(TmpBuf) ); nPort=atoi(TmpBuf);
	if( nPort == 0 || nPort > 65535 ) {
		STD_PRNT("Please check the configure file (port)");
		ERR_EXIT("Socket Port is not set");
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ���� */
	if( (server = socket(AF_INET, SOCK_STREAM, 0)) == -1 ) {
		STD_PRNT("Can't Create Server Socket");
		ERR_EXIT("Server Socket is 0");
	} 
	/*--------------------------------------------------------------------------------------------*/
	/* �������� ���� ���� */
#if 0	/* hostname ���� IP�� ���� �����ϰ� �ϴ� �ڵ�������, �� �ȵǹǷ� �ϴ� ���Ƶд�. */
    /* htonl(INADDR_ANY)�� ���� �ʰ� �̷��� �õ��� �ϴ� ������, � ���������� Ŭ���̾�Ʈ�� ���ӵǾ� �ִ� ���¿��� 
       ������ ��⵿�� �ϰ� �Ǹ� ������ ����� ������ ���� Ŭ���̾�Ʈ ������ bind ������ ���� �����̴�.
       (�̰��� ���ϱ� ���ؼ��� ���� �����ǿ� ���� �ɼǿ� REUSEADDR �� ����ؾ߸� �Ѵ�.)
       �̶����� nrasrv.conf �� ipaddr �� �Է¹������� �Ͽ�����, �Ｚ���ǿ��� �׷��� �ϸ� ���ȿ� ����ȴٰ� �ϹǷ�
       �� ����� ����� �� �� ���� �Ǿ���. �׷��� ���� ȣ��Ʈ�� �����Ǹ� ���� �ϴµ�, ������ ���� ���α׷�������
       ������µ� �̰����� �ϸ� ���и� �Ѵ�. ���߿� ���� �ľ��� �ؼ� �����ؾ� ��.
    */
    gethostname(szHostName, sizeof(szHostName));
    if ((he = gethostbyname(szHostName)) == NULL) {
        printf("nslookup failed \n");
    }
    printf("\nMy hostname : %s\n", szHostName);
    printf("IP Address : %s\n", inet_ntoa(*(struct in_addr *)he->h_addr));
    server_addr.sin_addr.s_addr = ((struct in_addr *)he->h_addr)->s_addr;
#else
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
#endif
    server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(nPort); 
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ���� */
	GetEnvIniString(pConfig, "NETWORK", "l_onoff", TmpBuf, sizeof(TmpBuf)); linger.l_onoff = atoi(TmpBuf);
	GetEnvIniString(pConfig, "NETWORK", "l_linger", TmpBuf, sizeof(TmpBuf)); linger.l_linger = atoi(TmpBuf);
	if(setsockopt(server, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger)) < 0) {
		STD_PRNT("Socket configuration(SO_LINGER) not applied");
	}
	/*--------------------------------------------------------------------------------------------*/
	/* Async ��� �����ε� */
		GetEnvIniString(pConfig, "NETWORK", "dst_ipaddr", TmpBuf, sizeof(TmpBuf));
	if( *TmpBuf != 0 ) { saa.bAsync=1; strcpy(saa.szDstIP, TmpBuf); }
	else saa.bAsync=0;
	GetEnvIniString(pConfig, "NETWORK", "dst_port", TmpBuf, sizeof(TmpBuf));
	if( *TmpBuf != 0 ) saa.nPort=atoi(TmpBuf);
	if( saa.bAsync ) {
		sprintf(TmpBuf, "Async Enabled(Destination : %s:%d)", saa.szDstIP, saa.nPort);
		STD_PRNT(TmpBuf);
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� Ÿ�Ӿƿ� ���� */
	GetEnvIniString(pConfig, "NETWORK", "timeout", TmpBuf, sizeof(TmpBuf)); 
	
	if(atoi(TmpBuf)>=30){
		tv.tv_sec = atoi(TmpBuf) / 1000;
   		tv.tv_usec = (atoi(TmpBuf) % 1000) * 1000;		
	}
	else{
		tv.tv_sec = atoi(TmpBuf); tv.tv_usec = 0;
	}

	if(setsockopt(server, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
		STD_PRNT("Socket configuration(SO_RCVTIMEO) not applied");
		
	}
	if(setsockopt(server, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
		STD_PRNT("Socket configuration(SO_SNDTIMEO) not applied");
		
	}
	setsockopt(server, SOL_SOCKET, SO_KEEPALIVE, (char*)&optval, sizeof(optval));

	/*--------------------------------------------------------------------------------------------*/
	/* ���� ���� ���� */
	GetEnvIniString(pConfig, "NETWORK", "socket_reuse", TmpBuf, sizeof(TmpBuf)); 
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		if(setsockopt(server, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0) {
			STD_PRNT("Socket Configuration Failed");
			close(server);
			ERR_EXIT("setsockopt(SO_REUSEADDR)");
		}
	}
#if 0
	/*--------------------------------------------------------------------------------------------*/
	/* ���� non����ŷ ��� ���� */
	if(ioctl(server, FIONBIO, (char *)&on) < 0) {
		STD_PRNT("ioctl() failed");
		close(server);
		ERR_EXIT("ioctl()");
	}
	/*--------------------------------------------------------------------------------------------*/
	/* ���� ����ŷ ��� ���� */
	/* setNonBlockSock(server); */
#endif
	/*--------------------------------------------------------------------------------------------*/	
	/* ���� ���ε� */
	if( bind(server, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1 ) {
		STD_PRNT("Socket Binding Failed");
		sprintf(TmpBuf, "\n\nbind: %s", strerror(errno)); 
		ERR_EXIT(TmpBuf);
	}
	/*--------------------------------------------------------------------------------------------*/	
	/* ���� ������ */
	if( listen(server, SOMAXCONN) == -1 ) { 
		STD_PRNT("Socket Listening Failed");
		sprintf(TmpBuf, "listen: %s", strerror(errno)); 
		ERR_EXIT(TmpBuf);
	} else {
		sprintf(TmpBuf, "Server is Listening at Port Number %d", nPort);
		STD_PRNT(TmpBuf);
	}
	/*--------------------------------------------------------------------------------------------*/			
	client = server + 1; 
	GetEnvIniString(pConfig, "NETWORK", "L4_IP", L4_IP, sizeof(L4_IP) );
}


/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : PID ������ Ȯ���Ͽ� ���μ��� ���࿩�� �Ǵ�
---------------------------------------------------------------------------------------------------*/
void CHK_PROCESS(char *pszPIDNAME)
{
	int i;
	char szPID[64]={0}, TmpBuf[128];
	FILE *t_file;

	if((t_file = fopen(pszPIDNAME, "r")) == 0) return;
	else {
		/* check */
		fgets(szPID, sizeof(szPID), t_file); 
		for( i=0; i<sizeof(szPID); i++ ) {
			if( szPID[i] == '\n' || szPID[i] == '\r' ) { szPID[i]=0; break; }
		}
		
		sprintf(TmpBuf, "+ Checking PID : %s", szPID); STD_PRNT(TmpBuf);
		if( GET_PROC(szPID) > 0 ) {			/* process exist */
			STD_PRNT("+ Engine process is exist.");
			STD_PRNT("+ If you want to stop the engine : 'srvctl stop'  ");
			STD_PRNT("+ If you have troubles starting the engine : REMOVE *Pid file and restart again.");
			ERR_EXIT("\nThe Engine is Already running");
		} else {
			STD_PRNT("+ Engine process is not exist.");
			sprintf(TmpBuf, "+ Removing %s file", pszPIDNAME); STD_PRNT(TmpBuf);
			if( remove(pszPIDNAME) == -1 ) {
				sprintf(TmpBuf, "remove: %s", strerror(errno)); STD_PRNT(TmpBuf);
			}
		}
		fclose(t_file);
	}
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : ���μ��� ���� ���
 TODO(�Ｚ����) 
 	���� : PID�� ���μ��� KILL�� �ϸ� �ȵ�(ROOT �ϰ�� �ٸ� ���μ��� KILL)
 	���� : �ߺ� ����ɰ�� PID ������ ������
 	
 	��� : ���μ��� ��Ī���� ���μ����� GREP �Ͽ� ��Ͽ� �ִ� ��� ���μ����� KILL �Ѵ�.
---------------------------------------------------------------------------------------------------*/
int GET_PROC(char *PID) 
{
	int nProc=0;
	FILE *fp;
	char TmpBuf[256], OS[64], MsgBuf[512];
	
	if( PID == 0 || *PID == 0 ) return nProc;
	if( GET_OS(OS) ) {
		if( strstr(OS, "Linux") != 0 ) {
			sprintf(TmpBuf, "ps aux | grep %s | grep -v grep | wc -l", PID);
		} else {
			sprintf(TmpBuf, "ps -ef | grep %s | grep -v grep | wc -l", PID);
		}
	} else return nProc;	
	sprintf(MsgBuf, "+ Checking Process : %s", TmpBuf); STD_PRNT(MsgBuf);
	if( (fp=popen(TmpBuf, "r") ) != 0 ) {
		fgets(TmpBuf, 9, fp);
		nProc=atoi(TmpBuf);
		fclose(fp);
	}
	
	sprintf(MsgBuf, "+ %d Process is running.", nProc); STD_PRNT(MsgBuf);
	return nProc;
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : OS���� ���
---------------------------------------------------------------------------------------------------*/
int GET_OS(char *OS)
{	
	FILE *fp;
	
	if( OS == 0 ) return 0;
	if( (fp=popen("uname", "r")) == 0 ) return 0;
	if( fp != 0 ) {
		fgets(OS, 10, fp);
		fclose(fp);
		return strlen(OS);
	}
	return 0;
}
/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : conf_file �ε�(�������� : pConfig)
---------------------------------------------------------------------------------------------------*/
void LOAD_CONFIG(char *path, const char *conf_file)
{
	char TmpBuf[16]={0};
	char Path[256]={0};

	/* nrasrv.conf ���� �б� */
	if( (pConfig=(INISTR *)calloc(1, sizeof(INISTR))) == 0 ) { 
		ERR_EXIT("(pConfig=(INISTR *)calloc(1,sizeof(INISTR))) == 0"); if( bError ) return;
	}	
	/* ȯ�漳�� �б� */
	getFullPath(path);

		
	if( conf_file != 0 ) sprintf(Path, "%s%s", g_szAbsPath, conf_file);
	
	
	if( LoadEnvironmentValue(Path, pConfig, 0) == 0 ) {
		STD_PRNT(Path);
		ERR_EXIT("\nCant Open Config File"); if( bError ) return;
	}
	/* �ý��� �α� */
	GetEnvIniString( pConfig, "LOGGING", "encoding", slog.enc, sizeof(slog.enc) ); UCASE(slog.enc);
	GetEnvIniString( pConfig, "LOGGING", "logdir", slog.path, sizeof(slog.path) );
	if( *slog.path == 0 ) strcpy(slog.path, "./");
	else { if( RSTR(slog.path, DIR_STRING) != 0 ) strcat(slog.path, DIR_STRING); }
	GetEnvIniString( pConfig, "LOGGING", "sys_log", TmpBuf, sizeof(TmpBuf) );
	GetEnvIniString( pConfig, "LOGGING", "logname", slog.file, sizeof(slog.file) ); RMSPC(slog.file);
	
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.bSysLog=1;
		STD_PRNT("Engine System Logging Enabled");
	} else {
		slog.bSysLog=0;
		STD_PRNT("Engine System Logging Disabled");
	}
	
	GetEnvIniString( pConfig, "LOGGING", "str_log", TmpBuf, sizeof(TmpBuf) );
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.bStrLog=1;
		STD_PRNT("Engine String Logging Enabled");
	} else {
		slog.bStrLog=0;
		STD_PRNT("Engine String Logging Disabled");
	}	
	
	GetEnvIniString( pConfig, "LOGGING", "ndisplay_log", TmpBuf, sizeof(TmpBuf) );
	if( *TmpBuf == '1' || *TmpBuf == 'Y' ) {
		slog.ndisplayLog=1;
		STD_PRNT("Engine No display Enabled");
	} else {
		slog.ndisplayLog=0;
		STD_PRNT("Engine No display Disabled");
	}	
	
	STD_PRNT("Loaded Configuration File");
	
	/* ���� ������ ���Ͽ��� �б� ���� ���� */
	signal(SIGPIPE, sig_handler);
	
}


/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� :   Ÿ�� ������
 #�Լ� RETURN : &gTime
---------------------------------------------------------------------------------------------------*/
char *GET_TIME(int flag)
{
	struct timeval tv;				/* for msec */	
	struct tm *local;
	
	*gTime='\0';
	gettimeofday(&tv, 0); local=(struct tm*)localtime((time_t*)&tv.tv_sec);
	/* 2011-05-25 17:08:30 */
	if(flag == 0) {
		sprintf(gTime, "%d-%02d-%02d %02d:%02d:%02d", local->tm_year + 1900, local->tm_mon +1, local->tm_mday, local->tm_hour, local->tm_min, local->tm_sec);
		return gTime;
	}
	/* 20110525 */
	else if(flag == 1) {
		sprintf(gTime, "%d%02d%02d", local->tm_year + 1900, local->tm_mon +1, local->tm_mday);
		return gTime;
	}
	/* 201105 */
	else if(flag == 2) {
		sprintf(gTime, "%d%02d", local->tm_year + 1900, local->tm_mon +1);
		return gTime;
	}
	/* 17:10:31:2854 (��:��:��:msec) */
	else if(flag == 3)
	{
		sprintf(gTime, "%.2d:%.2d:%.2d:%.4d", local->tm_hour, local->tm_min, local->tm_sec, (int)(tv.tv_usec/100));
		return gTime;
	} 
	/* 2011052517083020 */
	else if(flag == 4) {
		sprintf(gTime, "%d%02d%02d%02d%02d%02d%2.2d", local->tm_year + 1900, local->tm_mon +1, local->tm_mday, local->tm_hour, local->tm_min, local->tm_sec,(int)(tv.tv_usec/100));
		return gTime;
	}
	/* 08:20 */
	else if(flag == 5) {
		 sprintf(gTime, "%02d:%02d",local->tm_hour,local->tm_min);
		return gTime;
	}	
	/* 171031 (�ú���) */
	else if(flag == 6)
	{
		sprintf(gTime, "%02d%02d%02d", local->tm_hour, local->tm_min, local->tm_sec);
		return gTime;
	} 
	/* 2011�� 05�� 25�� 17�� 09�� 10�� */
	else {
		sprintf(gTime, "%d�� %02d�� %02d�� %02d�� %02d�� %02d��\n", local->tm_year + 1900, local->tm_mon +1, local->tm_mday, local->tm_hour, local->tm_min, local->tm_sec);
		return gTime;
	}
}

void setNonBlockSock(int fd)
{
	int flag;
	if( (flag = fcntl(fd, F_GETFL, 0)) == -1 ) {
		STD_PRNT("Failed to get fcntl(F_GETFL)"); flag=0;
		STD_PRNT("Switching to Blocking Mode");
	}
	if( fcntl(fd, F_SETFL, flag | O_NONBLOCK) != -1 ) {
		STD_PRNT("Switching to None Blocking Mode");
	}
}

/*--------------------------------------------------------------------------------------------------
 #�Լ� ��� : �������ϸ��� ������ ������ ����, argv[0] == null ����� ����
---------------------------------------------------------------------------------------------------*/
void getFullPath(char *argv)
{
	SEPFLD ss;
	
	memset(&g_szAbsPath, 0, sizeof(g_szAbsPath));
	realpath(argv, g_szAbsPath);
	SEPCHRB(&ss, g_szAbsPath, DIR_STRING, SEP_FLD_MAX);	
	ss.pt[ ss.cnt - 1 ][0] = 0;
	STD_PRNT(g_szAbsPath);
}



/*--------------------------------------------------------------------------------------------------
 # refdata�� �����߿� srvctl ���ɾ ���ؼ� �ε��Ѵ�.
---------------------------------------------------------------------------------------------------*/
void refdata_reload(char *szCmd)
{
#if 0
    unsigned int i;
    char TmpBuf2[1024], TmpBuf[1024]={0,}, envpath[256];
	SEPFLD ss;

    memcpy(TmpBuf, szCmd, 64);  /* ������ 64����Ʈ����? */
	SEPCHRB(&ss, szCmd, ":", SEP_FLD_MAX);
    if (ss.cnt < 3){
		printf("\nNot enough refdata_reload params!");
        return;
    }

    for (i = 0; i < sizeof(g_stSrvCtl) / sizeof(g_stSrvCtl[0]); ++i)
    {
        if (strcmp(ss.pt[2], g_stSrvCtl[i].szShortCmd)){
            if (strcmp(szCmd, g_stSrvCtl[i].szCmd)){
                continue;
            }
        }
        printf("\nReloading refdata...\n");
	    strcpy(TmpBuf, g_szAbsPath);
	    ENV_GetIniString(pConfig, "GENERAL", "refdata", TmpBuf+strlen(TmpBuf));
	    ENV_GetIniString(pConfig, "GENERAL", "envfile", envpath);

        RELOAD_Begin(TmpBuf, envpath, 1, 1);
	    if( *TmpBuf != 0 && *envpath != 0 ) {
		    sprintf(TmpBuf2, "RefData : %s", TmpBuf); STD_PRNT(TmpBuf2);
		    sprintf(TmpBuf2, "EnvPath : %s\n", envpath); STD_PRNT(TmpBuf2);		
		    if( g_stSrvCtl[i].pfnLoad(TmpBuf, envpath, 1, 1) == -1 ) {
			    STD_PRNT("Failed to Loading Reference Data!\n\n");
		    }
	    }
        RELOAD_End(TmpBuf, envpath, 1, 1);

		printf("\nDone!!!\n");
        break;
    }
#endif
}


/*------------------------------------------------------------------------------------------------*/
/* connect to server */
/*------------------------------------------------------------------------------------------------*/
int connect_svr(const char *pszIP, unsigned short nPort)
{
	struct sockaddr_in server_addr;
	struct linger linger;
	struct timeval tv;
	int sock;
	
	if( pszIP == 0 || *pszIP == 0 || nPort <= 0 ) return -1;
	/*--------------------------------------------------------------------------------------------*/
	if( (sock = socket( AF_INET, SOCK_STREAM, 0)) == -1 ) {
		perror(strerror(errno));
		return -1;
	} 
	/*--------------------------------------------------------------------------------------------*/
	linger.l_onoff = 1;
	linger.l_linger = 3;
	tv.tv_sec = 10;
	tv.tv_usec = 0;
	/*--------------------------------------------------------------------------------------------*/
	setsockopt(sock, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
	setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
	/*--------------------------------------------------------------------------------------------*/
	memset(&server_addr, 0, sizeof( server_addr));
	server_addr.sin_family     = AF_INET;
	server_addr.sin_port       = htons(nPort);
	server_addr.sin_addr.s_addr= inet_addr(pszIP);
	/*--------------------------------------------------------------------------------------------*/
	if( connect( sock, (struct sockaddr*)&server_addr, sizeof( server_addr) ) == -1 ) {
		sleep(5);
		if( connect( sock, (struct sockaddr*)&server_addr, sizeof( server_addr) ) == -1 ) {
			perror(strerror(errno));
			return -1;
		}
	}
	/*--------------------------------------------------------------------------------------------*/
	return sock;
}

/*------------------------------------------------------------------------------------------------*/
/* disconnect server */
/*------------------------------------------------------------------------------------------------*/
void disconnect_svr(int sock)
{
	shutdown(sock, SHUT_RD); shutdown(sock, SHUT_WR);
	if( close(sock) != 0 ) close(sock);
}

int socket_recv_all(int socket, char* buffer, int size)
{
	int total_received;
	int received,rtotcnt;
	assert(buffer);	assert(size > 0);
	total_received = 0;
	rtotcnt=size;
	while(size)	{
		received = read(socket, buffer, size);
		printf("[%s]\n\n", buffer);				
		/* ���ϰ��� = 0 �̸� close�Ǿ����� �ǹ�
		   ���ϰ��� < 0 �̸� ���� �߻��� �ǹ�
		*/
		if(received <= 0) break;
		total_received += received;
		size -= received;
		buffer += received;		
		if(rtotcnt <= total_received)
		 break;		 
		 printf("rtotcnt[%d]total_received[%d]\n\n", rtotcnt,total_received);
	}
	return total_received;
}
