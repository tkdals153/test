#define PROGRAM_NAME "srchsrv"
#define VERSION_INFO "4.3.0"
#define REVISION_INFO "rev.735"

