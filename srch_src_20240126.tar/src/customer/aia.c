#ifndef WIN32 
#include "nrasrv.h"
#endif
#include "MakeText.h"

#ifdef _AIA_
void LOGGER_OUTREC(const char *str, int nBufSize);

/*-----------------------------------------------------------------------------------------------*/
/* AIA���� : (1) ���� ��� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_CustForm_AIA_GetHead(void *p, char *pszSrc, char *MODE)
{
	nra_outRec *nra_out=(nra_outRec*)p;
	
	memset(&nra_out->hdr, 0x20, sizeof(nra_out->hdr));
	memcpy(&nra_out->hdr, pszSrc, sizeof(nra_out->hdr));
}

/*-----------------------------------------------------------------------------------------------*/
/* AIA���� : (2) ���� ������ ���� */
/* ������ ������ ������ �� ����(�� ���� �ڷ� �Ǽ�) */
/*-----------------------------------------------------------------------------------------------*/
int MakeText_CustForm_AIA_MakeDataBlock(void *pROUT, void *pNra_out, char *pszDst, char *GB)
{
	OP_NODE *ROUT=(OP_NODE*)pROUT;
	nra_outRec *nra_out=(nra_outRec*)pNra_out;
	OJBN_NODE *pJBN;
	ONRA_NODE *pNRA;
	int i=0, T, D, P, nNext, nDat=0;
	int nSize;
	char TmpBuf[6];
	
	if( nra_out == 0 || GB == 0 ) return i; memset(nra_out->dat, 0x00, sizeof(nra_out->dat));
	nSize=sizeof(nra_out->dat)/sizeof(nra_out->dat[0]);
	/*-------------------------------------------------------------------------------------------*/
	/* �ڷ� ��û ��ġ */
	strnzcpy(TmpBuf, nra_out->hdr.DatReqLoc, sizeof(nra_out->hdr.DatReqLoc));
	nNext=atoi(TmpBuf); if( nNext <= 0 ) nNext=1;
	/*-------------------------------------------------------------------------------------------*/
	/* ����-���� ��� */
	if( ROUT != 0 && ROUT->pJBNNode != 0 ) {		
		for( pJBN=ROUT->pJBNNode,T=0,D=0,P=0; pJBN!=0; pJBN=pJBN->pNext ) {
			if( (nNext-1) <= T && nDat < nSize ) {	/* T=���� ��ġ, nNext=������ġ  &&  �����ͺ����� �ִ������ ������ �߰� */
				P=0;
				MakeText_CustForm_AIA_SetDataBlock(pJBN->JMAC, &nra_out->dat[nDat++], GB, 'D', ++D, P);
			}			
			
			for( pNRA=pJBN->pChild, P=0, T++; pNRA!=0; pNRA=pNRA->pNext, T++ ) {
				if( (nNext-1) <= T && nDat < nSize ) {
					MakeText_CustForm_AIA_SetDataBlock(pNRA->NMAC, &nra_out->dat[nDat++], GB, 'P', D, P++);
					
				}
			}
		}
	}
	/* ����-���� ��� */
	else if( ROUT != 0 && ROUT->pNRANode != 0 ) {
		for( pNRA=ROUT->pNRANode,T=0,D=0,P=0; pNRA!=0; pNRA=pNRA->pNext ) {			
			if( (nNext-1) <= T && nDat < nSize ) {	/* T=���� ��ġ, nNext=������ġ  &&  �����ͺ����� �ִ������ ������ �߰� */
				P=0;
				MakeText_CustForm_AIA_SetDataBlock(pNRA->NMAC, &nra_out->dat[nDat++], GB, 'D', ++D, P);
			}			
			
			for( pJBN=pNRA->pChild, P=0, T++; pJBN!=0; pJBN=pJBN->pNext, T++ ) {			
				if( (nNext-1) <= T && nDat < nSize ) {
					MakeText_CustForm_AIA_SetDataBlock(pJBN->JMAC, &nra_out->dat[nDat++], GB, 'P', D, P++);
					
				}
			}
		}
	} else { /* ���� ����ó�� */ }
	/*-------------------------------------------------------------------------------------------*/	
	MakeText_CustForm_AIA_SetHeader(ROUT, nra_out, T, nDat, nNext);
	MakeText_CustForm_AIA_MakeDataText(nra_out, pszDst, nDat);/* �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
	/*-------------------------------------------------------------------------------------------*/
	return nDat;
}

void MakeText_CustForm_AIA_SetHeader(OP_NODE *ROUT, nra_outRec *nra_out, int nTotCnt, int nBlkCnt, int nNext)
{
	char NRA_TBL[] = { '9', 'A', 'B', 'G', 'H', 0 };
	char JBN_TBL[] = { '4', '5', '6', '7', '8', 'C', 'D', 'E', 'F', 'I', 0 };
	char TmpBuf[128];
	int i;

	if( ROUT == 0 || nra_out == 0 ) return; *TmpBuf=0;
	/* �����ͺ���ü���� */
	sprintf(TmpBuf, "%06d", nBlkCnt*sizeof(nra_out->dat[0])); strncpy(nra_out->hdr.DatSize, TmpBuf, sizeof(nra_out->hdr.DatSize));

	/* �� ���� �ڷ�Ǽ� */
	sprintf(TmpBuf, "%03d", nTotCnt); strncpy(nra_out->hdr.TotDatCnt, TmpBuf, sizeof(nra_out->hdr.TotDatCnt));

	/* ���ӱ��� */
	if( nTotCnt > ((nNext-1)+nBlkCnt) ) *nra_out->hdr.NextYN='Y';
	else *nra_out->hdr.NextYN='N'; 

	/* block�Ǽ� */
	sprintf(TmpBuf, "%02d", nBlkCnt); strncpy(nra_out->hdr.BlckCnt, TmpBuf, sizeof(nra_out->hdr.BlckCnt));

	/* �����ڵ�(����ڵ�) */
	CheckAndCopyFixedLenFLD_WN(ROUT->GEN.RC3, nra_out->hdr.ErrCode, sizeof(nra_out->hdr.ErrCode));
	/* ����޼���(����޼���) */
	CheckAndCopyFixedLenFLD_WN(ROUT->GEN.RM3, nra_out->hdr.ErrMsg, sizeof(nra_out->hdr.ErrMsg));

	/* ���� ���� ����  �ּұ��� 1.���� 2.���θ� 3.���кҰ� */
	for( i=0; JBN_TBL[i]!=0; i++ ) {				/* ���� ���� �ڵ� */
		if( *ROUT->GEN.RC3 == JBN_TBL[i] ) {
			*nra_out->hdr.AddrSectCd='1';
			return;
		}
	}
	for( i=0; NRA_TBL[i]!=0; i++ ) {				/* ���� ���� �ڵ� */
		if( *ROUT->GEN.RC3 == NRA_TBL[i] ) {
			*nra_out->hdr.AddrSectCd='2';
			return;
		}
	}
	*nra_out->hdr.AddrSectCd='3';					/* ���кҰ� */
}

void MakeText_CustForm_AIA_SetDataBlock(char *MAC, NRADAT *dat, char *GB, char cType, int nParent, int nChild)
{
	SEPFLD ss;
	char *p, TmpBuf[256];

	if( MAC == 0 || *MAC == 0 || dat == 0 || GB == 0 ) return; p=strdup(MAC);
	/*-------------------------------------------------------------------------------------------*/
	/* ������ ���� �κ� */
	*dat->SectCd=cType;
	sprintf(TmpBuf, "%03d", nParent); strncpy(dat->D_DataNo, TmpBuf, sizeof(dat->D_DataNo));
	sprintf(TmpBuf, "%03d", nChild); strncpy(dat->P_DataNo, TmpBuf, sizeof(dat->P_DataNo));
	/*-------------------------------------------------------------------------------------------*/
	/* ���� ������ �κ� */
	SEPCHRB(&ss, p, GB, SEP_FLD_MAX); SEPARRY(&ss);								/* ��ũ�� ��� ���� �и� */
	sprintf(TmpBuf, "%06s", ss.pt[0]); strncpy(dat->ZIP6, TmpBuf, sizeof(dat->ZIP6));
	/*--------------------------------------------------------------------------------------------*/
	CheckAndCopyFixedLenFLD_WN(ss.pt[1],  TmpBuf,  sizeof(dat->ADDR1H       )); strncpy(dat->ADDR1H    , TmpBuf, sizeof(dat->ADDR1H    ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[2],  TmpBuf,  sizeof(dat->DTL10        )); strncpy(dat->DTL10     , TmpBuf, sizeof(dat->DTL10     ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[3],  TmpBuf,  sizeof(dat->DTL11        )); strncpy(dat->DTL11     , TmpBuf, sizeof(dat->DTL11     ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[4],  TmpBuf,  sizeof(dat->DTL12        )); strncpy(dat->DTL12     , TmpBuf, sizeof(dat->DTL12     ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[5],  TmpBuf,  sizeof(dat->STDADDRE     )); strncpy(dat->STDADDRE  , TmpBuf, sizeof(dat->STDADDRE  ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[6],  TmpBuf,  sizeof(dat->GISX         )); strncpy(dat->GISX      , TmpBuf, sizeof(dat->GISX      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[7],  TmpBuf,  sizeof(dat->GISY         )); strncpy(dat->GISY      , TmpBuf, sizeof(dat->GISY      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[8],  TmpBuf,  sizeof(dat->ZIPR         )); strncpy(dat->ZIPR      , TmpBuf, sizeof(dat->ZIPR      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[9],  TmpBuf,  sizeof(dat->NADR1        )); strncpy(dat->NADR1     , TmpBuf, sizeof(dat->NADR1     ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[10], TmpBuf,  sizeof(dat->NBKU         )); strncpy(dat->NBKU      , TmpBuf, sizeof(dat->NBKU      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[11], TmpBuf,  sizeof(dat->NBKM         )); strncpy(dat->NBKM      , TmpBuf, sizeof(dat->NBKM      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[12], TmpBuf,  sizeof(dat->NBKS         )); strncpy(dat->NBKS      , TmpBuf, sizeof(dat->NBKS      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[13], TmpBuf,  sizeof(dat->NADR3S       )); strncpy(dat->NADR3S    , TmpBuf, sizeof(dat->NADR3S    ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[14], TmpBuf,  sizeof(dat->NADREH       )); strncpy(dat->NADREH    , TmpBuf, sizeof(dat->NADREH    ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[15], TmpBuf,  sizeof(dat->NNMX         )); strncpy(dat->NNMX      , TmpBuf, sizeof(dat->NNMX      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[16], TmpBuf,  sizeof(dat->NNMY         )); strncpy(dat->NNMY      , TmpBuf, sizeof(dat->NNMY      ));
	CheckAndCopyFixedLenFLD_WN(ss.pt[17], TmpBuf,  sizeof(dat->NNMZ         )); strncpy(dat->NNMZ      , TmpBuf, sizeof(dat->NNMZ      ));
	/*--------------------------------------------------------------------------------------------*/
	free(p);
}


/*-----------------------------------------------------------------------------------------------*/
/* AIA���� : (3) �ϼ��� ����ü�� �ؽ�Ʈ ���� ���� */
/*-----------------------------------------------------------------------------------------------*/
void MakeText_CustForm_AIA_MakeDataText(nra_outRec *nra_out, char *pszDst, int nBlkCnt)
{
	int i;
	FILE *fp=0;

	if( nra_out == 0 || pszDst == 0 ) return; *pszDst=0;
	/*-------------------------------------------------------------------------------------------*/
	/* ����� ���� */
	#ifdef _TXT_FILEOUT
	if( (fp=fopen("txt_output.txt", "wb")) != 0 ) {
		/* HEADER */
		fwrite(nra_out->hdr.DatSize, 1, sizeof(nra_out->hdr), fp); fwrite("\n", 1, 1, fp); fflush(fp);
		/* DATA BLOCK */
		for( i=0; i<nBlkCnt; i++ ) 	{
			fwrite(nra_out->dat[i].SectCd, 1, sizeof(nra_out->dat[i]), fp);
			fwrite("\n", 1, 1, fp); fflush(fp);
		}fwrite(pszDst, 1, strlen(pszDst), fp); fwrite("\n", 1, 1, fp);
		if( fp != 0 ) fclose(fp);
	}
	#endif
	/*-------------------------------------------------------------------------------------------*/
	/* ��� ���� */
	memcpy(pszDst, &nra_out->hdr, sizeof(nra_out->hdr) );							/* HEAD ���� */
	memcpy(pszDst + sizeof(nra_out->hdr), nra_out->dat, sizeof(NRADAT) * nBlkCnt);	/* DATA ���� */
	/*-------------------------------------------------------------------------------------------*/
	/* �α� ���� */
	LOGGER_OUTREC(pszDst, sizeof(nra_out->hdr) + (sizeof(NRADAT) * nBlkCnt) );
	/*-------------------------------------------------------------------------------------------*/
}

void LOGGER_OUTREC(const char *str, int nBufSize)
{
#ifndef WIN32
	int nBlk, i;
	char TmpBuf[256];
	NRAHDR *pHdr;
    NRADAT *pDat;
    
	if( str == 0 || slog.bNraLog == 0 ) return; pHdr=(NRAHDR *)str; pDat=(NRADAT *)(str + sizeof(NRAHDR));
	if( pHdr == 0 || pDat == 0 ) return;
	/*-------------------------------------------------------------------------------------------*/
	LOGGER("\n=================[HDR  BLOCK]=================", 1);
	sprintf(TmpBuf, "[DatSize     ] [%.6s]",    pHdr->DatSize     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[TotDatCnt   ] [%.3s]",    pHdr->TotDatCnt   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[DatReqLoc   ] [%.3s]",    pHdr->DatReqLoc   ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[NextYN      ] [%.1s]",    pHdr->NextYN      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[BlckCnt     ] [%.2s]",    pHdr->BlckCnt     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[ErrCode     ] [%.6s]",    pHdr->ErrCode     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[ErrMsg      ] [%.80s]",   pHdr->ErrMsg      ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[ZipCd       ] [%.6s]",    pHdr->ZipCd       ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[InAddr1     ] [%.80s]",   pHdr->InAddr1     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[InAddr2     ] [%.130s]",  pHdr->InAddr2     ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[AddrSectCd  ] [%.1s]",    pHdr->AddrSectCd  ); LOGGER(TmpBuf, 1);
	sprintf(TmpBuf, "[filler      ] [%.18s]",   pHdr->filler      ); LOGGER(TmpBuf, 1);
	
	strncpy(TmpBuf, pHdr->BlckCnt, sizeof(pHdr->BlckCnt)); TmpBuf[sizeof(pHdr->BlckCnt)]=0;
	nBlk=atoi(TmpBuf);
	
	
	
	for( i=0; i<nBlk; ++i, pDat++) {
		sprintf(TmpBuf, "\n=================[DATA BLOCK(%d/%d)]=================", i+1, nBlk); LOGGER(TmpBuf, 1);
		
		sprintf(TmpBuf, "[SectCd     ] [%.1s]",    pDat->SectCd    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[D_DataNo   ] [%.3s]",    pDat->D_DataNo  ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[P_DataNo   ] [%.3s]",    pDat->P_DataNo  ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIP6       ] [%.6s]",    pDat->ZIP6      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ADDR1H     ] [%.80s]",   pDat->ADDR1H    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DTL10      ] [%.1s]",    pDat->DTL10     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DTL11      ] [%.4s]",    pDat->DTL11     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[DTL12      ] [%.4s]",    pDat->DTL12     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[STDADDRE   ] [%.130s]",  pDat->STDADDRE  ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[GISX       ] [%.20s]",   pDat->GISX      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[GISY       ] [%.20s]",   pDat->GISY      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[ZIPR       ] [%.6s]",    pDat->ZIPR      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR1      ] [%.80s]",   pDat->NADR1     ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NBKU       ] [%.1s]",    pDat->NBKU      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NBKM       ] [%.5s]",    pDat->NBKM      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NBKS       ] [%.5s]",    pDat->NBKS      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADR3S     ] [%.100s]",  pDat->NADR3S    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NADREH     ] [%.80s]",   pDat->NADREH    ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMX       ] [%.20s]",   pDat->NNMX      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMY       ] [%.20s]",   pDat->NNMY      ); LOGGER(TmpBuf, 1);
		sprintf(TmpBuf, "[NNMZ       ] [%.25s]",   pDat->NNMZ      ); LOGGER(TmpBuf, 1);
		
	}
	LOGGER("=================[End of DATA BLOCK]=================\n\n", 1);
	/*-------------------------------------------------------------------------------------------*/	
#endif
}




#endif /* _AIA_ */

