#ifndef WORK_QUEUE_H
#define WORK_QUEUE_H
#include <pthread.h>

/*
 * srchsrv work queue (2022.07.11)
 */
struct WorkQueue {
    int *items;
    int front;
    int rear;
    int size;
    int maxsize;
    pthread_mutex_t mutex;
};

struct WorkQueue* WQ_Create(int nSize);

/* Check if the queue is full */
int WQ_IsFull(struct WorkQueue* handle);

/* Check if the queue is empty */
int WQ_IsEmpty(struct WorkQueue* handle);

/* Adding an element */
void WQ_EnQueue(struct WorkQueue* handle, int element);

/* Removing an element */
int WQ_DeQueue(struct WorkQueue* handle);

int WQ_GetCount(struct WorkQueue* handle);
int WQ_GetSize(struct WorkQueue* handle);

#endif

