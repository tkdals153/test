#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <pthread.h>

#include <sys/stat.h>
#include <sys/wait.h> 
#include <errno.h>
#include "srchsrv.h"

int File_LineInput(FILE *hFile,char *lpDest,int *nReadByte,int nMax);
void t_function(char *sndOut,int port);
void threadFn_function(void *port);
void threadFn_functionM(void *port);
void f_daemon2(void);
int write_pid2();
int s,checkD[10];
void sig_err();
char *time_stamp();
char *time_stampA(int a);
char   gTime2[30];
int main(int argc, char *argv[])
{
	FILE *file_sch,*file_in;
	char ct[10],checktime[16],checktime2[16],checktime3[16],stime[10],sjob[1024],rmsjob[1024];
	int i,j,k,rByte,nReadB,bfork=1;
	char l_buf[1024],port[8],filelogName[64],LOGDIR[32];
	pthread_t pid;
	
	getFullPath(argv[0]);
	LOAD_CONFIG(argv[0], "srchsrv.conf");
	/*LOAD_CONFIG("./sDailyClint","srchsrv.conf");*/
	GetEnvIniString(pConfig, "NETWORK", "port", port, sizeof(port));
	GetEnvIniString(pConfig, "LOGGING", "daily_ok", LOGDIR, sizeof(LOGDIR));
	
	/*strcpy(sjob,"DAILY_MEM_ADD.txt");*/
	printf("usage : sDailyClint -s :: ����\n");	
	printf("usage : sDailyClint\n");

	/* 2020.11.05: check required files  */
	sprintf(sjob, "%s%s", g_szAbsPath, "schedule_job.txt");
	if((file_sch = fopen(sjob, "r")) == NULL) {
		perror("File Not Found!!! (schedule_job.txt) exit program..");
		exit(0);	
	} else {
		fclose(file_sch); file_sch = NULL;
	}

	sprintf(sjob, "%s%s", g_szAbsPath, "DAILY_MEM_ADD.txt");
	if((file_in = fopen(sjob, "r")) == NULL) {
		perror("File Not Found!!! (DAILY_MEM_ADD.txt) exit program..");
		exit(0);
	} else {
		fclose(file_in); file_in = NULL;
	}
	
	/* Standalone Mode */
	if( argc > 1 && (strcmp(argv[1], "-a")==0 || strcmp(argv[1], "standalone")==0) ) {
		bfork=0;
	} 
	
	if(argc > 1 && strcmp(argv[1], "-s")==0 ) {
		if((file_in = fopen(sjob, "r")) == NULL) {
			perror("File Not Found!!!");
		}		
		else {
			while(1) {
				rByte=File_LineInput(file_in,l_buf,&nReadB,1024); 
				if ( nReadB==0 ) break;
	           	t_function(l_buf,atoi(port));
	        }	           
	        fclose(file_in);       
		}
		exit(0);
	}
	
	if(argc > 1 && strcmp(argv[1], "-sm")==0){				
		/*pthread_create(&pid, 0, threadFn_functionM, (void *)port);*/
		threadFn_functionM((void *)port);		
		exit(0);
	}
	if( bfork == 1 ) {	
		f_daemon2(); write_pid2();
	}
	while(1)
	{
		strcpy(checktime,time_stamp());		
		strcpy(checktime2,time_stampA(3));	
		strcpy(checktime3,time_stampA(5));
	
		if(argc > 1 && strcmp(argv[1], "-l")==0){
			sprintf(filelogName,"%s/DAILY_OK.%s",LOGDIR,GET_TIME(1));
			if(access(filelogName, F_OK) ==0 && checkD[0]==0)
			{
				if((file_in = fopen(sjob, "r")) == NULL) {
					perror("File Not Found!!!");
				}	
				else {
					while(1) {
						rByte=File_LineInput(file_in,l_buf,&nReadB,1024); 
						if ( nReadB==0 ) break;
			           	t_function(l_buf,atoi(port));
			        }	           
			        fclose(file_in);       
				}
				checkD[0]=1;				
			}
			if(	strcmp(checktime,"00:01")==0)
					memset(checkD,0,10);
			
		}else if(argc > 1 && strcmp(argv[1], "-pm")==0) {
			sprintf(sjob, "%s%s", g_szAbsPath, "schedule_job.txt");
			if((file_sch = fopen(sjob, "r")) == NULL) {
				perror("File Not Found!!");
			}
			else {
				memset(stime,0,sizeof(stime));
				memset(sjob,0,sizeof(sjob));
				memset(l_buf,0,sizeof(l_buf));
				k=0;	
				while(1) {
					rByte=File_LineInput(file_sch,l_buf,&nReadB,1024); 
					if ( nReadB==0 ) break;
					
					for(i=0;l_buf[i]!=0 && l_buf[i]!=' ';i++)
						stime[i]=l_buf[i];
						
					for(j=0,i++;l_buf[i]!=0 && l_buf[i]!=' ' ;i++,j++)
						sjob[j]=l_buf[i];
					if(strcmp(stime,checktime)==0 && checkD[k]==0) {						
						/*pthread_create(&pid, 0, threadFn_functionM, (void *)port);*/
						threadFn_functionM((void *)port);
						/*printf("Creating thread : %d\n", pid);*/
				        checkD[k]=1;
					}
				
					memset(stime,0,10);
					memset(sjob,0,50);
					memset(l_buf,0,sizeof(l_buf));
					k++;
				}
				fclose(file_sch);	
				if(	strcmp(checktime,"00:01")==0)
					memset(checkD,0,10);
			}
		}
		else if(argc > 1 && strcmp(argv[1], "-pm")==0){
			sprintf(sjob, "%s%s", g_szAbsPath, "schedule_job.txt");
			if((file_sch = fopen(sjob, "r")) == NULL) {
				perror("File Not Found!!");	
			}
			else {
				memset(stime,0,sizeof(stime));
				memset(sjob,0,sizeof(sjob));
				memset(l_buf,0,sizeof(l_buf));
				k=0;	
				while(1) {
					rByte=File_LineInput(file_sch,l_buf,&nReadB,1024); 
					if ( nReadB==0 ) break;
					
					for(i=0;l_buf[i]!=0 && l_buf[i]!=' ';i++)
						stime[i]=l_buf[i];
						
					for(j=0,i++;l_buf[i]!=0 && l_buf[i]!=' ' ;i++,j++)
						sjob[j]=l_buf[i];
					if(strcmp(stime,checktime)==0 && checkD[k]==0) {						
						for(i=0;i<atoi(argv[2]);i++)
						{
							pthread_create(&pid, 0, threadFn_function, (void *)port);
							printf("Creating thread : %d\n", pid);	
							sleep(1);			            	
				        } 
				        checkD[k]=1;
					}
					if(strcmp(stime,checktime2)==0 && checkD[k]==0) {
						for(i=0;i<atoi(argv[2]);i++)
						{
							pthread_create(&pid, 0, threadFn_functionM, (void *)port);
							printf("Creating thread : %d\n", pid);	
							sleep(1);			            	
				        } 
					}
					if(strcmp(stime,checktime3)==0 && checkD[k]==0) {
						for(i=0;i<atoi(argv[2]);i++) {
							pthread_create(&pid, 0, threadFn_functionM, (void *)port);
							printf("Creating thread : %d\n", pid);	
							sleep(1);			            	
				        }   
					}
					memset(stime,0,10);
					memset(sjob,0,50);
					memset(l_buf,0,sizeof(l_buf));
					k++;
				}
				fclose(file_sch);	
				if(	strcmp(checktime,"00:01")==0)
					memset(checkD,0,10);
			}
		}
		else {			
			sprintf(sjob, "%s%s", g_szAbsPath, "schedule_job.txt");
			if((file_sch = fopen(sjob, "r")) == NULL) {
				perror("File Not Found!!");
			}
			else {
				memset(stime,0,sizeof(stime));
				memset(sjob,0,sizeof(sjob));
				memset(l_buf,0,sizeof(l_buf));
				k=0;	
				while(1) {
					rByte=File_LineInput(file_sch,l_buf,&nReadB,1024); 
					if ( nReadB==0 ) break;
					
					for(i=0;l_buf[i]!=0 && l_buf[i]!=' ';i++)
						stime[i]=l_buf[i];
						
					for(j=0,i++;l_buf[i]!=0 && l_buf[i]!=' ' ;i++,j++)
						sjob[j]=l_buf[i];
					if(strcmp(stime,checktime)==0 && checkD[k]==0) {
						printf("%s\n",sjob);
						if((file_in = fopen(sjob, "r")) == NULL) {
							perror("File Not Found!!!");
						}
						else {
							while(1) {
								rByte=File_LineInput(file_in,l_buf,&nReadB,1024); 
								if ( nReadB==0 ) break;
				            	t_function(l_buf,atoi(port));
				            }
				            
				            fclose(file_in);
				            /*sprintf(rmsjob,"rm %s",sjob);
				            system(rmsjob);*/
				            checkD[k]=1;
						}
						
					}
					memset(stime,0,10);
					memset(sjob,0,50);
					memset(l_buf,0,sizeof(l_buf));
					k++;
				}
				fclose(file_sch);	
				if(	strcmp(checktime,"00:01")==0)
					memset(checkD,0,10);
			}
		}
		
		sleep(60);
	}
	exit(0);
	
}

void f_daemon2(void)
{
	pid_t   pid;

	if (( pid = fork()) < 0)
	{
		exit(0);
	}
    	/* �θ����μ����� �����Ѵ�. */
	else if(pid != 0){
		exit(0);
	}
    
	/*setsid();*/
	/*chdir("/");*/

    	/*���⿡ ���α׷� ��ü�� �ִ´�. */
	setsid();	
}
int write_pid2()
{
	FILE *stream;
	char *file_name;
	char *z_pid;
	const char fn[] = "sDailyClient.pid";
	
	z_pid = (char *)malloc(sizeof(pid_t));
	
	file_name = (char *)malloc(sizeof(fn));
	strncpy(file_name,fn,sizeof(fn));

	if((stream = fopen(file_name, "ab")) != NULL)
	{
		sprintf(z_pid, "%d\n", getpid());
		fputs(z_pid, stream);
	}
	else
	{
		perror("Faild to write Proces ID of DailyCient");
		return 0;
	}
	fflush(stream);
	fclose(stream);
	free(file_name);
	return 1;
}
char *time_stamp()
{               
    struct  tm *nPtime;
    time_t  nTime;
    memset(gTime2,0,30);
    time(&nTime);
    nPtime = localtime(&nTime);
   
    memset(gTime2, '\0', 30);
    sprintf(gTime2, "%02d:%02d",nPtime->tm_hour,nPtime->tm_min);
    return gTime2;

}
char *time_stampA(int a)
{               
    struct  tm *nPtime;
    time_t  nTime;
    memset(gTime2,0,30);
    time(&nTime);
    nPtime = localtime(&nTime);
   
    memset(gTime2, '\0', 30);
    if(nPtime->tm_min+a>=60){
	    sprintf(gTime2, "%02d:%02d",nPtime->tm_hour+1,(nPtime->tm_min+a)%60);
	}
	else
		sprintf(gTime2, "%02d:%02d",nPtime->tm_hour,nPtime->tm_min+a);
    return gTime2;

}
void t_function(char *sndOut,int port)
{
  int echo_fd,rByte,wByte;
  int i = 0;
  struct sockaddr_in serveraddr;
  int server_sockfd;
  int client_len;
  char rbuf[1024];

  if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
      perror("error :");
	  return;
      /*exit(0);*/
  }

  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  serveraddr.sin_port = htons(port);

  client_len = sizeof(serveraddr);

  if (connect(server_sockfd, (struct sockaddr *)&serveraddr, client_len) < 0)
  {
      perror("connect error:");
      /*exit(0);*/
  }
	sndOut[strlen(sndOut)]=0;
  if (write(server_sockfd, sndOut, strlen(sndOut)+1) <= 0)
  {
      perror("write error : ");
      /*exit(0);*/
  }
  memset(rbuf, 0x00, 1024);

  if (read(server_sockfd, rbuf, 1024) <= 0)
  {
      perror("read error : ");
      /*exit(0);*/
  }
	  
  close(server_sockfd);
}

void threadFn_function(void *port)
{
  int echo_fd,rByte,wByte;
  int i = 0;
  struct sockaddr_in serveraddr;
  int server_sockfd;
  int client_len;
  char rbuf[1024]={0};
  
  pthread_detach(pthread_self());

  if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
      perror("error :");
      exit(0);
  }

  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  serveraddr.sin_port = htons(atoi((char *)port));

  client_len = sizeof(serveraddr);

  if (connect(server_sockfd, (struct sockaddr *)&serveraddr, client_len) < 0)
  {
      perror("connect error:");
      /*exit(0);*/
  }
  strcpy(rbuf,"#CTL:DLY:ADD:");  
  if (write(server_sockfd, rbuf, strlen(rbuf)+1) <= 0)
  {
      perror("write error : ");
      /*exit(0);*/
  }
  memset(rbuf, 0x00, 1024);

  if (read(server_sockfd, rbuf, 1024) <= 0)
  {
      perror("read error : ");
      /*exit(0);*/
  }
	  
  close(server_sockfd);
  /*pthread_exit(0);*/
  return;
}
void threadFn_functionM(void *port)
{
  int echo_fd,rByte,wByte;
  int i = 0;
  struct sockaddr_in serveraddr;
  int server_sockfd;
  int client_len;
  char rbuf[1024]={0};
  pthread_detach(pthread_self());
  if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)  {
  	 
      perror("error :");      
      exit(0);
  }
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  serveraddr.sin_port = htons(atoi((char *)port));

  client_len = sizeof(serveraddr);
  if (connect(server_sockfd, (struct sockaddr *)&serveraddr, client_len) < 0)
  {
      perror("connect error:");
      /*exit(0);*/
  }
  strcpy(rbuf,"#CTL:DLY:MADD:");  
  if (write(server_sockfd, rbuf, strlen(rbuf)+1) <= 0)
  {
      perror("write error : ");
      /*exit(0);*/
  }
  memset(rbuf, 0x00, 1024);
  if (read(server_sockfd, rbuf, 1024) <= 0)
  {
      perror("read error : ");
      /*exit(0);*/
  }
 /* printf("%s\n",rbuf);*/
  close(server_sockfd);
  /*pthread_exit(0);*/
  return;
}

int File_LineInput(FILE *hFile,char *lpDest,int *nReadByte,int nMax)
{
	static char *lpSrc,TempBuff[4096];
	static size_t rByte;
	int i;

	if ( hFile==0 ) return 0;
	if ( lpDest==0 ){ lpSrc=0; return -1;}
	if ( nReadByte!=0 ) *nReadByte=0;
	*lpDest=0;i=0;
    /*--------------------------------------------------------------------------------------*/
	while (1){
		/*-----------------------------------------------------------------------*/
		if ( !(lpSrc!=0 && lpSrc!=TempBuff && rByte!=0) )		{
			rByte=fread(TempBuff,sizeof(char),4096,hFile);
			if ( rByte==0 ){lpDest[i]=0;return i;}
			lpSrc=TempBuff;
		}
		/*-----------------------------------------------------------------------*/
		while ( rByte!=0 ){
			if ( *lpSrc==0x0a ){
				lpSrc++;rByte--;(*nReadByte)++;
				if ( i<nMax ){lpDest[i]=0;return i;}
				else return -1;
			}
			else if ( *lpSrc!=0x0d && *lpSrc!=0x1a && i<nMax ) lpDest[i++]=*lpSrc;

			(*nReadByte)++;lpSrc++;rByte--;
		}
		/*-----------------------------------------------------------------------*/
	}
    /*--------------------------------------------------------------------------------------*/
}
